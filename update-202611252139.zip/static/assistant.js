(() => {
  const $ = id => document.getElementById(id);
  const ball = $("assistantBall"), panel = $("assistantPanel"), img = $("assistantBallImg");
  const modeSel = $("assistantModeSel"), note = $("assistantModeNote");
  const input = $("assistantQuestion"), send = $("assistantSend"), messages = $("assistantMessages");
  const sizeInput = $("assistantSize"), fileInput = $("assistantAvatarInput");
  const history = [];
  const personaInput = $("assistantPersona");
  let defaultPersona = '';
  personaInput.onchange = () => prefSet('assistantPersona',{text:personaInput.value.trim()});
  $("assistantPersonaReset").onclick = () => {personaInput.value=defaultPersona;prefSet('assistantPersona',{text:defaultPersona});};
  async function loadPersona(){const saved=prefGet('assistantPersona','');try{const response=await fetch('/static/assistant-knowledge.md');if(!response.ok)throw new Error();const kb=await response.text();defaultPersona=kb.split('默认人设：',2)[1].split(/\r?\n1\. /,1)[0].trim();if(!defaultPersona)throw new Error();personaInput.value=typeof saved==='object'&&saved!==null?String(saved.text??''):saved||defaultPersona;syncPersona();}catch{personaInput.value=typeof saved==='object'&&saved!==null?String(saved.text??''):saved||'';syncPersona();}}
  // 置顶消息（11-23 Hazel）：对话框顶上固定一块，默认放常用链接，用户可改；网址自动变成能点的链接
  const DEFAULT_PIN = '星露谷中文 wiki：https://zh.stardewvalleywiki.com/Stardew_Valley_Wiki\nNexus：https://www.nexusmods.com/stardewvalley/mods\nSMAPI 日志分析：https://smapi.io/log\nxnb 解包：https://lybell-art.github.io/xnb-js/';
  const pinInput = $("assistantPin"), pinBox = $("assistantPinBox");
  const pinText = () => { const v = prefGet('assistantPin', null); return v && typeof v === 'object' ? String(v.text ?? '') : DEFAULT_PIN; };
  function syncPin(){
    const text = pinText().trim();
    if (document.activeElement !== pinInput) pinInput.value = pinText();
    pinBox.replaceChildren();
    pinBox.classList.toggle('hidden', !text);
    text.split(/(https?:\/\/[^\s，。、）)]+)/).forEach((part, i) => {
      if (i % 2) { const a = document.createElement('a'); a.href = part; a.textContent = part; a.onclick = (e) => { e.preventDefault(); openExt(part); }; pinBox.append(a); }
      else if (part) pinBox.append(document.createTextNode(part));
    });
  }
  pinInput.onchange = () => { prefSet('assistantPin', {text: pinInput.value.slice(0, 2000)}); syncPin(); };
  $("assistantPinReset").onclick = () => { prefSet('assistantPin', null); pinInput.value = DEFAULT_PIN; syncPin(); };
  const showBox = $("assistantShow"), personaOn = $("assistantPersonaOn");
  function syncPersona(){const off=!!prefGet('assistantPersonaOff',false);personaOn.checked=!off;personaInput.disabled=$("assistantPersonaReset").disabled=off;}
  function syncShow(){const hidden=!!prefGet('assistantHidden',false);showBox.checked=!hidden;ball.classList.toggle('off',hidden);if(hidden)panel.classList.add('hidden');}
  personaOn.onchange=()=>{prefSet('assistantPersonaOff',!personaOn.checked);syncPersona();};
  showBox.onchange=()=>{prefSet('assistantHidden',!showBox.checked);syncShow();};
  const nameInput = $("assistantName");
  const asName = () => String(prefGet('assistantName','') || '').trim() || '模菇';
  function syncName(){nameInput.value=prefGet('assistantName','')||'';$("assistantTitle").textContent=asName();ball.title=ball.ariaLabel=asName()+'（可拖动）';}
  nameInput.onchange=()=>{prefSet('assistantName',nameInput.value.trim().slice(0,12));syncName();};
  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
  let size = 52, pos = {x:1,y:.89}, mode = 'local', busy = false, drag = null, suppressClick = false;
  function bounds() { return {x:Math.max(1,innerWidth-size-24),y:Math.max(1,innerHeight-size-24)}; }
  function snap() { const b=bounds(), distances=[pos.x*b.x,(1-pos.x)*b.x,pos.y*b.y];const edge=distances.indexOf(Math.min(...distances));if(edge===0)pos.x=0;else if(edge===1)pos.x=1;else pos.y=0; }
  function place() {
    const b = bounds();
    Object.assign(ball.style,{width:size+'px',height:size+'px',left:(12+pos.x*b.x)+'px',top:(12+pos.y*b.y)+'px',right:'auto',bottom:'auto'});
    if (!panel.classList.contains('hidden')) {
      const topEdge=pos.y===0&&pos.x>0&&pos.x<1;
      const r = ball.getBoundingClientRect();
      panel.style.height=topEdge?Math.min(490,Math.max(120,innerHeight-r.bottom-22))+'px':'';
      const w = panel.offsetWidth, h = panel.offsetHeight;
      panel.style.left = clamp(topEdge?r.left+(r.width-w)/2:r.left > innerWidth/2 ? r.left-w-10 : r.right+10,12,Math.max(12,innerWidth-w-12))+'px';
      panel.style.top = clamp(topEdge?r.bottom+10:r.bottom-h,12,Math.max(12,innerHeight-h-12))+'px';
    }
  }
  function hasAI() { return !!state.cfg?.ai_api_key_set; }
  function syncMode() {
    mode = hasAI() && prefGet('assistantMode','local') === 'ai' ? 'ai' : 'local';
    modeSel.value = mode; if (modeSel._fsLabel) modeSel._fsLabel();
    note.textContent = !hasAI() ? '还没接 AI（设置 → AI），先用本地知识库。' : (mode === 'ai' ? '用「设置 → AI」里的服务商回答，会消耗你的额度。提问和最近三轮聊天会发给它，别在聊天里写 Key。' : '只在使用说明里找答案，免费，不联网。');
    send.disabled = busy;
  }
  const intro = $("assistantIntro");
  function finishIntro(){if(!intro.classList.contains('hidden')){prefSet('assistantIntroSeen',true);intro.classList.add('hidden');}}
  function toggle(open) { panel.classList.toggle('hidden',!open); ball.setAttribute('aria-expanded',String(open)); if(open){intro.classList.toggle('hidden',!!prefGet('assistantIntroSeen',false));syncMode();place();}else{finishIntro();} }
  modeSel.onchange = () => {if(modeSel.value==='local'||hasAI())prefSet('assistantMode',modeSel.value);syncMode();};  // 没接 AI 时选了也退回本地
  $("assistantClose").onclick = () => toggle(false);
  $("assistantSkip").onclick = () => {finishIntro();input.focus();};
  $("assistantSetup").onclick = () => {toggle(false);openSettings('assistant');syncMode();};
  new MutationObserver(()=>{syncMode();syncShow();syncPersona();syncName();syncPin();}).observe($("settings"),{attributes:true,attributeFilter:['open']});
  document.querySelector('#setForm .settabs [data-tab="assistant"]').addEventListener('click',syncMode);
  ball.addEventListener('click',() => {if(suppressClick){suppressClick=false;return;}toggle(panel.classList.contains('hidden'));});
  document.addEventListener('pointerdown',(e)=>{if(panel.classList.contains('hidden')||panel.contains(e.target)||ball.contains(e.target))return;toggle(false);},true);  // 点对话框外面就收起
  ball.addEventListener('pointerdown',e=>{if(e.button!==0)return;suppressClick=false;drag={id:e.pointerId,x:e.clientX,y:e.clientY,pos:{...pos},moved:false};ball.setPointerCapture(e.pointerId);});
  ball.addEventListener('pointermove',e=>{if(!drag||e.pointerId!==drag.id)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(!drag.moved&&Math.hypot(dx,dy)<5)return;drag.moved=true;const b=bounds();pos={x:clamp(drag.pos.x+dx/b.x,0,1),y:clamp(drag.pos.y+dy/b.y,0,1)};place();});
  function finishDrag(e){if(!drag||e.pointerId!==drag.id)return;if(drag.moved){suppressClick=true;snap();place();prefSet('assistantPosition',pos);setTimeout(()=>{suppressClick=false;},300);}drag=null;}
  ball.addEventListener('pointerup',finishDrag);ball.addEventListener('pointercancel',finishDrag);
  sizeInput.oninput=()=>{size=Number(sizeInput.value);place();};sizeInput.onchange=()=>prefSet('assistantSize',size);
  $("assistantAvatarPick").onclick=()=>fileInput.click();
  function refreshAvatar(){img.src=$("assistantPreview").src='/api/assistant-avatar?v='+Date.now();}
  img.onerror=()=>{if(!img.src.endsWith('/static/Mogu.png'))img.src='/static/Mogu.png';};
  fileInput.onchange=async()=>{const file=fileInput.files[0];fileInput.value='';if(!file)return;try{if(file.size>10*1024*1024)throw new Error();const bitmap=await createImageBitmap(file);const canvas=document.createElement('canvas');canvas.width=canvas.height=192;const ratio=Math.min(192/bitmap.width,192/bitmap.height),w=bitmap.width*ratio,h=bitmap.height*ratio;canvas.getContext('2d').drawImage(bitmap,(192-w)/2,(192-h)/2,w,h);bitmap.close();await api('/api/assistant-avatar',{data:canvas.toDataURL('image/png')});refreshAvatar();}catch{toast('无法使用此图片，请选择小于 10 MB 的图片');}};
  $("assistantAvatarReset").onclick=async()=>{try{await api('/api/assistant-avatar',{clear:true});refreshAvatar();}catch{toast('恢复失败，请重试');}};
  function addMessage(text, who, label){const el=document.createElement('div');el.className='assistant-message'+(who==='user'?' user':'');if(label){const tag=document.createElement('small');tag.textContent=label;el.append(tag);}if(who!=='user')text=text.replace(/\*\*([^*\n]+)\*\*/g,'$1').replace(/\\n/g,'\n');el.append(document.createTextNode(text));messages.append(el);while(messages.children.length>25)messages.firstElementChild.remove();messages.scrollTop=messages.scrollHeight;}
  $("assistantForm").onsubmit=async e=>{e.preventDefault();const question=input.value.trim();if(!question||busy)return;finishIntro();syncMode();addMessage(question,'user');input.value='';busy=true;syncMode();try{const result=await api('/api/assistant-answer',{question,history:history.slice(-3),use_ai:mode==='ai',consent:mode==='ai'});const answer=result.answer||'暂时没有找到答案。';addMessage(answer,'assistant',result.mode==='ai'?'AI':'本地知识库');history.push({question,answer});if(history.length>3)history.shift();}catch{addMessage('暂时无法连接助手，请重新打开管理器后再试。','assistant');}finally{busy=false;syncMode();input.focus();}};
  input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();$("assistantForm").requestSubmit();}});
  addEventListener('resize',place);
  prefsReady.then(()=>{const saved=prefGet('assistantPosition',pos);if(saved&&Number.isFinite(saved.x)&&Number.isFinite(saved.y))pos={x:clamp(saved.x,0,1),y:clamp(saved.y,0,1)};size=clamp(Number(prefGet('assistantSize',52))||52,40,80);sizeInput.value=size;loadPersona();syncShow();syncName();syncPin();snap();place();syncMode();});
})();
