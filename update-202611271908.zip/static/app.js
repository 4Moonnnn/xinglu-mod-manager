"use strict";
const $ = (s, el = document) => el.querySelector(s);
// 统一替代浏览器原生 title 提示：原生提示受 Windows DPI/窗口缩放影响，可能离按钮很远。
(() => {
  const tip = document.createElement("div");
  tip.id = "uiTooltip"; tip.setAttribute("role", "tooltip"); tip.setAttribute("popover", "manual");
  document.body.append(tip);
  const popover = typeof tip.showPopover === "function";
  if (!popover) tip.hidden = true;
  let target = null, timer = 0, text = "";
  function hide() {
    clearTimeout(timer); timer = 0;
    if (popover) { if (tip.matches(":popover-open")) tip.hidePopover(); }
    else tip.hidden = true;
    if (target?.getAttribute("aria-describedby") === tip.id) target.removeAttribute("aria-describedby");
    target = null; text = "";
  }
  function follow(el) {
    const anchor = el instanceof Element ? el.closest("[title],[data-ui-tip]") : null;
    if (!anchor || anchor.matches("iframe")) { hide(); return; }
    if (anchor.hasAttribute("title")) {
      const value = anchor.getAttribute("title");
      anchor.removeAttribute("title");
      if (value) {
        anchor.dataset.uiTip = value;
        // 只有图标的按钮，保留原 title 提供的无障碍名称。
        if (anchor.matches("button,a,[role=button],summary") && !anchor.textContent.trim() && (!anchor.hasAttribute("aria-label") || anchor.dataset.uiTipLabel)) {
          anchor.setAttribute("aria-label", value); anchor.dataset.uiTipLabel = "1";
        }
      } else delete anchor.dataset.uiTip;
    }
    const next = anchor.dataset.uiTip || "";
    if (anchor === target && next === text) return;
    hide();
    if (!next) return;
    target = anchor; text = next;
    timer = setTimeout(() => {
      if (!target?.isConnected || !target.getClientRects().length) { hide(); return; }
      tip.textContent = text;
      // popover 位于窗口顶层，不会被详情页滚动区或 dialog 裁掉。
      if (popover) { if (!tip.matches(":popover-open")) tip.showPopover(); }
      else { (target.closest("dialog[open]") || document.body).append(tip); tip.hidden = false; }
      const r = target.getBoundingClientRect(), t = tip.getBoundingClientRect(), gap = 7, margin = 8;
      const left = Math.max(margin, Math.min(r.left + (r.width - t.width) / 2, innerWidth - t.width - margin));
      let top = r.top - t.height - gap;
      if (top < margin) top = r.bottom + gap;
      tip.style.left = `${left}px`; tip.style.top = `${Math.max(margin, Math.min(top, innerHeight - t.height - margin))}px`;
      if (!target.hasAttribute("aria-describedby")) target.setAttribute("aria-describedby", tip.id);
    }, 350);
  }
  // pointermove 也覆盖禁用按钮和动态插入的控件；鼠标不动时提示锚定在按钮而非指针。
  document.addEventListener("pointermove", e => { if (e.pointerType === "mouse" || e.pointerType === "pen") follow(document.elementFromPoint(e.clientX, e.clientY)); }, { passive: true, capture: true });
  document.addEventListener("pointerout", e => { if (!e.relatedTarget) hide(); }, true);
  document.addEventListener("focusin", e => { if (e.target.matches?.(":focus-visible")) follow(e.target); });
  document.addEventListener("focusout", hide, true);
  document.addEventListener("pointerdown", hide, true);
  document.addEventListener("scroll", hide, true);
  window.addEventListener("resize", hide);
  window.addEventListener("blur", hide);
  document.addEventListener("keydown", e => { if (e.key === "Escape") hide(); });
})();
const state = { mods: [], cfg: null, cat: "全部", q: "", openId: null, pollTimer: null };
const HIDDEN_NX = new Set(["hidden", "removed", "wastebinned", "deleted", "not_published", "under_moderation"]);
const MISS = "缺必需前置", UNC = "待分类", INST = "已安装", NOTINST = "未下载", OFF = "已停用", DLFAIL = "下载失败";
// 下载失败：没装上、错误是下载/安装时出的
const dlFailed = (m) => !m.installed && !m.status && /^(下载失败|安装失败)/.test(m.error || "");
// 刚点了下载：马上从「未下载」里拿走（10 分钟内没装上也没报错，就当没点过）
state.dlPending = new Map();
const dlBusy = (m) => !!m.status || (state.dlPending.get(m.id) || 0) > Date.now() - 600000;
state.selMode = false; state.sel = new Set();
const catNames = () => (state.cfg?.categories || []).map((c) => c.name);
const subsOf = (c) => (state.cfg?.categories || []).find((x) => x.name === c)?.subs || [];
// 一个 Mod 按「包含哪些内容」多选分类：存成 category/subcategory（第一个，决定整理时放哪个文件夹）+ also（其余的）
const MAX_TAGS = 8;
const tagsOf = (m) => m.category ? [{ category: m.category, subcategory: m.subcategory || "" }, ...(m.also || [])] : [...(m.also || [])];
// 显示时按分类单的顺序排（大分类先后、再子分类先后）；存的时候第一个仍然是「整理文件夹按它放」的那个
function tagRank(a) {
  const cs = (state.cfg && state.cfg.categories) || [];
  const ci = cs.findIndex((c) => c.name === a.category), c = cs[ci];
  const si = c ? c.subs.indexOf(a.subcategory || "") : -1;
  return (ci < 0 ? 999 : ci) * 1000 + (si < 0 ? (a.subcategory ? 998 : -1) : si);
}
const sortedTags = (m) => tagsOf(m).map((t, i) => ({ ...t, i })).sort((a, b) => tagRank(a) - tagRank(b));
const tagLabel = (a) => a.category + (a.subcategory ? " · " + a.subcategory : "");
const NOSUB = "其他"; // 大分类有子分类、但这个 Mod 没分到任何子分类 → 归到「其他」（分类单里自己有「其他」子分类就合在一起）
const subIs = (c, x, s) => !s || (s === NOSUB ? x === NOSUB || !subsOf(c).includes(x || "") : x === s);
const mainIn = (m, c, s) => m.category === c && subIs(c, m.subcategory, s);
const inCat = (m, c, s) => mainIn(m, c, s) || (m.also || []).some((a) => a.category === c && subIs(c, a.subcategory, s));
// 同一大分类的子分类合并成一行：内容扩展 · 新增NPC、新区域…
const catGroupsHtml = (m) => { const g = new Map(); sortedTags(m).forEach((a) => { if (!g.has(a.category)) g.set(a.category, []); if (a.subcategory) g.get(a.category).push(a.subcategory); }); return [...g].map(([c, subs]) => `<div><b>${esc(c)}</b>${subs.map((x) => `<span>${esc(x)}</span>`).join("")}</div>`).join(""); };
const catGroups = (m) => { const g = new Map(); sortedTags(m).forEach((a) => { if (!g.has(a.category)) g.set(a.category, []); if (a.subcategory) g.get(a.category).push(a.subcategory); }); return [...g].map(([c, subs]) => c + (subs.length ? " · " + subs.join("、") : "")); };
const catLabel = (m) => m.category ? tagLabel(m) : "待分类";
state.sub = "";
// 侧边栏按住 Ctrl（Mac 是 ⌘）点分类可以多选：满足任一 / 同时满足
state.multi = []; state.mAll = false; state.fold = false;
state.pack = ""; state.issue = ""; state.updReview = false;
// 刷新页面后回到原来的位置：当前分类、搜索词、打开的详情、滚动位置（只在这个窗口里记）
const KEEP = ["cat", "sub", "multi", "mAll", "pack", "q", "openId", "issue"];
const listScroll = () => matchMedia("(min-width: 821px)").matches ? $("#listScroll") : window;
const listScrollY = () => listScroll() === window ? window.scrollY : listScroll().scrollTop;
try {
  const k = JSON.parse(sessionStorage.getItem("smm-where") || "null");
  if (k) { KEEP.forEach((x) => { if (k[x] !== undefined) state[x] = k[x]; }); state.restore = k; }
} catch (e) {}
const saveWhere = () => {
  try {
    const k = {}; KEEP.forEach((x) => (k[x] = state[x]));
    k.openId = $("#detail")?.open ? state.openId : null;
    k.y = listScrollY(); k.shown = state.shown;
    sessionStorage.setItem("smm-where", JSON.stringify(k));
  } catch (e) {}
};
window.addEventListener("pagehide", saveWhere);
window.addEventListener("beforeunload", saveWhere);
const multiOn = () => state.multi.length > 1;
const multiHas = (c, s) => state.multi.some((x) => x.c === c && x.s === (s || ""));

// 常见前置的 UniqueID → 友好名字（没装在本地时也能显示得好看点）
const KNOWN = {
  "pathoschild.contentpatcher": "Content Patcher",
  "spacechase0.jsonassets": "Json Assets",
  "spacechase0.spacecore": "SpaceCore",
  "spacechase0.genericmodconfigmenu": "Generic Mod Config Menu",
  "digus.mailframeworkmod": "Mail Framework Mod",
  "platonymous.toolkit": "PyTK",
  "cherry.shoptileframework": "Shop Tile Framework",
  "paritee.betterfarmanimalvariety": "Better Farm Animal Variety",
  "esca.farmtypemanager": "Farm Type Manager",
  "furyx639.expandedstorage": "Expanded Storage",
  "peacefulend.fashionsense": "Fashion Sense",
  "peacefulend.alternativetextures": "Alternative Textures",
  "aedenthorn.customspousepatioredux": "Custom Spouse Patio Redux",
  "cherry.expandedpreconditionsutility": "Expanded Preconditions Utility",
  "flashshifter.stardewvalleyexpandedcp": "Stardew Valley Expanded",
  "mistyspring.dynamicdialogues": "Dynamic Dialogues",
  "spacechase0.contentpatcheranimations": "Content Patcher Animations",
  "dlx.bigger_backpack": "Bigger Backpack",
};

const clog = (msg) => { try { fetch("/api/clientlog", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ msg: `${msg} | ${innerWidth}x${innerHeight} dpr${devicePixelRatio}` }) }); } catch (e) {} };
window.addEventListener("error", (e) => {
  const at = (e.filename || "").split("/").pop().split("?")[0] + ":" + e.lineno;
  clog("error: " + e.message + " @" + at);
  // 页面自己的代码出错：直接告诉用户，带上位置，方便复制发给作者（11-26 Hazel）
  if (/^(app|assistant)\.js:/.test(at) && !/ResizeObserver/.test(e.message) && Date.now() - (window._jsErrAt || 0) > 10000) {
    window._jsErrAt = Date.now();
    setTimeout(() => typeof toast === "function" && toast(`页面出错：${e.message}［${at}］`, 12000), 0);
  }
});
window.addEventListener("unhandledrejection", (e) => clog("reject: " + (e.reason && (e.reason.stack || e.reason.message) || e.reason)));
// 缺设置的报错：直接打开对应的设置页，提示改成「已打开设置」（11-24 Hazel：能直接带过去的就别让人自己找）
function needSetting(msg) {
  const m = String(msg || "");
  const t = /Nexus API Key/i.test(m) ? ["nexus", "还没填 Nexus API Key，已打开设置，填好点「保存」"]
    : /AI 的 API Key/.test(m) ? ["ai", "还没填 AI 的 API Key，已打开设置，填好点「保存」"]
    : /还没.{0,4}设置游戏 Mods 文件夹|还没设置游戏 Mods 文件夹/.test(m) ? ["gen", "还没填游戏 Mods 文件夹，已打开设置，点「自动查找」或粘贴路径后点「保存」"] : null;
  if (!t || navigator.userActivation?.isActive === false) return "";  // 只在你刚点过东西时弹，后台自己发的请求不弹
  setTimeout(() => openSettings(t[0]), 0);
  return t[1];
}
async function api(path, body) {
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) };
  let r;
  try { r = await fetch(path, opt); }
  catch (err) { lostServer(); throw err; }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(needSetting(j.error) || j.error || `请求失败 (${r.status})`);
  return j;
}

// 出错时一键复制错误信息（带管理器版本），方便直接发给作者（11-23）
async function copyText(s) {
  try { await navigator.clipboard.writeText(s); return true; } catch (e) {}
  const ta = document.createElement("textarea"); ta.value = s; ta.style.position = "fixed"; ta.style.opacity = "0";
  (topDialog() || document.body).appendChild(ta); ta.select();
  let ok = false; try { ok = document.execCommand("copy"); } catch (e) {} ta.remove(); return ok;
}
async function copyErr(msg, m) {
  const ver = (typeof appUpd !== "undefined" && appUpd?.mine) || "本地版";
  const lines = [`星露管理器 ${ver}`, m ? `Mod：${m.name_zh || m.name}${m.nexus_id ? `（Nexus ${m.nexus_id}）` : ""}${m.local_version ? ` v${m.local_version}` : ""}` : "", `错误：${msg}`, `时间：${new Date().toLocaleString()}`];
  toast(await copyText(lines.filter(Boolean).join("\n")) ? "已复制，可以直接粘贴发给作者" : "复制失败，请截图发给作者");
}
const ERR_LIKE = /失败|出错|没装上|没处理好|错误|报错|不了|无法|找不到|没找到|不能|超时|拒绝|损坏|不完整|Error|error/;
const toastEl = $("#toast"), modalStack = [];
function topDialog() {
  return [...modalStack].reverse().find(d => d.open && d.isConnected)
    || document.activeElement?.closest("dialog[open]") || [...document.querySelectorAll("dialog[open]")].at(-1) || null;
}
// 原生 modal 使外部元素不可交互；toast 必须属于当前最上层的 dialog，而不只是视觉盖在它上面。
const toastHostWatch = new MutationObserver(() => { if (!toastEl.isConnected) placeToast(); });
let toastHost = null;
function placeToast() {
  const visible = !toastEl.classList.contains("hidden");
  const host = visible ? topDialog() || document.body : document.body;
  if (toastEl.parentNode !== host) {
    try { if (toastEl.matches(":popover-open")) toastEl.hidePopover(); } catch (e) {}
    host.appendChild(toastEl);
  }
  if (host !== toastHost) {
    toastHostWatch.disconnect(); toastHost = host;
    if (host !== document.body) toastHostWatch.observe(host, { childList: true });  // 复用弹窗重画时保留原提示
  }
  if (visible) { try { if (!toastEl.matches(":popover-open")) toastEl.showPopover(); } catch (e) {} }
}
document.addEventListener("beforetoggle", e => {
  const d = e.target;
  if (d.tagName !== "DIALOG") return;
  const i = modalStack.indexOf(d); if (i >= 0) modalStack.splice(i, 1);
  if (e.newState === "open") modalStack.push(d);
  queueMicrotask(placeToast);
}, true);
function toast(msg, ms = 3500) {
  const t = toastEl;
  t.textContent = msg;
  if (ms >= 6000 && ERR_LIKE.test(msg)) {  // 是报错：后面加「复制」
    const b = document.createElement("button"); b.type = "button"; b.className = "tcopy"; b.textContent = "复制";
    b.onclick = () => copyErr(msg); t.appendChild(b);
  }
  t.classList.remove("hidden");
  // 放到最上层，牌阵、详情这些弹窗开着时也看得见（11-23）
  try { if (t.matches(":popover-open")) t.hidePopover(); } catch (e) {}
  placeToast();
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { t.classList.add("hidden"); try { t.hidePopover(); } catch (e) {} placeToast(); }, ms);
}

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const norm = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9一-龥]/g, "");
const title = (m) => m.name_zh || m.name;
// 装在游戏里、能启停：有自己的文件夹，或是放进原 Mod 里的汉化
const inGame = (m) => m.installed && ((m.local_folders || []).length || (m.zh_applied || []).length);

function mdToHtml(md) {
  const lines = esc(md).split(/\r?\n/);
  let out = "", inList = false;
  for (let l of lines) {
    l = l.replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/`([^`]+)`/g, "<code>$1</code>");
    const h = l.match(/^\s*#{1,6}\s*(.*)$/);
    const li = l.match(/^\s*(?:[-*•]|\d+[.)、])\s+(.*)$/);
    if (li) { if (!inList) { out += "<ul>"; inList = true; } out += `<li>${li[1]}</li>`; continue; }
    if (inList) { out += "</ul>"; inList = false; }
    if (h) out += `<h4>${h[1]}</h4>`;
    else if (l.trim()) out += `<p>${l}</p>`;
  }
  return out + (inList ? "</ul>" : "");
}

// ---------------------------------------------------------- 依赖
// 列表里的 + 你忽略了的（忽略的 Mod 还装在游戏里时，照样算前置、算冲突）
const allMods = () => state.ignored.length ? state.mods.concat(state.ignored) : state.mods;
let libraryLookup = null;
const uninstalling = new Set();
function withLibraryLookup(fn) {
  if (libraryLookup) return fn();
  const byUid = new Map(), byNexus = new Map(), byName = new Map(), ids = new Map();
  const put = (map, key, mod) => { if (key && !map.has(key)) map.set(key, mod); };
  for (const m of allMods()) {
    ids.set(m.id, m);
    for (const u of liveUids(m)) put(byUid, u.toLowerCase(), m);
    if (m.nexus_id) put(byNexus, String(m.nexus_id), m);
    put(byName, norm(m.name), m); put(byName, norm(m.name_zh), m);
  }
  // 前置对号：自己的 Nexus 编号优先；再认 manifest 里写的 Nexus 编号、SMAPI 官网按 UniqueID 查到的 Nexus 编号（GitHub 版、接手版）
  for (const m of allMods()) for (const n of nexusAlias(m)) put(byNexus, String(n), m);
  libraryLookup = { byUid, byNexus, byName, ids, missing: new WeakMap() };
  try { return fn(); } finally { libraryLookup = null; }
}
// 装着的 Mod 只认这次扫描真在的 UniqueID：删掉的子文件夹不再算「前置已装」（GPT 查出，11-24）
const liveUids = (m) => (m.installed && m.live_uids ? m.live_uids : m.unique_ids) || [];
const nexusAlias = (m) => m.installed ? [...(m.uk_nexus || []), ...(m.smapi_nexus || [])] : [];
function findInLibrary(dep) {
  if (libraryLookup) {
    const uid = dep.unique_id && libraryLookup.byUid.get(dep.unique_id.toLowerCase());
    const nexus = dep.url && libraryLookup.byNexus.get((dep.url.match(/mods\/(\d+)/) || [])[1]);
    const name = norm(dep.name);
    return uid || nexus || (name.length >= 2 && libraryLookup.byName.get(name)) || null;
  }
  const ms = allMods();
  if (dep.unique_id) {
    const u = dep.unique_id.toLowerCase();
    const m = ms.find((x) => liveUids(x).some((y) => y.toLowerCase() === u));
    if (m) return m;
  }
  if (dep.url) {
    const id = (dep.url.match(/mods\/(\d+)/) || [])[1];
    if (id) { const m = ms.find((x) => String(x.nexus_id) === id) || ms.find((x) => nexusAlias(x).some((n) => String(n) === id)); if (m) return m; }
  }
  // 名字只认完全一样的：以前「开头相同」也算，结果 Fashion Sense 被认成了 Fashion Sense Hand Mirror Retexture
  if (dep.name) {
    const n = norm(dep.name);
    if (n.length >= 2) return ms.find((x) => norm(x.name) === n || norm(x.name_zh) === n) || null;
  }
  return null;
}

// 常见前置：说明文字里的简称 / 全名 → 标准名 + Nexus编号（这样能直接给「加入」按钮，也能和 Nexus那条合并）
const DEP_ALIAS = (() => {
  const t = [
    ["Content Patcher", 1915, "cp", "contentpatcher"], ["Fashion Sense", 9969, "fs", "fashionsense"],
    ["Json Assets", 1720, "ja", "jsonassets"], ["SpaceCore", 1348, "spacecore"],
    ["Generic Mod Config Menu", 5098, "gmcm", "genericmodconfigmenu"], ["Alternative Textures", 9246, "at", "alternativetextures"],
    ["Farm Type Manager", 3231, "ftm", "farmtypemanager"], ["Expanded Preconditions Utility", 6529, "epu", "expandedpreconditionsutility"],
    ["Mail Framework Mod", 1536, "mfm", "mailframeworkmod"], ["Stardew Valley Expanded", 3753, "sve", "stardewvalleyexpanded"],
    ["Furniture Framework", 23458, "ff", "furnitureframework"], ["PyTK", 1726, "pytk"],
  ];
  const o = {};
  for (const [name, nid, ...keys] of t) for (const k of keys) o[k] = { name, url: `https://www.nexusmods.com/stardewvalley/mods/${nid}` };
  return o;
})();
const canonDep = (d) => {
  const a = d.name && DEP_ALIAS[norm(d.name)];
  return a ? { ...d, name: a.name, url: d.url || a.url } : d;
};

const NX_PAGE = "https://www.nexusmods.com/stardewvalley/mods/";
// 内容包框架（Nexus 编号 → UniqueID）。一个 Mod 分 CP / CF / DGA 几种版本、Nexus 上几个框架都写成必需时，
// 你装的那个版本文件里没用到的框架就不算缺（11-25 Hazel：烘焙家具三个版本）
const FW_NX = { 1915: "pathoschild.contentpatcher", 1254: "platonymous.customfurniture", 9365: "spacechase0.dynamicgameassets", 1720: "spacechase0.jsonassets",
  23458: "leroymilo.furnitureframework", 9246: "peacefulend.alternativetextures", 9969: "peacefulend.fashionsense" };
const FW_CODE = { "pathoschild.contentpatcher": "CP", "platonymous.customfurniture": "CF", "spacechase0.dynamicgameassets": "DGA", "spacechase0.jsonassets": "JA",
  "leroymilo.furnitureframework": "FF", "peacefulend.alternativetextures": "AT", "peacefulend.fashionsense": "FS" };
// 只看全是内容包的 Mod（有代码的可能在代码里用到框架，不猜）。返回：这个框架你装的版本用不到 → true
function fwUnused(mod, url) {
  const fws = (mod.content && mod.content.frameworks) || [];
  if (!mod.installed || !fws.length || fws.includes("SMAPI") || !fws.some(Boolean)) return false;
  const nid = (String(url || "").match(/mods\/(\d+)/) || [])[1];
  let uid = nid && FW_NX[nid];
  if (!uid && nid) uid = Object.keys(FW_CODE).find((u) => String((state.smapiIds || {})[u]) === nid);
  if (!uid) return false;
  return !fws.includes(FW_CODE[uid]) && !(mod.local_deps || []).some((d) => (d.unique_id || "").toLowerCase() === uid);
}
const depLinkKey = (d) => ((d.url || "").match(/mods\/(\d+)/) || [])[1] || norm(d.unique_id || d.name);
function depsOf(mod) {
  const list = [];
  const add = (d0) => {
    const d = canonDep(d0);
    const isSmapi = /^smapi|stardewmodding?api/i.test(norm(d.name || d.unique_id));
    const link = depLinkKey(d), mine = !isSmapi && (mod.dep_links || {})[link];  // 玩家自己选的：「我装了」= 已装的 Mod id；「找」= "nx:Nexus 编号"；「不需要」= "skip"
    if (mine === "skip") { d.required = false; d.skipped = true; }
    if (typeof mine === "string" && mine.startsWith("nx:")) d.url = NX_PAGE + mine.slice(3);
    else if (!d.url && d.unique_id && (state.smapiIds || {})[d.unique_id.toLowerCase()]) d.url = NX_PAGE + state.smapiIds[d.unique_id.toLowerCase()];  // SMAPI 官网查到的 Nexus 编号
    const picked = typeof mine === "number" && (libraryLookup ? libraryLookup.ids.get(mine) : allMods().find((x) => x.id === mine));
    const lib = isSmapi ? null : picked || findInLibrary(d);
    d.link = link; d.picked = !!picked || (typeof mine === "string" && mine.startsWith("nx:") && !!lib);
    const key = isSmapi ? "smapi" : lib ? "id" + lib.id : norm(d.name || d.unique_id);
    if (lib && lib.id === mod.id) return;
    const ex = list.find((x) => x.key === key);
    if (ex) { if (d.prio > ex.prio) { ex.required = d.required; ex.prio = d.prio; } ex.url = ex.url || d.url; return; }
    list.push({ ...d, key, lib });
  };
  // Nexus上的 Mod 只看 Nexus写的前置；不在 Nexus上的只看 Mod 自带的 manifest.json（Hazel 定的，不再混用说明文字）
  if (mod.nexus_id) {
    for (const d of mod.nexus_requirements || []) {
      const off = d.required !== false && fwUnused(mod, d.url);
      add({ name: d.name, url: d.url, required: d.required !== false && !off, unused: off, notes: d.notes || "", prio: 2, src: "Nexus" });
    }
    // 11-25 Hazel：Nexus 页面没写、但 Mod 文件里写了「必需」的前置，游戏（SMAPI）会因为缺它不加载这个 Mod，也要列出来补齐。
    // 只补「游戏里确实没装」的那几个，Nexus 已经列过的（按 SMAPI 官网对到的编号）不重复列
    const nxIds = new Set((mod.nexus_requirements || []).map((d) => (String(d.url || "").match(/mods\/(\d+)/) || [])[1]).filter(Boolean));
    for (const d of mod.local_deps || []) {
      if (d.required === false || !d.unique_id) continue;
      const uid = d.unique_id.toLowerCase(), nid = (state.smapiIds || {})[uid];
      if (nid && nxIds.has(String(nid))) continue;
      const dd = { unique_id: d.unique_id, name: KNOWN[uid] || d.unique_id, required: true, prio: 1, src: "Mod 文件" };
      const lib = findInLibrary(canonDep(dd));
      if (lib && lib.installed && !lib.disabled) continue;
      add(dd);
    }
  } else for (const d of mod.local_deps || []) add({ unique_id: d.unique_id, name: KNOWN[d.unique_id.toLowerCase()] || d.unique_id, required: d.required, prio: 3, src: "Mod 文件" });
  for (const d of list) d.smapi = d.key === "smapi";
  return list;
}

// 只给装在游戏里的 Mod 判断缺不缺前置：必需的前置没装（不在列表、或在列表但没安装）就算缺
// 停用的 Mod 自己不检查；前置被停用了也算缺
const missingRequired = (mod) => {
  if (!mod.installed || mod.disabled) return [];
  const cache = libraryLookup?.missing;
  if (cache?.has(mod)) return cache.get(mod);
  const result = depsOf(mod).filter((d) => d.required && !d.smapi && !(d.lib && d.lib.installed && !d.lib.disabled));
  cache?.set(mod, result);
  return result;
};

// ---------------------------------------------------------- 更新 / 内容 / 冲突
const vt = (v) => (String(v || "").match(/\d+/g) || []).slice(0, 4).map(Number);
// 更新结论由后端统一计算；页面版本号和本地组件版本号不在前端直接比较。
const hasUpdate = (m) => !!m.installed && !m.ignored && m.update_assessment?.state === "update" && !m.update_assessment.stale;
const needsUpdateReview = (m) => !!(m.installed && m.nexus_id && !m.ignored && (!m.update_assessment || m.update_assessment.stale || ["unknown", "unavailable"].includes(m.update_assessment.state)));
const updateStateText = { update: "有新版本", current: "未发现新版本", unknown: "待核查", unavailable: "无法检查" };
const updateStateOf = (m) => m.update_assessment?.stale ? "unknown" : m.update_assessment?.state || "unknown";
function updateTip(m) {
  const a = m.update_assessment, files = (a?.targets || []).map((f) => `${f.name || "文件"}${f.version ? " v" + f.version : ""}`);
  return [updateStateText[updateStateOf(m)], a?.stale ? "上次结果已失效，请刷新 Mod 状态" : a?.reason, ...(a?.stale ? [] : files)].filter(Boolean).join("；");
}
function updateAssessmentHtml(m) {
  if (!m.installed || !m.nexus_id) return "";
  const a = m.update_assessment, stale = a?.stale, rows = a?.components || [];
  return `<section><h3>更新检查</h3><p>${esc(updateStateText[updateStateOf(m)] || "待核查")}<span class="muted small">${a?.checked_at ? " · " + esc(new Date(a.checked_at * 1000).toLocaleString()) : ""}</span></p>
    <p class="muted small">${esc(stale ? "上次结果已失效，请刷新 Mod 状态重新检查。" : a?.reason || "尚未核查当前安装文件，请刷新 Mod 状态。")}</p>
    ${!stale && rows.length ? `<details${rows.length > 1 && hasUpdate(m) ? " open" : ""}><summary>本地组件（${rows.length}）</summary><ul>${rows.map(c => `<li>${esc(c.name || c.uid)}${c.version ? " · v" + esc(c.version) : ""}：${esc(updateStateText[c.state] || "待核查")}${c.state === "update" && c.target_version ? " → v" + esc(c.target_version) : ""}${c.reason ? ` <span class="muted small">${esc(c.reason)}</span>` : ""}</li>`).join("")}</ul></details>` : ""}</section>`;
}
const UPD = "有更新", ERR = "处理出错", IGN = "已忽略", ISSUE = "需处理";
// 「需处理」= 缺必需前置 + 下载失败 + 处理出错（2026-11-22 Hazel：状态太多，合成一项，页面顶上再细分）
const dlFailVisible = (m) => dlFailed(m) && !((state.dlPending.get(m.id) || 0) > Date.now() - 15000);
const errOf = (m) => m.error && !m.status && !dlFailed(m);
const ISSUE_KIND = { miss: (m) => missingRequired(m).length > 0, dl: dlFailVisible, err: errOf };
const ISSUE_NAME = { miss: "缺必需前置", dl: "下载失败", err: "处理出错" };
const hasIssue = (m) => Object.values(ISSUE_KIND).some((f) => f(m));
const PACK = "\u0002合集";
state.packs = [];
const curPack = () => state.packs.find((p) => p.name === state.pack);
const packIds = (p) => (p ? p.ids : []).filter((i) => libraryLookup ? libraryLookup.ids.has(i) : allMods().some((m) => m.id === i));
state.ignored = [];
const HIDDEN_ST = ["hidden", "removed", "wastebinned", "deleted", "not_published", "under_moderation"];

const DL_RE = /^(下载中|排队下载|获取下载地址|解压安装|下载非官方)/;

// ---------------------------------------------------------- 列表
async function load() {
  if (load.running) { load.queued = true; return load.running; }
  load.running = (async () => {
    do {
      load.queued = false;
      await loadOnce();
    } while (load.queued);
  })();
  try { await load.running; } finally { load.running = null; }
}
async function loadOnce() {
  load.busy = load.busy || new Map();
  const [all, packs, slog, sids] = await Promise.all([api("/api/mods"), api("/api/packs").catch(() => state.packs), api("/api/smapi-last").catch(() => state.smapiLast), api("/api/smapi-ids").catch(() => state.smapiIds)]);
  state.smapiIds = sids || {};
  state.packs = packs || [];
  state.smapiLast = slog || {};
  // Nexus上已隐藏/删除的 Mod 不显示（装在游戏里的除外，免得你找不到它）
  const vis = all.filter((m) => m.installed || !HIDDEN_ST.includes(m.nexus_status));
  state.hiddenCount = all.length - vis.length;
  state.ignored = vis.filter((m) => m.ignored); // 你选了「忽略」的：不在列表里出现，只在「已忽略」里
  state.mods = vis.filter((m) => !m.ignored);
  render();
  smapiPopup();
  const busy = state.mods.some((m) => m.status);
  clearTimeout(state.pollTimer);
  if (busy) state.pollTimer = setTimeout(load, 4000);
  liveRefresh();
  // 刚才还在下载/安装、现在失败了的：当场弹出来（11-24 Hazel：不要让人自己点进去找）
  // 11-26：装好后翻译/AI 出错的不算「没装上」（用户截图：装好了却提示没装上）
  const was = load.busy instanceof Map ? load.busy : new Map();
  const ended = state.mods.filter((m) => was.has(m.id) && !m.status && m.error);
  const bad = ended.filter((m) => !/^((翻译|AI|Nexus)：|没有可供 AI)/.test(m.error) || !inGame(m));
  const half = ended.filter((m) => !bad.includes(m));
  if (bad.length) toast(bad.length === 1 ? `「${title(bad[0])}」没装上：${bad[0].error.replace(/^(安装|下载)失败[：:]\s*/, "")}` : `${bad.length} 个没装上，在左侧「需处理」里看原因：${bad.slice(0, 3).map(title).join("、")}`, 12000);
  else if (half.length) toast(half.length === 1 ? `「${title(half[0])}」中文名或分类没处理好（不影响游戏）：${half[0].error}` : `${half.length} 个 Mod 的中文名或分类没处理好（不影响游戏），在左侧「需处理」里看原因`, 12000);
  load.busy = new Map(state.mods.filter((m) => m.status).map((m) => [m.id, m.status]));
}
// 实时更新（11-24 Hazel：彻底查一遍）：Mod 列表一变，开着的详情页、牌阵跟着重画。
// 只在和它有关的内容真变了时才重画（这个 Mod 自己、它的前置、它的原 Mod），正在打字、开着小菜单或选择框时先不动。
const modSig = (m) => m ? [m.id, m.updated_at, m.status, m.progress, m.installed, m.disabled, m.starred, m.error, m.name_zh, m.local_version, m.version, JSON.stringify(m.update_assessment || null),
  m.category, m.subcategory, JSON.stringify(m.also || []), m.note, m.source, m.source_url, m.nexus_id, m.nexus_manual, m.component_group_confirmed, m.summary, m.summary_zh, m.tracked, m.ignored, JSON.stringify(m.dep_links || {}), (m.local_folders || []).join()].join("|") : "-";  // 一秒内连着改也认得出（GPT 查出，11-24）
function detailSig(id) {
  const m = allMods().find((x) => x.id === id);
  if (!m) return "gone";
  return withLibraryLookup(() => [modSig(m), ...depsOf(m).map((d) => d.key + ":" + modSig(d.lib)), modSig(allMods().find((x) => x.id === m.original_mod_id)), missingRequired(m).length, (gameIssues(m) || []).join(), compatOf(m) || ""].join("\n"));
}
const userBusyIn = (el) => {
  const a = document.activeElement;
  return (a && el.contains(a) && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) && a.type !== "checkbox" && a.type !== "button")
    || !!el.querySelector("details.menu[open], details.minimenu[open], .fsel.open") || $("#files").open;
};
setInterval(() => { if (!document.hidden && !load.running && ($("#detail").open || $("#stackView").open)) liveRefresh(); }, 1500);  // 刚才在打字没重画的，停下来后补上
function liveRefresh() {
  const d = $("#detail");
  if (state.openId && d.open && !userBusyIn(d)) {
    const sig = detailSig(state.openId);
    if (sig !== state.detailSig) { state.detailSig = sig; openDetail(state.openId, true).catch(() => {}); }
  }
  const sv = $("#stackView");
  if (sv.open && sv.dataset.svkey) {
    const mods = (state.restList?.find((u) => u.stack === sv.dataset.svkey) || {}).mods || [];
    const sig = mods.map(modSig).join("\n");
    if (sig !== sv.dataset.sig) { const x = $(".svtrack", sv)?.scrollLeft || 0; openStackView(sv.dataset.svkey, null, x); }
  }
}

// 非 Nexus Mod 的来源
const SOURCES = { naver: "Naver", custom: "自制", gift: "私享", other: "其他" };
const NAVER_RE = /^https?:\/\/(naver\.me\/[A-Za-z0-9]+|(m\.)?cafe\.naver\.com\/starvall\/\d+)\/?([?#].*)?$/i;
const NAVER_HINT = "可以填完整链接，也可以只填尾号：字母尾号（如 xIFKQ3Ex）或数字尾号（如 421622）";
// 完整链接或尾号 → 标准链接；认不出返回空
const normNaver = (v) => {
  v = (v || "").trim();
  if (/^\d+$/.test(v)) return "https://cafe.naver.com/starvall/" + v;
  if (/^[A-Za-z0-9]*[A-Za-z][A-Za-z0-9]*$/.test(v)) return "https://naver.me/" + v;
  if (v && !/^https?:\/\//i.test(v)) v = "https://" + v;
  return NAVER_RE.test(v) ? v : "";
};
// 本地 Mod 库：把选好的压缩包 / 文件夹传给管理器存进库
const readB64 = (f) => new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = () => no(new Error("读不了这个文件")); r.readAsDataURL(f); });
async function filesBody(files) {
  files = [...files];
  const one = files.length === 1 && !files[0].webkitRelativePath;
  return one ? { name: files[0].name, data: await readB64(files[0]) }
    : { files: await Promise.all(files.map(async (f) => ({ path: f.webkitRelativePath || f.name, data: await readB64(f) }))) };
}
async function libUpload(id, files) {
  if (!files || !files.length) return null;
  return api(`/api/mods/${id}/lib-import`, await filesBody(files));
}
const fmtSize = (b) => b >= 1048576 ? (b / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(b / 1024)) + " KB";
// 拖放导入：压缩包、文件夹直接拖进来自动认，不用先选类型；一次拖多个就是批量导入
const ARCH_RE = /\.(zip|7z|rar)$/i;
const DROP_ZONE = `<div class="dropz"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v11M7 10l5 5 5-5M5 20h14"/></svg><div><b>把压缩包或文件夹拖到这里</b><span class="muted small">可以一次拖多个。也可以 <label class="lnk">选压缩包<input type="file" data-dzfile accept=".zip,.7z,.rar" multiple hidden></label> 或 <label class="lnk">选文件夹<input type="file" data-dzdir webkitdirectory hidden></label></span></div></div>`;
const entryFile = (e) => new Promise((ok, no) => e.file(ok, no));
async function walkEntry(e, files) {
  if (e.isFile) { files.push({ file: await entryFile(e), path: e.fullPath.replace(/^\//, "") }); return; }
  const rd = e.createReader();
  for (;;) {
    const batch = await new Promise((ok, no) => rd.readEntries(ok, no));
    if (!batch.length) break;
    for (const c of batch) await walkEntry(c, files);
  }
}
async function dropItems(dt) {
  // 必须在 drop 事件里同步拿到 entry，之后才能慢慢读
  const ents = [...(dt.items || [])].map((i) => i.webkitGetAsEntry && i.webkitGetAsEntry()).filter(Boolean);
  const items = [], skip = [];
  if (!ents.length) [...(dt.files || [])].forEach((f) => (ARCH_RE.test(f.name) ? items.push({ name: f.name, files: [{ file: f, path: "" }] }) : skip.push(f.name)));
  for (const e of ents) {
    if (e.isDirectory) { const files = []; await walkEntry(e, files); if (files.length) items.push({ name: e.name, files }); else skip.push(e.name); }
    else { const f = await entryFile(e); ARCH_RE.test(f.name) ? items.push({ name: f.name, files: [{ file: f, path: "" }] }) : skip.push(f.name); }
  }
  return { items, skip };
}
function inputItems(inp) {
  const fs = [...inp.files];
  if (!inp.hasAttribute("webkitdirectory")) return { items: fs.map((f) => ({ name: f.name, files: [{ file: f, path: "" }] })), skip: [] };
  if (!fs.length) return { items: [], skip: [] };
  return { items: [{ name: fs[0].webkitRelativePath.split("/")[0], files: fs.map((f) => ({ file: f, path: f.webkitRelativePath })) }], skip: [] };
}
const itemBody = async (it) => it.files.length === 1 && !it.files[0].path ? { name: it.name, data: await readB64(it.files[0].file) }
  : { files: await Promise.all(it.files.map(async (x) => ({ path: x.path, data: await readB64(x.file) }))) };
const itemDesc = (it) => it.files[0].path ? `文件夹「${it.name}」· ${it.files.length} 个文件` : it.name;
function bindDrop(root, onItems) {
  const z = root.querySelector(".dropz");
  if (!z) return;
  const got = (r) => { if (r.skip.length) toast(`这些不是压缩包或文件夹，跳过了：${r.skip.slice(0, 5).join("、")}${r.skip.length > 5 ? " 等" : ""}`, 7000); if (r.items.length) onItems(r.items); };
  z.addEventListener("dragover", (e) => { e.preventDefault(); z.classList.add("over"); });
  z.addEventListener("dragleave", (e) => { if (!z.contains(e.relatedTarget)) z.classList.remove("over"); });
  z.addEventListener("drop", (e) => { e.preventDefault(); e.stopPropagation(); z.classList.remove("over"); dropItems(e.dataTransfer).then(got).catch((err) => toast("读不了拖进来的东西：" + err.message, 7000)); });
  z.querySelectorAll("input[type=file]").forEach((inp) => (inp.onchange = () => { const r = inputItems(inp); inp.value = ""; got(r); }));
}
// 拖到窗口别处也不会把文件直接在浏览器里打开；没开着对话框时，拖进来就直接开导入
const hasFiles = (e) => e.dataTransfer && [...e.dataTransfer.types].includes("Files");
window.addEventListener("dragover", (e) => { if (hasFiles(e)) e.preventDefault(); });
window.addEventListener("drop", (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault();
  if (document.querySelector("dialog[open]")) return;
  dropItems(e.dataTransfer).then((r) => {
    if (r.skip.length && !r.items.length) return toast("只能拖压缩包（zip / 7z / rar）或文件夹进来", 6000);
    if (r.items.length) openBatchImport(r.items);
  });
});
// 浏览器的选择框不能同时选文件和文件夹，所以做成一个按钮 + 小菜单（也可以直接拖进来）
const LIB_PICK = `<details class="minimenu"><summary class="btn mini" title="也可以直接把压缩包或文件夹拖进来">选文件<svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></summary><div class="mmpop"><label>压缩包（zip / 7z / rar）<input type="file" data-libfile accept=".zip,.7z,.rar" hidden></label><label>文件夹<input type="file" data-libdir webkitdirectory hidden></label></div></details>`;
const srcLabel = (m) => m.nexus_id ? "Nexus" : SOURCES[m.source] || "非 Nexus";
const srcTag = (m) => m.nexus_id ? (m.unofficial ? `<span class="tag src" title="装的是非官方版">非官方</span>` : "") : `<span class="tag src src-${esc(m.source || "none")}">${esc(srcLabel(m))}${m.source === "custom" ? ({original: "·原创", modified: "·改制"}[m.custom_type] || "") : ""}</span>`;
const FSTATE = {
  star: (m) => !!m.starred,
  nonx: (m) => !m.nexus_id, "src-naver": (m) => !m.nexus_id && m.source === "naver", "src-custom": (m) => !m.nexus_id && m.source === "custom",
  "src-gift": (m) => !m.nexus_id && m.source === "gift",
  "src-nexus": (m) => !!m.nexus_id,
  "src-original": (m) => !m.nexus_id && m.source === "custom" && m.custom_type === "original",
  "src-modified": (m) => !m.nexus_id && m.source === "custom" && m.custom_type === "modified",
  on: (m) => m.installed && !m.disabled, off: (m) => m.installed && m.disabled, nodl: (m) => !m.installed && !dlBusy(m) && !dlFailed(m),
  upd: (m) => hasUpdate(m), warn: (m) => missingRequired(m).length, note: (m) => (m.note || "").trim(),
  untracked: (m) => m.nexus_id && m.tracked === false,
  unoff: (m) => !!(m.unofficial_url || m.unofficial),
  zh: (m) => !m.zh_for && zhOn(m),  // 装了汉化的原 Mod（11-26 Hazel：看哪些汉化过了）
};
const FSORT = {
  name: (a, b) => title(a).localeCompare(title(b), "zh-Hans-CN"),
  added: (a, b) => (b.created_at || 0) - (a.created_at || 0),
  nexus: (a, b) => (b.nexus_updated || 0) - (a.nexus_updated || 0),
  dl: (a, b) => (b.downloads || 0) - (a.downloads || 0),
  end: (a, b) => (b.endorsements || 0) - (a.endorsements || 0),
};
state.fState = ""; state.fSort = "";
try { state.fState = localStorage.getItem("smm-fstate") || ""; state.fSort = localStorage.getItem("smm-fsort") || ""; } catch (e) {}
function filtered() {
  const list = filtered0().filter((m) => !state.fState || !FSTATE[state.fState] || FSTATE[state.fState](m));
  return state.fSort && FSORT[state.fSort] ? list.sort(FSORT[state.fSort]) : list;
}
function matchesSearch(m, q) {
  const tail = (m.source_url || m.url || "").split(/[?#]/)[0].replace(/\/+$/, "").split("/").pop();
  // 不分大小写、不管空格（11-25 Hazel）：「stardewvalley expanded」「Stardew Valley Expanded」都能搜到
  const k = searchKey(q);
  return !k || searchKey([m.name, m.name_zh, m.nexus_id, tail, m.note, m.summary_zh, m.author].join("")).includes(k);
}
function searchKey(s) { return String(s ?? "").toLowerCase().replace(/[\s\u3000]+/g, ""); }
function filtered0() {
  const q = state.q.trim().toLowerCase();
  return (state.cat === IGN ? state.ignored : state.mods).filter((m) => {
    if (multiOn()) {
      const hit = (x) => inCat(m, x.c, x.s);
      if (!(state.mAll ? state.multi.every(hit) : state.multi.some(hit))) return false;
      return matchesSearch(m, q);
    }
    if (state.cat === IGN) return matchesSearch(m, q);
    if (state.cat === PACK) { if (!(curPack()?.ids || []).includes(m.id)) return false; }
    if (state.cat === ISSUE) { if (!(state.issue ? ISSUE_KIND[state.issue](m) : hasIssue(m))) return false; }
    else if (state.cat === MISS) { if (!missingRequired(m).length) return false; }
    else if (state.cat === UNC) { if (catNames().includes(m.category)) return false; }
    else if (state.cat === INST) { if (!m.installed) return false; }
    else if (state.cat === NOTINST) { if (m.installed || dlBusy(m) || dlFailed(m)) return false; }
    else if (state.cat === OFF) { if (!m.disabled) return false; }
    else if (state.cat === UPD) { if (!(state.updReview ? needsUpdateReview(m) : hasUpdate(m))) return false; }
    else if (state.cat === ERR) { if (!m.error || m.status || dlFailed(m)) return false; }
    else if (state.cat === DLFAIL) { if (!dlFailed(m) || (state.dlPending.get(m.id) || 0) > Date.now() - 15000) return false; }
    else if (state.cat !== "全部" && state.cat !== PACK && !inCat(m, state.cat, state.sub)) return false;
    return matchesSearch(m, q);
  });
}

const view = "grid";
state.pinAll = false;
try { state.pinAll = localStorage.getItem("smm-pin") === "1"; } catch (e) {}
const ICON_EDIT = '<svg viewBox="0 0 24 24"><path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m13 7 4 4"/></svg>';
const ICON_PIN = '<svg viewBox="0 0 24 24"><path d="M9 4h6l-1 6 4 3v2H6v-2l4-3z"/><path d="M12 15v5"/></svg>';

// 本地预览图偶尔没加载出来（比如管理器正好在自动重启）：过一会儿自动重试，最多 3 次
document.addEventListener("error", (e) => {
  const img = e.target;
  if (!(img instanceof HTMLImageElement) || !/\/images\//.test(img.src)) return;
  const n = +(img.dataset.retry || 0);
  if (n >= 3) return;
  img.dataset.retry = n + 1;
  setTimeout(() => { img.src = img.src.replace(/[?#].*$/, "") + "?r=" + (n + 1); }, 1500 * (n + 1));
}, true);
function thumb(m, cls) {
  const img = (m.images || [])[0];
  return img ? `<img class="${cls}" loading="lazy" src="${esc(img)}" alt="">`
    : cls === "cover" ? genCover(m, cls) : `<div class="${cls} ph">${esc((title(m) || "?").slice(0, 1))}</div>`;
}
// 没有图片的 Mod：用名字排一张简单的封面（中文名加粗居中，下面英文名 + 作者）（11-26 Hazel）
function genCover(m, cls = "") {
  const gc = gcCfg();
  if (!gc.on) return `<div class="${cls} ph">${esc((title(m) || "?").slice(0, 1))}</div>`;
  const zh = m.name_zh && m.name_zh !== m.name ? m.name_zh : "", head = zh || m.name || "?";
  const long = zh ? head.length > 8 : head.length > 22;
  return `<div class="${cls} gencov p-${gc.pos} w-${gc.wt}${gc.img ? " hasimg" : ""}"><div class="gzh${long ? " l" : ""}${zh ? "" : " noz"}">${esc(head)}</div>${zh && m.name && gc.en ? `<div class="gen">${esc(m.name)}</div>` : ""}${m.author && gc.au ? `<div class="gau">by ${esc(m.author)}</div>` : ""}</div>`;
}

const NAV_ICON = {
  all: '<svg viewBox="0 0 24 24"><rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/></svg>',
  cat: '<svg viewBox="0 0 24 24"><path d="M4 7a2 2 0 0 1 2-2h4l2 2h6a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/></svg>',
  unc: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6M12 16.5v.5"/></svg>',
  inst: '<svg viewBox="0 0 24 24"><path d="M12 4v11m0 0-4-4m4 4 4-4M5 19h14"/></svg>',
  miss: '<svg viewBox="0 0 24 24"><path d="M12 4 3 19h18z"/><path d="M12 10v4M12 16.5v.5"/></svg>',
  pack: '<svg viewBox="0 0 24 24"><path d="M4 7a2 2 0 0 1 2-2h4l2 2h6a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/></svg>',
  redo: '<svg viewBox="0 0 24 24"><path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/></svg>',
};
const ICON_PLUS = '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>';

function render() { return withLibraryLookup(renderContent); }
function renderContent() {
  if (state.cat === UNC) { state.cat = "全部"; state.sub = ""; }
  if (state.cat === PACK && !curPack()) { state.cat = "全部"; state.pack = ""; }
  const names = catNames();
  const count = (f) => state.mods.filter(f).length;
  const categoryCounts = new Map();
  const subLists = new Map(names.map((c) => [c, new Set(subsOf(c))]));
  const catKey = (c, s = "") => c + "\u0000" + s;
  for (const m of state.mods) {
    const keys = new Set();
    for (const t of tagsOf(m)) {
      const subs = subLists.get(t.category);
      if (!subs) continue;
      keys.add(catKey(t.category));
      keys.add(catKey(t.category, subs.has(t.subcategory) ? t.subcategory : NOSUB));
    }
    for (const key of keys) categoryCounts.set(key, (categoryCounts.get(key) || 0) + 1);
  }
  const catCount = (c, s = "") => categoryCounts.get(catKey(c, s)) || 0;
  const isCat = (c) => names.includes(c);
  const item = (c, n, icon, cls = "") => `<button class="nav-item ${multiOn() ? (multiHas(c, "") ? "on" : state.multi.some((x) => x.c === c) ? "parent" : "") : c === state.cat ? (state.sub ? "parent" : "on") : ""} ${cls}" data-cat="${esc(c)}"${isCat(c) ? ` title="按住 Ctrl 点可以多选"` : ""}>${icon}<span>${esc(c)}</span><em>${n}</em></button>`;
  $("#allNav").innerHTML = item("全部", state.mods.length, NAV_ICON.all);
  let html = `<div class="nav-label">分类<button class="pin" id="editCats" title="编辑分类单">${ICON_EDIT}</button><button class="pin ${state.pinAll ? "on" : ""}" id="pinBtn" title="${state.pinAll ? "取消固定：只展开当前分类" : "固定：展开所有子分类"}">${ICON_PIN}</button></div>` +
    names.map((c) => {
      let h = item(c, catCount(c), NAV_ICON.cat);
      if ((state.pinAll || (c === state.cat && !state.fold) || state.multi.some((x) => x.c === c)) && subsOf(c).length) {
        const ns = catCount(c, NOSUB);
        const sl = [...subsOf(c), ...(ns && !subsOf(c).includes(NOSUB) ? [NOSUB] : [])].filter((x) => (c === state.cat && x === state.sub) || multiHas(c, x) || catCount(c, x)).map((x) => `<button class="sub-item ${(multiOn() ? multiHas(c, x) : c === state.cat && x === state.sub) ? "on" : ""}" data-cat="${esc(c)}" data-sub="${esc(x)}" title="按住 Ctrl 点可以多选"><span>${esc(x)}</span><em>${catCount(c, x)}</em></button>`).join("");
        if (sl) h += `<div class="subnav">${sl}</div>`;
      }
      return h;
    }).join("");
  $("#cats").innerHTML = html;
  // 合集单独一块，固定显示，不跟着分类一起滚走
  html = `<div class="nav-label">合集<button class="pin" id="newPack" title="新建合集">${ICON_PLUS}</button></div>` +
    (state.packs.length > 1 ? `<select id="packSelect" title="切换合集"><option value="" ${state.cat !== PACK || !curPack() ? "selected" : ""}>未选择</option>${state.packs.map((p) => `<option value="${esc(p.name)}" ${state.cat === PACK && state.pack === p.name ? "selected" : ""}>${esc(p.name)} · ${packIds(p).length}</option>`).join("")}</select>`
      : state.packs.length ? state.packs.map((p) => `<button class="nav-item ${state.cat === PACK && state.pack === p.name && !multiOn() ? "on" : ""} ${p.auto ? "autopack" : ""}" data-pack="${esc(p.name)}" title="${esc(p.note || "")}">${p.auto ? NAV_ICON.redo : NAV_ICON.pack}<span>${esc(p.name)}</span><em>${packIds(p).length}</em><i class="pkdel" data-pkdel="${esc(p.name)}" title="删除合集"><svg viewBox="0 0 24 24"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg></i></button>`).join("")
      : `<div class="nav-hint">暂无合集</div>`);
  $("#packNav").innerHTML = html;
  if ($("#packSelect")) {
    const sel = $("#packSelect");
    sel.onchange = (e) => { state.multi = []; state.pack = e.target.value; state.cat = state.pack ? PACK : "全部"; state.sub = ""; render(); };
    fancySelect(sel);
  }
  html = "";
  const inst = count((m) => m.installed);
  html += `<div class="nav-label">状态</div>`;
  html += item(INST, inst, NAV_ICON.inst);
  // 已停用在搜索框右边的「全部」筛选下拉里看；缺前置 / 下载失败 / 处理出错 合成「需处理」
  if ([OFF, MISS, DLFAIL, ERR].includes(state.cat)) {
    if (state.cat === OFF) { state.cat = INST; state.fState = "off"; } else { state.issue = { [MISS]: "miss", [DLFAIL]: "dl", [ERR]: "err" }[state.cat]; state.cat = ISSUE; }
  }
  const notinst = count((m) => !m.installed && !dlBusy(m) && !dlFailed(m));
  html += item(NOTINST, notinst, NAV_ICON.unc);
  const upd = count(hasUpdate);
  html += item(UPD, upd, NAV_ICON.inst, "blue");
  html += item(ISSUE, count(hasIssue), NAV_ICON.miss, "warn");
  html += item(IGN, state.ignored.length, NAV_ICON.unc);
  $("#statusNav").innerHTML = html;

  const list = filtered();
  $("#pageTitle").textContent = multiOn() ? state.multi.map((x) => x.s || x.c).join(state.mAll ? " ＋ " : " / ")
    : state.cat === PACK ? "合集 · " + state.pack : (state.cat === "全部" ? "全部 Mod" : state.cat) + (state.sub ? " / " + state.sub : "");
  const cobj = (state.cfg?.categories || []).find((c) => c.name === state.cat);
  const issueTools = $("#issueTools");
  issueTools.classList.toggle("hidden", state.cat !== ISSUE || multiOn());
  if (state.cat !== ISSUE || multiOn()) issueTools.innerHTML = "";
  const desc = state.sub ? (cobj?.sub_desc || {})[state.sub] || (state.sub === NOSUB ? "放不进上面任何一个子分类的 Mod" : "") : cobj?.desc;
  if (state.cat === PACK && !multiOn()) {
    const p = curPack(), ms = allMods().filter((m) => p.ids.includes(m.id));
    const on = ms.filter((m) => m.installed && !m.disabled).length, off = ms.filter((m) => m.installed && m.disabled).length, nd = ms.filter((m) => !m.installed).length;
    $("#pageSub").innerHTML = `<span class="pkbtns">${p.auto
        ? `<button class="small-btn primary" data-papply="only" title="把启用状态恢复成存下来的样子">恢复到这个状态</button>`
        : `<button class="small-btn primary" data-papply="add" title="启用合集里的 Mod 和它们需要的前置，别的不动">启用合集</button><button class="small-btn" data-papply="only" title="启用合集里的，其他非前置的 Mod 都停用；现在的状态会先存成「${AUTO_PACK}」">单独启用此合集</button><button class="small-btn" data-papply="off" title="停用合集里的 Mod（别的 Mod 还要用的前置留着）">停用合集</button>`}
      ${!p.auto && nd ? `<button class="small-btn" data-pdl>下载没装的 ${nd} 个</button>` : ""}${p.auto ? "" : `<button class="small-btn ghost" data-pshare>分享合集</button>`}<button class="small-btn ghost" data-prename>重命名</button><button class="small-btn ghost" data-pdel>删除合集</button></span>
      <span class="muted">${ms.length} 个：启用 ${on} · 停用 ${off}${nd ? ` · <b class="er">未下载 ${nd}</b>` : ""}${p.note ? " · " + esc(p.note) : ""}</span>`;
    $("#pageSub").title = "";
  } else if (multiOn()) {
    $("#pageSub").innerHTML = `<span class="mseg"><button class="${state.mAll ? "" : "on"}" data-mall="0">满足任一</button><button class="${state.mAll ? "on" : ""}" data-mall="1">同时满足</button></span><span class="muted">已选 ${state.multi.length} 个分类，继续按住 Ctrl 点侧边栏可以加减</span><button class="mclr" data-mclr>清除</button>`;
    $("#pageSub").title = "";
  } else if (state.cat === ISSUE) {
    const n = (k) => state.mods.filter(ISSUE_KIND[k]).length;
    if (state.issue && !n(state.issue)) state.issue = "";
    const seg = [["", "全部", state.mods.filter(hasIssue).length], ...Object.keys(ISSUE_KIND).map((k) => [k, ISSUE_NAME[k], n(k)])].filter(([k, , c]) => !k || c);
    const act = state.issue === "miss" || (!state.issue && n("miss")) ? `<button class="small-btn primary" data-fixdeps>补齐前置</button>` : "";
    const retry = state.issue === "err" || (!state.issue && n("err")) ? `<button class="small-btn" data-retryall>全部重新处理</button>` : "";
    const redl = state.issue === "dl" || (!state.issue && n("dl")) ? `<button class="small-btn" data-redl>全部重新下载</button>` : "";
    $("#pageSub").textContent = "\u00a0";
    issueTools.innerHTML = `<div class="issue-tabs">${seg.map(([k, t, c]) => `<button class="${state.issue === k ? "on" : ""}" data-issue="${k}">${t}<em>${c}</em></button>`).join("")}</div><div class="issue-actions">${act}${redl}${retry}</div>`;
    $("#pageSub").title = "";
    issueTools.querySelectorAll("[data-issue]").forEach((b) => (b.onclick = () => { state.issue = b.dataset.issue; saveWhere?.(); render(); }));
    if ($("[data-fixdeps]")) $("[data-fixdeps]").onclick = openFixDeps;
    if ($("[data-redl]")) $("[data-redl]").onclick = async (e) => {
      const b = e.currentTarget, todo = state.mods.filter(dlFailVisible);
      b.disabled = true; b.textContent = `正在提交 ${todo.length} 个…`;
      try {
        const r = await api("/api/redownload", { ids: todo.map((m) => m.id) });
        const now = Date.now(); todo.forEach((m) => state.dlPending.set(m.id, now));
        if (r.guided) { await ensureNxm(); state.updLine = { left: r.guided }; pollLine(); }
        toast([r.queued && `开始下载 ${r.queued} 个`, r.guided && `${r.guided} 个要在弹出的页面点「Slow download」`, pickVersions(r), r.manual.length > (r.manual_ids || []).length && `${r.manual.length - (r.manual_ids || []).length} 个不在 Nexus，要自己下`].filter(Boolean).join("；") || "没有要下的", 9000);
      } catch (err) { toast(err.message, 8000); }
      load();
    };
    if ($("[data-retryall]")) $("[data-retryall]").onclick = async (e) => {
      const b = e.currentTarget, todo = state.mods.filter(errOf);
      b.disabled = true; b.textContent = `正在提交 ${todo.length} 个…`;
      let ok = 0, bad = todo.length;  // 一次提交全部（原来一个个提交，每个都要整份存一次列表）
      try { const r = await api("/api/bulk", { ids: todo.map((m) => m.id), action: "refresh" }); ok = r.ok; bad = todo.length - r.ok; } catch (err) {}
      toast(bad ? `${ok} 个已重新开始处理，${bad} 个没提交上，等下再点一次` : `${ok} 个已重新开始处理，处理完会自动从这里消失`);
      load();
    };
  } else {
    $("#pageSub").textContent = desc || "\u00a0"; // 没说明也占着这一行，工具栏不会上下跳
    $("#pageSub").title = desc || "";
  }

  const busy = state.mods.filter((m) => m.status).length;
  const b = $("#banner");
  b.classList.toggle("hidden", !busy);
  b.innerHTML = busy ? `<span class="spin"></span>正在后台处理 ${busy} 个 Mod（${state.mods.some((m) => /归类/.test(m.status || "")) ? "按分类单重新归类" : state.mods.some((m) => DL_RE.test(m.status || "")) ? "下载安装" : "抓取信息、AI 翻译、下载预览图"}），可以先看别的。` : "";

  const orphan = state.mods.filter((m) => m.category && !names.includes(m.category) && !m.status).length;
  const o = $("#orphan");
  o.classList.toggle("hidden", !orphan);
  o.innerHTML = orphan ? `<span>有 ${orphan} 个 Mod 的分类不在你的分类单里（可能是旧分类）。</span><button class="secondary small-btn" id="fixOrphan">按分类单重新归类</button>` : "";
  if (orphan) $("#fixOrphan").onclick = () => reclassify(false);

  const ub = $("#updbar"), nUpd = state.mods.filter(hasUpdate).length, nReview = state.mods.filter(needsUpdateReview).length;
  const nErr = state.mods.filter((m) => m.error && !m.status && !dlFailed(m)).length;
  if (state.cat === ERR && nErr) {
    ub.classList.remove("hidden");
    ub.innerHTML = `<span>${nErr} 个 Mod 处理时出错了（多半是网络或 AI 一时没连上）。</span><button class="primary small-btn" id="retryAll">全部重新处理</button>`;
    $("#retryAll").onclick = async (e) => {
      const b = e.currentTarget, todo = state.mods.filter((x) => x.error && !x.status && !dlFailed(x));
      b.disabled = true; b.textContent = `正在提交 ${todo.length} 个…`;
      let ok = 0, bad = todo.length;  // 一次提交全部（原来一个个提交，每个都要整份存一次列表）
      try { const r = await api("/api/bulk", { ids: todo.map((m) => m.id), action: "refresh" }); ok = r.ok; bad = todo.length - r.ok; } catch (err) {}
      toast(bad ? `${ok} 个已重新开始处理，${bad} 个没提交上，等下再点一次` : `${ok} 个已重新开始处理，处理完会自动从这里消失`);
      load();
    };
  }
  const line = state.updLine;
  const showUb = line && line.left > 0 || state.cat === UPD || state.fState === "upd" && nUpd > 0;
  if (state.cat !== ERR) ub.classList.toggle("hidden", !showUb);
  if (state.cat !== ERR) ub.innerHTML = !showUb ? "" : line && line.left > 0
    ? `<span>正在逐个更新，还剩 ${line.left} 个：在弹出的小窗口里点「Slow download」，装好后会自动弹出下一个。</span><button class="small-btn" id="updReopen" title="下载窗口被关掉了，再打开一次">重新打开</button><button class="small-btn" id="updSkip">跳过这个</button><button class="small-btn" id="updStop">停止</button>`
    : `<span>${state.cat === UPD && state.updReview ? `${nReview} 个 Mod 待核查，尚不能确认需要更新。` : `${nUpd} 个 Mod 确认有新版本。`}</span>${state.cat === UPD && (nReview || state.updReview) ? `<button class="small-btn" id="updReview">${state.updReview ? `有更新（${nUpd}）` : `待核查（${nReview}）`}</button>` : ""}${nUpd && !(state.cat === UPD && state.updReview) ? `<button class="primary small-btn" id="updAll">全部更新</button>` : ""}`;
  if ($("#updReopen")) $("#updReopen").onclick = () => updLine({ reopen: true });
  if ($("#updSkip")) $("#updSkip").onclick = () => updLine({ skip: true });
  if ($("#updStop")) $("#updStop").onclick = () => updLine({ stop: true });
  if ($("#updAll")) $("#updAll").onclick = updateAll;
  if ($("#updReview")) $("#updReview").onclick = () => { state.updReview = !state.updReview; render(); };

  $("#btnSelect").classList.toggle("on", state.selMode);
  $("#btnStack").classList.toggle("on", state.stack);
  $("#empty").classList.toggle("hidden", state.mods.length > 0);
  const g = $("#grid");
  g.className = !list.length ? "" : view === "list" ? "table" : "cards";
  renderSelBar(list);  // 没有结果时也要刷新批量操作栏（GPT 查出，11-24）
  if (!list.length) {
    // 不是真的没有，而是被上面的「状态筛选」或搜索词挡住了：说清楚，给个一键清除
    const hid = state.mods.length ? filtered0().length : 0, fs = $("#fState");
    const q = state.q.trim().toLowerCase();
    const elsewhere = q && !hid ? state.mods.filter((m) => matchesSearch(m, q)).length : 0;
    g.innerHTML = !state.mods.length ? "" : hid && state.fState
      ? `<p class="none">当前筛选无结果 <button class="secondary small-btn" id="clearFState">清除筛选</button></p>`
      : elsewhere ? `<p class="none">当前分类没有匹配的 Mod，其他分类找到 ${elsewhere} 个。<button class="secondary small-btn" id="searchAll">查看全部</button></p>`
      : `<p class="none">${q ? "没有找到匹配的 Mod" : "这里还没有 Mod"}</p>`;
    if ($("#searchAll")) $("#searchAll").onclick = () => {
      state.cat = "全部"; state.sub = ""; state.multi = []; state.fState = "";
      fs.value = ""; fs._fsLabel?.();
      try { localStorage.setItem("smm-fstate", ""); } catch (e) {}
      render();
    };
    if ($("#clearFState")) $("#clearFState").onclick = () => {
      state.fState = ""; fs.value = ""; fs._fsLabel?.();
      try { localStorage.setItem("smm-fstate", ""); } catch (e) {}
      render();
    };
    return;
  }
  g.classList.toggle("selecting", state.selMode);
  // Mod 很多时先只画前面一批，滚到底部附近再接着画，操作后重画就不会卡
  const key = [view, state.cat, state.sub, state.fState, state.fSort, state.q, JSON.stringify(state.multi), state.mAll, state.pack, state.selMode, state.cat === UPD && state.updReview].join("|");
  if (key !== state.listKey) { state.listKey = key; state.shown = PAGE_N; }
  const units = stackUnits(list);
  state.restList = units;
  const fn = unitFn();
  g.innerHTML = (view === "list" ? `<div class="thead"><span>名称</span><span>分类</span><span>状态</span><span class="tc">启用</span></div>` : "")
    + units.slice(0, state.shown).map(fn).join("") + (units.length > state.shown ? `<div class="more-sent"></div>` : "");
  watchMore();
}
const PAGE_N = 60;
// 同作者叠成一摞（开关，默认关；批量操作时不叠）
state.stack = !!prefGetEarly("stackAuthor");
state.openStacks = new Set();
function prefGetEarly(k) { try { return JSON.parse(localStorage.getItem(k) || "null"); } catch (e) { return null; } }
const authorKey = (m) => (m.author || "").trim().toLowerCase();
function stackUnits(list) {
  if (!state.stack || state.selMode) return list;
  const by = new Map();
  for (const m of list) { const k = authorKey(m); if (k) by.set(k, [...(by.get(k) || []), m]); }
  const out = [], done = new Set();
  for (const m of list) {
    const k = authorKey(m), grp = k && by.get(k);
    if (!grp || grp.length < 2) { out.push(m); continue; }
    if (done.has(k)) continue;
    done.add(k);
    if (state.openStacks.has(k)) out.push({ stackHead: k, mods: grp }, ...grp, { stackEnd: k });
    else out.push({ stack: k, mods: grp });
  }
  return out;
}
function unitFn() {
  const fn = view === "list" ? row : card;
  return (u) => u.stack ? stackHtml(u) : u.stackHead ? stackHeadHtml(u) : u.stackEnd ? `<div class="stackend"></div>` : fn(u);
}
function stackHtml(u) {
  const m = u.mods[0], a = esc(m.author), n = u.mods.length;
  const on = u.mods.filter((x) => inGame(x) && !x.disabled).length, upd = u.mods.filter(hasUpdate).length;
  const names = u.mods.slice(0, 4).map((x) => esc(title(x))).join("、") + (n > 4 ? "…" : "");
  if (view === "list") return `<div class="item stackrow" data-stack="${esc(u.stack)}"><div class="name">${thumb(m, "av")}<div class="mid"><div class="t">${a}<span class="stackn">${n} 个</span></div><div class="s">${names}</div></div></div><div class="c"></div><div class="r">${upd ? `<span class="upd small">${upd} 个有更新</span>` : ""}</div><div class="rtog"></div></div>`;
  return `<article class="card stack" data-stack="${esc(u.stack)}">
    <div class="thumb">${thumb(m, "cover")}<span class="stackn">${n} 个</span></div>
    <div class="body">
      <div class="t">${a}</div>
      <div class="en">同一作者</div>
      <p>${names}</p>
      <div class="meta"><span class="muted small">已启用 ${on}/${n}${upd ? ` · <span class="upd">${upd} 个有更新</span>` : ""}</span><span class="stackopen">展开</span></div>
    </div>
  </article>`;
}
function stackHeadHtml(u) {
  return `<div class="stackhead" data-stackclose="${esc(u.stackHead)}"><span>${esc(u.mods[0].author)} · ${u.mods.length} 个</span><button class="small-btn">收起</button></div>`;
}
const moreIO = "IntersectionObserver" in window ? new IntersectionObserver((es) => { if (es.some((e) => e.isIntersecting)) showMore(); }, { rootMargin: "1200px 0px" }) : null;
function watchMore() {
  const sen = $("#grid .more-sent");
  if (!sen) return;
  if (moreIO) moreIO.observe(sen); else { state.shown = state.restList.length; render(); }
}
function showMore() {
  const g = $("#grid"), sen = $("#grid .more-sent"), list = state.restList || [];
  if (!sen) return;
  if (moreIO) moreIO.unobserve(sen);
  sen.remove();
  const fn = unitFn(), next = list.slice(state.shown, state.shown + PAGE_N * 2);
  state.shown += next.length;
  g.insertAdjacentHTML("beforeend", withLibraryLookup(() => next.map(fn).join("")) + (list.length > state.shown ? `<div class="more-sent"></div>` : ""));
  watchMore();
}

function row(m) {
  const sub = m.status ? `<span class="st">${esc(m.status)}</span>` : m.error ? `<span class="er">${esc(m.error)}</span>` : esc(m.summary_zh || m.summary || "");
  return `<div class="item ${state.sel.has(m.id) ? "picked" : ""} ${lvl(m)}" data-id="${m.id}">
    <div class="name">${state.selMode ? `<span class="chk ${state.sel.has(m.id) ? "on" : ""}"></span>` : ""}${thumb(m, "av")}
      <div class="mid">
        <div class="t">${starHtml(m)}${esc(title(m))}${m.name_zh ? `<span class="en">${esc(m.name)}</span>` : ""}${srcTag(m)}</div>
        <div class="s">${sub}</div>
        ${m.note ? `<div class="n">备注：${esc(m.note)}</div>` : ""}
      </div>
    </div>
    <div class="c" title="${esc(catGroups(m).join("\n"))}">${catGroupsHtml(m) || `<div class="none-cat">待分类</div>`}</div>
    <div class="r">${lifeHtml(m)}${updBtn(m)}${warnHtml(m)}</div>
    <div class="rtog">${togHtml(m)}</div>
  </div>`;
}

function renderSelBar(list) {
  const bar = $("#selbar");
  bar.classList.toggle("hidden", !state.selMode);
  if (!state.selMode) return;
  const visible = new Set(list.map((m) => m.id));
  for (const id of [...state.sel]) if (!allMods().some((m) => m.id === id)) state.sel.delete(id);
  const allOn = list.length && list.every((m) => state.sel.has(m.id));
  const sel = allMods().filter((m) => state.sel.has(m.id)), n = sel.length;
  const inst = sel.filter(inGame);
  const ign = state.cat === IGN;
  const sb = (id, icon, text, dis, cls = "") => `<button id="${id}" class="abtn small ${cls}" ${dis ? "disabled" : ""}>${ACT_ICON[icon]}<span>${text}</span></button>`;
  const opts = (state.cfg.categories || []).flatMap((c) => c.subs.length ? c.subs.map((x) => [c.name, x]) : [[c.name, ""]]);
  bar.innerHTML = `<div class="selhead"><span>已选 <b>${n}</b> 个</span>
      <button class="secondary small-btn" id="selAll">${allOn ? "取消全选" : `全选当前（${list.length}）`}</button>
      <span class="grow"></span><button class="ghost small-btn" id="selExit">完成</button></div>
    <div class="selacts">
      <div class="agrp"><span class="acap">游戏里</span><div>
        ${sb("bOn", "on", "启用", !inst.some((m) => m.disabled))}${sb("bOff", "off", "停用", !inst.some((m) => !m.disabled))}${sb("bUninst", "uninstall", uninstalling.size ? "正在卸载…" : "卸载", !inst.length || uninstalling.size, "danger")}
      </div></div>
      <div class="agrp"><span class="acap">管理器里</span><div>
        <select id="bTag" ${n ? "" : "disabled"}><option value="">＋ 分类</option>${opts.map(([c, x]) => `<option value="${esc(c + "\u0001" + x)}">${esc(c + (x ? " · " + x : ""))}</option>`).join("")}</select>
        <select id="bPack" ${n ? "" : "disabled"}><option value="">＋ 合集</option>${state.packs.filter((p) => !p.auto).map((p) => `<option value="${esc(p.name)}">${esc(p.name)}</option>`).join("")}<option value="\u0001new">新建合集…</option></select>
        ${state.cat === PACK ? sb("bUnpack", "remove", "移出合集", !n) : ""}
        ${sb("bMerge", "folder", "合并组件…", n < 2 || !sel.every((m) => m.installed && (m.local_folders || []).length))}
        ${ign ? sb("bIgn", "unignore", "取消忽略", !n) : sb("bIgn", "ignore", "忽略", !n)}${sb("bRemove", "remove", "移除…", !n, "danger")}
      </div></div>
    </div>`;
  bar.querySelectorAll("select").forEach(fancySelect);
  const ids = () => [...state.sel];
  const done = (msg) => (r) => { if (r && r.ok) toast(msg.replace("N", r.ok), 5000); };
  $("#selAll").onclick = () => { allOn ? visible.forEach((id) => state.sel.delete(id)) : visible.forEach((id) => state.sel.add(id)); render(); };
  $("#selExit").onclick = () => { state.selMode = false; state.sel.clear(); render(); };
  $("#bOn").onclick = () => runAction(ids(), "enable").then(done("已启用 N 个，下次进游戏生效"));
  $("#bOff").onclick = () => runAction(ids(), "disable").then(done("已停用 N 个，下次进游戏生效"));
  $("#bUninst").onclick = async (e) => {
    const b = e.currentTarget;
    if (!(await askConfirm(`卸载 ${inst.length} 个 Mod？`, "游戏文件放进回收站，30 天内能恢复。管理器里还留着它们（变回「未下载」）。", "卸载"))) return;
    const was = ids();
    b.disabled = true; b.querySelector("span").textContent = "正在卸载…";
    try {
      const r = await runAction(was, "uninstall");
      if (r.ok) { if (!r.errors?.length) done("已卸载 N 个")(r); openUnusedDeps(was); }
    } catch (err) { toast(err.message, 8000); }
    finally { if (b.isConnected) { b.disabled = false; b.querySelector("span").textContent = "卸载"; } }
  };
  $("#bTag").onchange = (e) => {
    if (!e.target.value) return;
    const [category, subcategory] = e.target.value.split("\u0001");
    runAction(ids(), "addtag", { category, subcategory }).then(done(`已给 N 个加上「${category}${subcategory ? " · " + subcategory : ""}」`));
  };
  $("#bIgn").onclick = () => runAction(ids(), ign ? "unignore" : "ignore").then((r) => { state.sel.clear(); done(ign ? "已取消忽略 N 个" : "已忽略 N 个，侧栏「已忽略」里能找回")(r); render(); });
  $("#bRemove").onclick = () => openRemove(sel);
  $("#bMerge").onclick = async (e) => {
    const button = e.currentTarget, chosen = ids();
    button.disabled = true;
    try {
      const p = await api("/api/merge-components", { ids: chosen });
      if (!(await askConfirm("合并为一个 Mod？", `将 ${p.records} 条同目录记录合并到「${p.name}」，共 ${p.folders} 个组件。保留文件、备注、标记及合集；以主记录为准，合并前记录会另外备份。`, "合并", "primary", sel.map(title)))) return;
      await api("/api/merge-components", { ids: chosen, confirm: true, primary: p.primary });
      state.sel.clear(); await load(); toast(`已合并为「${p.name}」，游戏文件未改动`);
    } catch (err) { toast(err.message, 7000); }
    finally { if (button.isConnected) button.disabled = false; }
  };
  $("#bPack").onchange = (e) => {
    const v = e.target.value;
    if (!v) return;
    if (v === "\u0001new") openPackNew(ids()); else addToPack(v, ids());
  };
  if ($("#bUnpack")) $("#bUnpack").onclick = () => { const k = ids().length; removeFromPack(state.pack, ids()).then(() => { state.sel.clear(); render(); toast(`已从「${state.pack}」移出 ${k} 个（Mod 本身不动）`); }); };
}

async function reclassify(all) {
  const r = await api("/api/reclassify", { all });
  toast(r.count ? `已安排 ${r.count} 个 Mod 重新归类` : "没有需要重新归类的 Mod");
  load();
}

// 卡片和列表上直接下载安装 / 更新（Nexus上的 Mod）
// 右下角固定是「生命周期」位：未下载 → 下载安装按钮；装好后 → 已启用 / 已停用。「更新」是附加操作，排在它左边
const canDl = (m) => m.nexus_id && !m.status && !state.selMode && !(m.nexus_status && HIDDEN_NX.has(m.nexus_status));
const updBtn = (m) => canDl(m) && hasUpdate(m) ? `<button class="mini primary dl" data-dl="${m.id}" data-update title="${esc(updateTip(m))}">更新</button>` : state.cat === UPD && state.updReview && needsUpdateReview(m) ? `<span class="muted small" title="${esc(updateTip(m))}">${esc(updateStateText[updateStateOf(m)] || "待核查")}</span>` : "";
function lifeHtml(m) {
  if (m.status) return `<span class="pill">${DL_RE.test(m.status) ? "下载中" : "处理中"}</span>`;
  if (m.installed) return m.disabled ? `<span class="pill gray">已停用</span>` : `<span class="pill green">已启用</span>`;
  return canDl(m) ? `<button class="mini dl" data-dl="${m.id}"${m.unofficial_url ? ` title="会下载非官方版"` : ""}>下载安装</button>` : `<span class="muted">—</span>`;
}
// 左边只放提醒：缺前置、选版本（文件冲突的提醒 2026-11-22 Hazel 删了：改同一个文件不代表改同一样东西）
// 上次进游戏这个 Mod 出的问题（SMAPI 日志）。之后更新、重装或停用了就不再提示
function gameIssues(m) {
  const L = state.smapiLast || {}, w = (L.mods || {})[m.id];
  if (!w || !m.installed || m.disabled) return null;
  if ((m.installed_file?.time || 0) > L.mtime || (m.unofficial?.time || 0) > L.mtime) return null;
  return w;
}
// SMAPI 自带名单里认定坏掉的（进游戏会被跳过）
const compatOf = (m) => (m.installed && !m.disabled && (state.smapiLast?.compat || {})[m.id]) || "";
function warnHtml(m) {
  const miss = missingRequired(m), gi = gameIssues(m), ci = compatOf(m);
  return (ci ? `<span class="pill red" title="${esc(ci)}">不兼容</span>` : "") + (gi ? `<span class="pill red" title="上次进游戏：${esc(gi.join("；"))}">上次出错</span>` : "") + (miss.length ? `<span class="pill red fixpill" data-fixpill title="缺：${esc(miss.map((d) => d.name).join("、"))}。点一下补齐">缺前置 ${miss.length}</span>` : "")
    + (m.variant_clash && !m.disabled ? `<span class="pill red" title="几个版本同时开着，只能用一个，在详情里选">选版本</span>` : "");
}
// 一个 Mod 里有几个只能用一个的版本：按钮上只写不一样的那部分（如「reshade」），一样的写「默认」
function variantLabels(g) {
  const lo = g.map((x) => x.toLowerCase());
  let p = 0, q = 0;
  while (lo.every((x) => x[p] !== undefined && x[p] === lo[0][p])) p++;
  while (lo.every((x) => x.length - q > p && x[x.length - 1 - q] === lo[0][lo[0].length - 1 - q])) q++;
  return g.map((x) => x.slice(p, x.length - q).replace(/^[\s\-_–—.()\[\]]+|[\s\-_–—.()\[\]]+$/g, "") || "默认");
}
function variantRows(m) {
  const on = new Set((m.local_folders || []).map((f) => f.split(/[\\/]/).pop()).filter((b) => !b.startsWith(".")));
  return (m.variants || []).map((g, gi) => {
    const lab = variantLabels(g);
    const explicit = m.disabled && g.some((b) => (m.variant_off || []).includes(b));
    return `<div class="alsorow srcrow"><span class="muted small">版本</span><span class="segsw">${g.map((b, i) =>
      `<button type="button" data-var="${esc(b)}" class="${(explicit ? !(m.variant_off || []).includes(b) : on.has(b)) && !(m.variant_clash) ? "on" : ""}" title="${esc(b)}">${esc(lab[i])}</button>`).join("")}</span>
      ${m.variant_clash && !m.disabled ? `<span class="small upd">只能开一个</span>` : ""}</div>`;
  }).join("");
}
// 我的标记：觉得不错的 Mod 点一下星星记住；状态筛选第一项「我的标记」只看它们
const STAR_ON = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20.3s-7.6-4.6-7.6-10.1A4.3 4.3 0 0 1 12 7.6a4.3 4.3 0 0 1 7.6 2.6c0 5.5-7.6 10.1-7.6 10.1z"/></svg>`;
const starHtml = (m) => state.selMode ? "" : `<button class="star ${m.starred ? "on" : ""} " data-star="${m.id}" title="${m.starred ? "已标记，点一下取消" : "标记一下，以后在「我的标记」里找"}" aria-label="标记">${STAR_ON}</button>`;
// 点亮爱心时，从爱心位置飘出几颗小爱心（放在页面最上层，列表重画也不影响）
function heartBurst(el) {
  if (!el || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const r = el.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
  const box = document.createElement("div");
  box.className = "hburst";
  box.style.left = cx + "px"; box.style.top = cy + "px";
  const n = 7;
  for (let i = 0; i < n; i++) {
    const a = (-90 + (360 / n) * i + (Math.random() * 16 - 8)) * Math.PI / 180, d = 20 + Math.random() * 8;
    const p = document.createElement("i");
    p.style.setProperty("--x", Math.cos(a) * d + "px"); p.style.setProperty("--y", Math.sin(a) * d + "px");
    p.style.setProperty("--s", (0.55 + Math.random() * 0.35).toFixed(2));
    p.style.animationDelay = (120 + Math.random() * 60) + "ms";
    p.innerHTML = STAR_ON;
    box.appendChild(p);
  }
  (el.closest("dialog[open]") || document.body).appendChild(box);
  setTimeout(() => box.remove(), 1100);
}
async function toggleStar(id) {
  const m = allMods().find((x) => x.id === id);
  if (!m) return;
  const on = !m.starred;
  if (on) heartBurst($("#detail").open ? $("#detail [data-star]") : $("#stackView").open ? $(`#stackView [data-star="${id}"]`) : document.querySelector(`#grid [data-star="${id}"]`));
  m.starred = on; state.quietUntil = Date.now() + 1500;  // 动效放完再同步列表
  // 只改这一颗爱心，不重画整个列表（重画会让动效卡一下）
  document.querySelectorAll(`#grid [data-star="${id}"], #stackView [data-star="${id}"]`).forEach((b) => { b.classList.toggle("on", on); b.classList.remove("pop"); void b.offsetWidth; if (on) b.classList.add("pop"); b.title = on ? "已标记，点一下取消" : "标记一下，以后在「我的标记」里找"; });
  if (state.fState === "star" && !on) render();
  if ($("#detail").open && state.openId === id) { const b = $("#detail [data-star]"); if (b) { b.classList.toggle("on", on); b.classList.remove("pop"); void b.offsetWidth; if (on) b.classList.add("pop"); } }
  try { await api(`/api/mods/${id}/update`, { starred: on }); toast(on ? `已标记「${title(m)}」` : "已取消标记"); }
  catch (err) { m.starred = !on; render(); toast(err.message, 6000); }
}
const togHtml = (m) => !state.selMode && inGame(m) ? `<button class="tog ${m.disabled ? "" : "on"}" data-tog="${m.id}" title="${m.disabled ? "已停用，点一下启用" : "已启用，点一下停用（不删文件）"}"><i></i></button>` : "";
const catLine = (m) => catGroups(m).map(esc).join("<i>/</i>") || "待分类";
const stateCell = (m) => `<span class="warn">${warnHtml(m)}</span><span class="life">${updBtn(m)}${lifeHtml(m)}</span>`;

// 状态层级：nodl 未下载 / off 已下载未启用 / on 已启用
const lvl = (m) => !m.installed ? "nodl" : m.disabled ? "off" : "on";

// 卡片上的「上次更新 + 是否适配当前游戏版本」：Nexus不标适配版本，按更新时间和用到的框架推测
const GAME16 = 1710806400; // 2024-03-19 星露谷 1.6 发布
function verLine(m) {
  const fw = m.content?.frameworks || [];
  const old = fw.filter((f) => ["JA", "DGA", "CF"].includes(f));
  const d = m.nexus_updated ? new Date(m.nexus_updated * 1000) : null;
  const day = d ? `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")} 更新` : m.nexus_id ? "" : `来源：${srcLabel(m)}`;
  let c = "", t = "", tip = "";
  if (old.length) { c = "bad"; t = "不适配 1.6"; tip = "用了 1.6 后不再支持的旧框架（" + old.join("、") + "）"; }
  else if (m.nexus_updated >= GAME16) { c = "ok"; t = "适配 1.6"; tip = "按更新时间推测：游戏 1.6 发布后作者更新过"; }
  else if (m.nexus_updated) { c = "warn"; t = "可能不适配 1.6"; tip = "1.6 发布前就没再更新过，下载前看看 Nexus评论区"; }
  return `<div class="ver" title="${esc(tip)}">${m.unofficial ? `<span class="vc uo" title="装的是非官方版">非官方</span>` : ""}${t ? `<span class="vc ${c}">${t}</span>` : ""}<span>${day}</span></div>`;
}
function card(m) {
  return `<article class="card ${state.sel.has(m.id) ? "picked" : ""} ${lvl(m)}" data-id="${m.id}">
    <div class="thumb">${state.selMode ? `<span class="chk ${state.sel.has(m.id) ? "on" : ""}"></span>` : ""}${togHtml(m)}${thumb(m, "cover")}${(m.images || []).length > 1 ? `<span class="pics">${m.images.length} 张</span>` : ""}${m.note && !state.selMode ? `<span class="cnote">${ICON_NOTE}备注</span><div class="cnote-full"><b>备注</b>${esc(m.note)}</div>` : ""}</div>
    <div class="body">
      <div class="t">${starHtml(m)}${esc(title(m))}</div>
      <div class="en">${m.nexus_id ? (m.name_zh ? esc(m.name) : "&nbsp;") : m.lib ? `${fmtSize(m.lib.size)} · ${m.lib.files} 个文件` : "&nbsp;"}</div>
      <div class="cat">${catLine(m)}</div>
      <p>${esc(m.summary_zh || m.summary || "")}</p>
      ${verLine(m)}
      <div class="meta">${stateCell(m)}</div>
    </div>
  </article>`;
}

async function toggleMod(id) {
  const m = allMods().find((x) => x.id === id);
  if (!m) return;
  // 先把开关拨过去（马上有反应），再让后台改文件夹
  const flip = (to) => document.querySelectorAll(`[data-tog="${id}"]`).forEach((b) => b.classList.toggle("on", to));
  flip(!!m.disabled);
  try { await api(`/api/mods/${id}/toggle`, { enable: !!m.disabled }); }
  catch (err) { flip(!m.disabled); return toast(err.message, 7000); }
  toast(m.disabled ? `已启用「${title(m)}」，下次进游戏生效` : `已停用「${title(m)}」，下次进游戏生效`);
  await load();
}

// 桌面窗口里：外部链接用你平时的浏览器打开（Nexus登录在那边）
function openExt(url, popup) {
  if (state.cfg?.app_window) api("/api/open", { url, popup: !!popup }).catch(() => window.open(url, "_blank"));
  else window.open(url, "_blank");
}
document.addEventListener("click", (e) => {
  const a = e.target.closest('a[target="_blank"]');
  if (a && state.cfg?.app_window && /^https?:/.test(a.href)) { e.preventDefault(); openExt(a.href); }
}, true);
// 心跳：告诉管理器这个窗口还开着；窗口关掉时说一声，管理器在所有窗口都关掉后才退出
const PAGE_ID = Math.random().toString(36).slice(2);
let myInstance = "";
const ping = () => fetch("/api/ping?id=" + PAGE_ID).then(async (r) => { const j = await r.clone().json().catch(() => ({})); if (j.instance) myInstance = j.instance; return r; });
setInterval(() => ping().catch(() => lostServer()), 30000);
document.addEventListener("visibilitychange", () => { if (!document.hidden) ping().catch(() => lostServer()); });
// 管理器自动重启后可能换了端口（旧端口一时让不出来）：在附近端口找同一个管理器，找到就直接跳过去（11-24）
async function findMovedServer() {
  const cur = +location.port || 80;
  if (!myInstance) return null;
  const ports = [];
  for (let d = 1; d <= 20; d++) { ports.push(cur + d); if (cur - d >= 37615) ports.push(cur - d); }
  const hits = await Promise.all(ports.map(async (p) => {
    const ac = new AbortController(); const t = setTimeout(() => ac.abort(), 1500);
    try { const j = await (await fetch(`http://127.0.0.1:${p}/api/ping`, { signal: ac.signal })).json(); return j.app === "smm" && j.instance === myInstance ? p : null; }
    catch { return null; } finally { clearTimeout(t); }
  }));
  return hits.find(Boolean) || null;
}
let lostBusy = false;
async function lostServer() {
  if (lostBusy) return; lostBusy = true;
  try {
    for (let i = 0; i < 12; i++) {  // 重启要几秒，多试一会儿
      try { await fetch("/api/ping?id=" + PAGE_ID); return; } catch {}  // 原端口又能连上了
      const p = await findMovedServer();
      if (p) { saveWhere(); location.href = `http://127.0.0.1:${p}/`; return; }
      await new Promise((r) => setTimeout(r, 2500));
    }
    toast("连不上管理器了：可能已经退出，请重新双击桌面图标打开", 8000);
  } finally { lostBusy = false; }
}
window.addEventListener("pageshow", () => ping().catch(() => {}));
window.addEventListener("pagehide", () => navigator.sendBeacon("/api/bye?id=" + PAGE_ID));
ping().catch(() => {});
// 实时同步：管理器在后台发现变化（Mods 文件夹被改了、Nexus追踪变了、检查到更新…）就重新读一次
state.rev = null;
setInterval(async () => {
  if (document.hidden || load.running) return;
  let r;
  try { r = await (await fetch("/api/rev")).json(); } catch (e) { return; }
  // 界面文件更新了 → 自动刷新这个窗口（开着弹窗或正在打字时先等等，免得打断你）
  if (r.ui) {
    if (!state.ui) state.ui = r.ui;
    else if (r.ui !== state.ui && !document.querySelector("dialog[open]") && !/^(INPUT|TEXTAREA)$/.test(document.activeElement?.tagName || "")) {
      try { sessionStorage.setItem("smm-ui-reload", "1"); } catch (e) {}
      return location.reload();
    }
  }
  if (state.quietUntil && Date.now() < state.quietUntil) return;  // 刚点完、动效还在放，晚一点再同步
  if (state.rev !== null && r.rev !== state.rev) {
    await load();  // 详情页、牌阵在 load 里跟着更新
    askTrack();
  }
  state.rev = r.rev;
  zhDoneCheck(r.zh);
}, 3000);
// 扫描进来、Nexus 上还没追踪的 Mod：问一次要不要追踪（11-24）。开着别的弹窗时不打扰，下次再问
let askTrackAt = 0;
async function askTrack() {
  if (Date.now() - askTrackAt < 60000 || document.querySelector("dialog[open]") || !state.cfg?.nexus_api_key_set) return;
  askTrackAt = Date.now();
  try { const r = await api("/api/track-ask", {}); if ((r.never || []).length && !document.querySelector("dialog[open]")) openUntracked(r.never, ""); } catch (e) {}
}
setTimeout(askTrack, 8000);

// 还缺的必需前置：和卡片「缺前置」、下面「前置依赖」用同一套判断（Nexus Mod 只看 Nexus 前置），点按钮一次补齐
function pendingDepsHtml(m) {
  const miss = missingRequired(m), gi = gameIssues(m), ci = compatOf(m);
  const g = (ci ? `<div class="depnote"><b>不兼容</b><span class="muted small">${esc(ci)}。去 Nexus 看看有没有新版，或者先停用它。</span></div>` : "") + (gi ? `<div class="depnote"><b>上次进游戏出错</b><span class="muted small">${esc(gi.join("；"))}</span></div>` : "");
  if (!miss.length) return g;
  return g + `<div class="depnote"><b>还缺 ${miss.length} 个必需前置</b><span class="muted small">${miss.map((d) => esc(d.name)).join("、")}</span><button class="small-btn primary" data-fixdeps-d>补齐前置</button></div>`;
}

// 前置没有现成链接时：SMAPI 去官网，其他按名字在 Nexus搜（UniqueID 只取点后面那段，并把驼峰拆成单词）
function depLink(x) {
  if (x.smapi || /^smapi$/i.test(x.name || "")) return "https://smapi.io/";
  let kw = String(x.name || x.id || "");
  if (!/\s/.test(kw) && kw.includes(".")) kw = kw.split(".").pop().replace(/([a-z])([A-Z])/g, "$1 $2");
  return "https://www.nexusmods.com/games/stardewvalley/search?keyword=" + encodeURIComponent(kw);
}

const ICON_NOTE = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16v12l-4 4H4z"/><path d="M8 9h8M8 13h5"/></svg>`;

// ---------------------------------------------------------- 详情
const importDetails = [];
function chooseOriginalMod(id, save) {
  const d = $("#files");
  d.innerHTML = `<div class="mhead"><h2>关联原 Mod</h2><button class="x" data-close aria-label="关闭">×</button></div>
    <input id="originalSearch" type="search" placeholder="搜索 Mod 名称或 Nexus 编号">
    <div id="originalMatches" class="flist hidden" style="max-height:50vh;overflow:auto;margin-top:10px"></div>`;
  const q = $("#originalSearch", d), list = $("#originalMatches", d);
  const draw = () => {
    const term = q.value.trim().toLowerCase();
    list.classList.toggle("hidden", !term);
    if (!term) { list.innerHTML = ""; return; }
    const matches = allMods().filter((m) => m.id !== id && [m.name, m.name_zh, m.nexus_id].join(" ").toLowerCase().includes(term)).slice(0, 50);
    list.innerHTML = matches.map((m) => `<button class="btn" style="width:100%;justify-content:flex-start;margin-bottom:4px" data-original-id="${m.id}">${esc(title(m))}</button>`).join("") || `<p class="muted">没找到对应的 Mod。</p>`;
    list.querySelectorAll("[data-original-id]").forEach((b) => b.onclick = () => { d.close(); save(() => api(`/api/mods/${id}/update`, { original_mod_id: +b.dataset.originalId }), "已关联原 Mod"); });
  };
  q.oninput = draw; draw(); showOnTop(d); q.focus();
}
// 「找」：在管理器里直接搜 Nexus，点哪个就认哪个当这个前置，并且直接下载安装（11-24 Hazel）
function findDepOnNexus(name, done) {
  const d = $("#files");
  let kw = String(name || "");
  if (!/\s/.test(kw) && kw.includes(".")) kw = kw.split(".").pop().replace(/([a-z])([A-Z])/g, "$1 $2");
  d.innerHTML = `<div class="mhead"><h2>「${esc(name)}」是哪个？</h2><button class="x" data-close aria-label="关闭">×</button></div>
    <div class="row"><input id="nfQ" type="search" value="${esc(kw)}" placeholder="Mod 名字（英文）"><button id="nfGo" class="primary">搜索</button></div>
    <div id="nfList" class="flist" style="max-height:55vh;overflow:auto;margin-top:10px"></div>`;
  const q = $("#nfQ", d), list = $("#nfList", d);
  const run = async () => {
    list.innerHTML = `<p class="muted"><span class="spin"></span>正在搜 Nexus…</p>`;
    let r;
    try { r = await api("/api/nexus-name-search?q=" + encodeURIComponent(q.value.trim())); } catch (err) { list.innerHTML = `<p class="bad">${esc(err.message)}</p>`; return; }
    list.innerHTML = r.items.map((n) => `<div class="nfrow">${n.thumb ? `<img src="${esc(n.thumb)}" alt="" loading="lazy">` : `<i></i>`}
      <div><b>${esc(n.name)}</b><span class="muted small">${esc(n.author)} · 下载 ${n.downloads.toLocaleString()}</span><p class="muted small">${esc(n.summary)}</p></div>
      <div class="nfbtn"><a class="btn mini" href="${NX_PAGE}${n.nexus_id}" target="_blank">查看Nexus页面</a><button class="mini primary" data-nf="${n.nexus_id}">就是它</button></div></div>`).join("")
      || `<p class="muted">没搜到，换个词试试（比如去掉作者名）。</p>`;
    list.querySelectorAll("[data-nf]").forEach((b) => b.onclick = () => { d.close(); done(+b.dataset.nf); });
  };
  $("#nfGo", d).onclick = run; q.onkeydown = (e) => { if (e.key === "Enter") run(); };
  showOnTop(d); run();
}
// 「我装了」：从已装的 Mod 里选一个当这个前置
// 弹窗已经开着、但压在详情页下面时（比如从「补齐前置」点进详情），先关再开，才会盖到最上面（11-25 Hazel）
function showOnTop(d) { if (d.open) d.close(); d.showModal(); }
function pickInstalled(head, selfId, done) {
  const d = $("#files");
  d.innerHTML = `<div class="mhead"><h2>${esc(head)}</h2><button class="x" data-close aria-label="关闭">×</button></div>
    <input id="pickSearch" type="search" placeholder="搜名字或 Nexus 编号（下面先列前置框架）">
    <div id="pickList" class="flist" style="max-height:50vh;overflow:auto;margin-top:10px"></div>`;
  const q = $("#pickSearch", d), list = $("#pickList", d);
  // 没搜的时候只列像前置的：这个 Mod 自己文件里写着要的，和「前置框架」分类里的；搜了就在所有已装的里找
  const self = allMods().find((m) => m.id === selfId) || {};
  const want = new Set((self.local_deps || []).map((d) => (d.unique_id || "").toLowerCase()));
  const named = (m) => (m.unique_ids || []).some((u) => want.has(u.toLowerCase()));
  const isFw = (m) => catGroups(m).some((g) => g.startsWith("前置框架"));
  const pool = allMods().filter((m) => m.installed && m.id !== selfId)
    .sort((a, b) => (named(b) - named(a)) || (isFw(b) - isFw(a)) || title(a).localeCompare(title(b), "zh"));
  const draw = () => {
    const term = q.value.trim().toLowerCase();
    const hits = pool.filter((m) => term ? [m.name, m.name_zh, m.nexus_id, ...(m.unique_ids || [])].join(" ").toLowerCase().includes(term) : named(m) || isFw(m)).slice(0, 80);
    list.innerHTML = hits.map((m) => `<button class="btn" style="width:100%;justify-content:flex-start;margin-bottom:4px;gap:8px" data-pick="${m.id}">${esc(title(m))}${m.name && m.name !== title(m) ? `<span class="muted small">${esc(m.name)}</span>` : ""}${named(m) ? `<span class="muted small">· 它的文件里写着要这个</span>` : ""}${m.disabled ? `<span class="muted small">（已停用）</span>` : ""}</button>`).join("")
      || `<p class="muted">${term ? "没找到。" : "前置框架里没有，搜一下名字试试。"}</p>`;
    list.querySelectorAll("[data-pick]").forEach((b) => b.onclick = () => { d.close(); done(+b.dataset.pick); });
  };
  q.oninput = draw; draw(); showOnTop(d); q.focus();
}
let closingDetail = false;
function detailMissing(m) {
  if (!catNames().includes(m.category)) return "请选择分类后再关闭详情";
  if (m.nexus_id) return "";
  if (m.source === "custom" && !["original", "modified"].includes(m.custom_type)) return "请选择原创或改制，并保存来源后再关闭详情";
  return "";
}
async function closeDetailChecked() {
  const d = $("#detail");
  if (!d.open || closingDetail) return;
  closingDetail = true;
  try {
    if (d.saveSourceDraft) await d.saveSourceDraft();
    const m = await api(`/api/mods/${state.openId}`);
    const missing = detailMissing(m);
    if (missing) return toast(missing, 5000);
    d.close();
    if (importDetails.length) setTimeout(() => openDetail(importDetails.shift()), 0);
  } catch (err) { toast(err.message, 6000); }
  finally { closingDetail = false; }
}

async function openDetail(id, keepScroll, given) {
  if ($("#detail").open && state.openId && state.openId !== id) {
    if ($("#detail").saveSourceDraft) await $("#detail").saveSourceDraft();
    const missing = detailMissing(await api(`/api/mods/${state.openId}`));
    if (missing) return toast(missing, 5000);
  }
  const m = given || await api(`/api/mods/${id}`);  // given：刚在本地改过的，直接画，不等管理器
  state.openId = id;
  state.detailSig = detailSig(id);
  const d = $("#detail");
  d.saveSourceDraft = null;
  const scroll = (d.querySelector(".dscroll") || d).scrollTop;
  const noteFocused = document.activeElement && document.activeElement.id === "noteBox";
  if (noteFocused) return; // 正在写备注时不刷新
  const imgs = m.images || [];
  const deps = depsOf(m).filter((x) => !x.smapi);  // SMAPI 人人都要装，不列（11-24 Hazel）
  const req = deps.filter((x) => x.required), opt = deps.filter((x) => !x.required);
  const depLi = (x) => {
    const st = x.smapi ? `<span class="muted">（游戏加载器，装在游戏目录）</span>`
      : x.lib ? `<span class="okk"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 5 5 9-10"/></svg>已在列表${x.lib.installed ? "（已安装）" : ""}</span>` : x.skipped ? `<span class="muted small">你标了不需要</span>` : x.unused ? `<span class="muted small" title="Nexus 写了必需，但你装的版本文件里没用到它">你装的版本用不到</span>` : x.required ? `<span class="bad"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>列表里没有</span>` : `<span class="muted small">未添加</span>`;
    const name = x.lib ? `<a href="#" data-open="${x.lib.id}">${esc(/^(?:Nexus|N网) (?:Mod|模组) #\d+$/.test(title(x.lib)) && x.name ? x.name : title(x.lib))}</a>`
      : `<a href="${esc(x.url || depLink(x))}" target="_blank" title="${x.url ? "打开 Nexus页面" : "在 Nexus上搜索"}">${esc(x.name)}</a>`;
    // 已识别的前置在设置里更正，详情页只保留必要的操作。
    const mineBtn = x.smapi ? "" : x.lib ? `${x.picked ? ` <span class="muted small">你选的</span>` : ""}`
      : x.skipped ? ` <button class="mini" data-depskip="${esc(x.link)}" data-unskip="1" title="改回按 Nexus / Mod 文件写的算">取消</button>`
      : !x.lib && x.required ? ` <button class="mini" data-depskip="${esc(x.link)}" title="其实用不到这个前置（比如你装的版本不需要），以后不算缺">不需要</button> <button class="mini" data-deplink="${esc(x.link)}" data-depname="${esc(x.name)}" title="已经装了这个前置（别的版本或续作），选一下是哪个">我装了</button>` : "";
    // 前置直接「下载安装」（11-24 Hazel：「＋加入」只加记录，加完还是缺，看着像没反应）；装了但停用的给「启用」
    const failed = x.lib && !x.lib.installed && x.lib.error && !x.lib.status;  // 上次下载失败：原因直接写在这一行
    const fix = x.smapi ? "" : x.lib?.status ? ` <span class="muted small">${esc(x.lib.status)}</span>` : x.lib ? (!x.lib.installed && x.lib.nexus_id ? ` <button class="mini primary" data-fixdep="${x.lib.id}">${failed ? "重试" : "下载安装"}</button>`
      : x.lib.installed && x.lib.disabled ? ` <button class="mini primary" data-fixdep="${x.lib.id}">启用</button>` : "") : "";
    const add = mineBtn + fix + (x.lib || x.smapi || x.skipped ? "" : x.url ? ` <button class="mini primary" data-adddep="${esc(x.url)}" data-depname="${esc(x.name)}">下载安装</button>`
      : ` <button class="mini" data-depfind="${esc(x.link)}" data-depname="${esc(x.name)}" title="在 Nexus 搜这个前置，选中哪个就认哪个">找</button>`);
    // 按钮统一放在右边一列，下载安装 / 启用 上下对齐，不跟着名字长短跑（11-25 Hazel）
    const err = failed ? `<span class="bad small deperr">${esc(x.lib.error)}</span>` : "";
    return `<li${x.notes ? ` title="Nexus备注：${esc(x.notes)}"` : ""}>${name} ${st}<span class="depacts">${add.trim()}</span><span class="src">来源：${x.src}</span>${err}</li>`;
  };
  const tags = tagsOf(m);
  d.innerHTML = `
    <div class="dstick">
    <div class="mhead">
      <div>
        <h2>${starHtml(m)}${esc(title(m))}<button type="button" class="dren" id="dRename" title="${m.name_zh_locked ? "改中文名（已手动改过，不会被翻译覆盖）" : "改中文名"}">${ICON_EDIT}</button></h2>
        <div class="dsub">${esc(m.name)}${m.author ? " · 作者 " + esc(m.author) : ""}${m.version ? (m.nexus_id ? " · Nexus 页面 v" : " · v") + esc(m.version) : ""}${m.unofficial ? " · 装的是非官方版" + (m.local_version ? " v" + esc(m.local_version) : "") : m.local_version && (m.local_folders || []).length < 2 ? " · 本地 v" + esc(m.local_version) : ""}${m.url ? ` · <a class="nx" href="${esc(m.url)}" target="_blank">${m.nexus_id ? "Nexus页面" : esc(srcLabel(m)) + "页面"}<svg class="ico ext" viewBox="0 0 24 24" aria-hidden="true"><path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg></a>` : ""}${hasUpdate(m) ? ` · <span class="upd">${m.unofficial ? "官方更新了" : "有新版本"}</span>` : needsUpdateReview(m) ? ` · ${esc(updateStateText[updateStateOf(m)] || "待核查")}` : ""}${zhLine(m)}</div>
      </div>
      <div class="dhead-r">
        ${m.nexus_id && hasUpdate(m) && !m.status ? `<button id="dInstall" class="primary" title="${esc(updateTip(m))}">更新</button>` : needsUpdateReview(m) && !m.status && !m.unofficial && !m.unofficial_url && !HIDDEN_NX.has(m.nexus_status) ? `<button id="dUpdateFiles" title="当前版本关系尚待核查，可自行选择要安装的 Nexus 文件">选择文件</button>` : ""}
        ${inGame(m) ? `<button id="dToggle" class="dtog ${m.disabled ? "" : "on"}" title="${m.disabled ? "点一下启用" : "点一下停用（不删文件）"}"><i></i>${m.disabled ? "已停用" : "已启用"}</button>` : ""}
        <button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button>
      </div>
    </div>
    ${variantRows(m)}
    ${m.nexus_id ? `<div class="alsorow srcrow"><span class="muted small">非官方</span>
      ${m.unofficial_url ? `<a class="uolink" id="dUnoffLink" href="${esc(m.unofficial_url)}" target="_blank" title="${esc(m.unofficial_url)}">${esc(m.unofficial_url)}</a><button class="mini" id="dUnoffEdit">编辑</button>` : ""}
      <input id="dUnoff" class="${m.unofficial_url ? "hidden" : ""}" value="${esc(m.unofficial_url || "")}" placeholder="粘贴非官方更新的链接（作者不更新时别人做的版本）">
      <button class="mini ${m.unofficial_url ? "hidden" : ""}" id="dUnoffSave">保存</button>
</div>` : ""}
    ${m.nexus_manual && !m.component_group_confirmed && (m.local_folders || []).length < 2 && (m.unique_ids || []).length < 2 ? `<div class="alsorow srcrow"><span class="muted small">Nexus</span><span class="small">编号 ${m.nexus_id}（你填的）</span><button class="mini" id="dNxUnlink">取消对应</button></div>` : ""}
    ${m.nexus_id || m.manual ? "" : `<div class="alsorow srcrow" id="dNxRow"><span class="muted small">Nexus</span>
      <input id="dNxId" placeholder="Nexus 上有这个 Mod？填编号或链接"><button class="mini" id="dNxSave">保存</button><button class="mini" id="dNxGuess">找相近的</button></div>
    <div id="dNxCands" class="nxcands hidden"></div>`}
    ${m.nexus_id ? "" : `<div class="alsorow srcrow"><span class="muted small">来源</span>
      <span class="segsw" id="dSrc">${Object.entries(SOURCES).map(([k, v]) => `<button type="button" data-src="${k}" class="${m.source === k ? "on" : ""}">${v}</button>`).join("")}</span>
      ${(() => { const u = m.source_url || m.url || ""; const href = /^https?:\/\//.test(u) ? u : (normNaver(u) || "");
        return (u ? `<a id="dSrcLink" href="${esc(href || "#")}" target="_blank" title="${esc(u)}">${esc(u)}</a><button class="mini" id="dSrcEdit">编辑</button>` : "")
          + `<input id="dSrcUrl" class="${u ? "hidden" : ""}" value="${esc(u)}" placeholder="来源链接（Naver 必填，填尾号也行）"><button class="mini ${u ? "hidden" : ""}" id="dSrcSave">保存</button>`; })()}</div>
    <div class="alsorow srcrow" id="dCustom" style="${m.source === "custom" ? "" : "display:none"}"><span class="muted small">类型</span>
      <select id="dCustomType"><option value="">未区分</option><option value="original" ${m.custom_type === "original" ? "selected" : ""}>原创</option><option value="modified" ${m.custom_type === "modified" ? "selected" : ""}>改制</option></select>
      <span id="dOriginalActions" class="libpick ${m.custom_type === "modified" ? "" : "hidden"}">
        ${m.original_mod_id ? `<a class="btn mini" href="#" data-open="${+m.original_mod_id}">${esc(title(allMods().find((x) => x.id === m.original_mod_id) || {name:"原 Mod 已移除"}))}</a><button class="mini" id="dOriginalUnlink">取消关联</button>` : ""}
        <button class="mini" id="dOriginalChoose">${m.original_mod_id ? "更换原 Mod" : "关联已有 Mod"}</button>
        <label class="btn mini" title="可直接拖入原版压缩包">备份原版文件<input id="dOriginalFile" type="file" accept=".zip,.7z,.rar" hidden></label>
        ${m.original_backup_dir ? `<button class="mini" id="dOriginalOpen">打开原版备份</button>` : ""}
      </span></div>
    <div class="alsorow librow"><span class="muted small">本地库</span>
      ${m.lib ? `<button class="mini" id="dLibOpen"${m.lib.manifest ? "" : ' title="没有 manifest.json，要自己放进 Mods"'}>打开文件夹</button>${m.lib.manifest ? `<button class="mini" id="dLibInst">${m.installed ? "从库里重装" : "装到游戏里"}</button>` : ""}<span class="libpick" title="换成新文件（旧的会备份）">${LIB_PICK.replace(">选文件<", ">换文件<")}</span>`
        : `${LIB_PICK}${m.installed && (m.local_folders || []).length ? `<button class="mini" id="dLibCollect">从游戏里收进来</button>` : ""}`}
    </div>`}
    <div class="alsorow"><span class="muted small">分类</span>
      ${sortedTags(m).map((a) => `<span class="chip" title="${a.i ? "" : "整理 Mods 文件夹时按这个分类放"}">${esc(tagLabel(a))}<button class="chipx" data-rmtag="${a.i}" title="去掉这个分类"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></span>`).join("") || `<span class="muted small">待分类</span>`}
      ${tags.length < MAX_TAGS ? `<select id="tagAdd"><option value="" data-ph>＋ 添加分类</option>${(state.cfg.categories || []).map((c) => {
        const has = (x) => tags.some((a) => a.category === c.name && (a.subcategory || "") === x);
        if (!c.subs.length) return has("") ? "" : `<option value="${esc(c.name + "\u0001")}">${esc(c.name)}</option>`;
        const left = c.subs.filter((x) => !has(x));
        return left.length ? `<optgroup label="${esc(c.name)}">${left.map((x) => `<option value="${esc(c.name + "\u0001" + x)}" data-short="${esc(x)}">${esc(c.name + " · " + x)}</option>`).join("")}</optgroup>` : "";
      }).join("")}</select>` : ""}
      ${m.category_locked ? `<span class="lockd" title="手动改过分类，AI 重新处理时不会覆盖"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg></span>` : ""}
    </div>
    <div class="alsorow packrow"><span class="muted small">合集</span>
      ${state.packs.filter((p) => !p.auto && p.ids.includes(m.id)).map((p) => `<span class="chip">${esc(p.name)}<button class="chipx" data-rmpack="${esc(p.name)}" title="移出这个合集"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></span>`).join("")}
      <select id="packAdd"><option value="" data-ph>＋ 加入合集</option>${state.packs.filter((p) => !p.auto && !p.ids.includes(m.id)).map((p) => `<option value="${esc(p.name)}">${esc(p.name)}</option>`).join("")}<option value="\u0001new">新建合集…</option></select>
    </div>
    </div>
    <div class="dscroll">
    ${m.error && !m.status ? `<div class="err">${esc(m.error)}<button type="button" class="tcopy" data-copyerr="${m.id}">复制</button></div>` : ""}
    ${m.ignored ? `<div class="offnote">已忽略：它不会出现在列表里，扫描和导入追踪也不会再加回来。点下面的「取消忽略」就恢复。</div>` : ""}
    ${m.loose_name ? `<div class="offnote">没有 manifest.json 的散装 Mod（贴图、XNB 之类），只做记录。</div>` : ""}
    ${m.installed && m.disabled ? `<div class="offnote">已停用：游戏现在不会加载它（文件还在）。点右上角开关就能恢复。</div>` : ""}
    ${pendingDepsHtml(m)}
    <div class="dtop">
      ${imgs.length ? `<div class="gallery">
        <div class="mainwrap"><img class="main" src="${esc(imgs[0])}" data-zoom alt="" title="点一下看大图"><button class="covbtn" id="dCover">换封面</button></div>
        ${imgs.length > 1 ? `<div class="strip">${imgs.map((u, i) => `<span class="sitem"><img src="${esc(u)}" data-pick="${i}" class="${i ? "" : "on"}" alt=""><button class="sdel" data-imgdel="${esc(u)}" title="删掉这张（重新抓取时也不会再下载）" aria-label="删掉这张"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></span>`).join("")}</div>` : ""}
      </div>` : `<div class="gallery empty-g">${genCover(m)}<button class="secondary" id="dCover">＋ 设置封面</button></div>`}
      <section class="dinfo">
        ${m.summary_zh ? `<p class="lead">${esc(m.summary_zh)}</p>` : m.summary ? `<p class="lead">${esc(m.summary)}</p>` : ""}
        <h3 class="nh">备注<span class="muted small" id="noteState">自动保存</span></h3>
        <textarea id="noteBox" rows="3" placeholder="比如：和 XX 冲突、配置改了什么、存档里在用…">${esc(m.note)}</textarea>
      </section>
    </div>
    ${contentSection(m)}
    ${updateAssessmentHtml(m)}
    <section>
      <h3>前置依赖</h3>
      ${deps.length ? `
        <div class="deps"><div><h4>必需</h4>${req.length ? `<ul>${req.map(depLi).join("")}</ul>` : `<p class="muted">无</p>`}</div>
        <div><h4>可选</h4>${opt.length ? `<ul>${opt.map(depLi).join("")}</ul>` : `<p class="muted">无</p>`}</div></div>`
      : `<p class="muted">没有发现依赖。</p>`}
    </section>
    <section>
      <h3>使用说明（AI 精简）</h3>
      <div class="guide">${m.guide_zh ? mdToHtml(m.guide_zh) : `<p class="muted">还没有。</p>`}</div>
      ${m.summary ? `<details><summary>Nexus原始简介</summary><p>${esc(m.summary)}</p></details>` : ""}
      <details><summary>手动粘贴原文让 AI 处理</summary>
        <textarea id="rawText" rows="6" placeholder="Nexus抓不到或说明不全时，把原文贴这里"></textarea>
        <button id="rawGo">用这段文字重新 AI 处理</button>
      </details>
    </section>
    </div>
    ${actionBar(m)}`;
  d.querySelectorAll("input, textarea").forEach((x) => x.setAttribute("autocomplete", "off"));  // 浏览器别把别的 Mod 填过的链接当候选
  d.querySelectorAll("select").forEach(fancySelect);
  if (!d.open) d.showModal();
  d.querySelector(".dscroll").scrollTop = keepScroll ? scroll : 0;

  const save = (patch) => api(`/api/mods/${id}/update`, patch).then((nm) => {
    if (nm && nm._rev) { if (state.rev === nm._rev0) state.rev = nm._rev; delete nm._rev; delete nm._rev0; }  // 只有自己改了，不用再整份重读；别处也改过就照常重读
    const i = state.mods.findIndex((x) => x.id === id);
    if (i >= 0) state.mods[i] = { ...state.mods[i], ...nm };
    render();
  });
  // 第一个分类存成 category/subcategory（整理文件夹用），其余存 also；去掉第一个时后面的顶上来
  // 先在界面上立刻改好，再在后台保存（Mod 多时保存要等一会儿）
  const saveTags = async (t) => {
    if (!t.length) return toast("每个 Mod 至少保留一个分类，请先添加新分类", 5000);
    try { if (d.saveSourceDraft) await d.saveSourceDraft(); } catch (err) { return toast(err.message, 6000); }
    const patch = { category: t[0]?.category || "", subcategory: t[0]?.subcategory || "", also: t.slice(1), category_locked: true };
    const i = state.mods.findIndex((x) => x.id === id);
    if (i >= 0) state.mods[i] = { ...state.mods[i], ...patch };
    openDetail(id, true, { ...m, ...patch });
    save(patch).catch((err) => { toast("分类没保存上：" + err.message, 6000); openDetail(id, true); });
  };
  d.querySelectorAll("[data-rmtag]").forEach((b) => (b.onclick = () => saveTags(tags.filter((_, i) => i !== +b.dataset.rmtag))));
  if ($("#tagAdd", d)) $("#tagAdd", d).onchange = (e) => {
    if (!e.target.value) return;
    const [category, subcategory] = e.target.value.split("\u0001");
    // 已经有「玩家外观」（没子分类）再加「玩家外观 · 发型」→ 换成具体的那个
    const i = subcategory ? tags.findIndex((t) => t.category === category && !t.subcategory) : -1;
    saveTags(i >= 0 ? tags.map((t, j) => (j === i ? { category, subcategory } : t)) : [...tags, { category, subcategory }]);
  };
  const nb = $("#noteBox", d);
  let t;
  // 备注保存：失败就提示，并在 3 秒后自动再试一次（GPT 查出，11-24）
  const saveNote = (retry = true) => {
    const v = nb.value, ns = () => $("#noteState", d) || {};
    return save({ note: v }).then(() => { const e = ns(); e.textContent = "已保存 ✓"; e.className = "muted small"; }, (err) => {
      const e = ns(); e.textContent = "备注没保存上：" + err.message; e.className = "small er";
      toast("备注没保存上：" + err.message, 6000);
      if (retry) setTimeout(() => { if (nb.value === v) saveNote(false); }, 3000);
    });
  };
  nb.oninput = () => { $("#noteState", d).textContent = "输入中…"; clearTimeout(t); t = setTimeout(saveNote, 600); };
  nb.onblur = () => { clearTimeout(t); saveNote(); };
  const main = $(".gallery .main", d);
  d.querySelectorAll("[data-pick]").forEach((im) => (im.onclick = () => {
    main.src = imgs[+im.dataset.pick];
    d.querySelectorAll("[data-pick]").forEach((x) => x.classList.toggle("on", x === im));
  }));
  d.querySelectorAll("[data-imgdel]").forEach((b) => (b.onclick = async (e) => {
    e.stopPropagation();
    try { await api(`/api/mods/${id}/cover`, { remove: b.dataset.imgdel }); } catch (err) { return toast(err.message, 6000); }
    toast("已删掉这张图"); await load(); openDetail(id, true);
  }));
  if (main) main.onclick = () => { $("#lightbox img").src = main.src; $("#lightbox").showModal(); };
  const rerun = (kind, body = {}) => api(`/api/mods/${id}/${kind}`, body).then(() => { toast("已加入处理队列"); load(); });
  if ($("#dRefresh", d)) $("#dRefresh", d).onclick = () => rerun("refresh");
  if ($("#dInstall", d)) $("#dInstall", d).onclick = () => installMod(id, undefined, true);
  if ($("#dUpdateFiles", d)) $("#dUpdateFiles", d).onclick = () => openFiles(id, true);
  if ($("#dFiles", d)) $("#dFiles", d).onclick = () => openFiles(id);
  $("#dRename", d).onclick = async () => {  // 改中文名（英文原名不动，对应 Nexus、检查更新都靠它）
    const r = await askInput("改中文名", m.name_zh || "", "保存", `原名：${m.name}。清空后保存就恢复自动翻译。`, { label: "同时更改 GMCM 内 Mod 名称", checked: m.name_game !== false });
    if (r === null) return;
    const v = r.value, g = r.checked;
    if (v === (m.name_zh || "") && g === (m.name_game !== false)) return;
    try {
      const x = await api(`/api/mods/${id}/update`, { name_zh: v, name_game: g });
      toast(x._warn || (!v ? "已恢复自动翻译，游戏里也换回原名" : g ? (m.installed ? "已改名，游戏里也改好了，下次进游戏生效" : "已改名，装好后游戏里也会用这个名字") : "已改名，只在管理器里显示"), x._warn ? 8000 : 4000);
      await load(); openDetail(id, true);
    } catch (err) { toast(err.message, 6000); }
  };
  $("#dCover", d).onclick = (e) => { e.stopPropagation(); openCovers(id); };
  if ($("[data-star]", d)) $("[data-star]", d).onclick = () => toggleStar(id);
  if ($("#dToggle", d)) $("#dToggle", d).onclick = () => toggleMod(id).then(() => openDetail(id, true));
  d.querySelectorAll("[data-var]").forEach((b) => (b.onclick = async () => {
    try { await api(`/api/mods/${id}/variant`, { pick: b.dataset.var }); toast(`已切换到「${b.textContent}」，下次进游戏生效`); await load(); openDetail(id, true); }
    catch (err) { toast(err.message, 7000); }
  }));
  const libDo = async (fn, ok) => { try { await fn(); toast(ok); await load(); openDetail(id, true); } catch (err) { toast(err.message, 8000); } };
  d.querySelectorAll(".librow input[type=file]").forEach((inp) => (inp.onchange = () => {
    if (!inp.files.length) return;
    toast("正在存进本地库…", 20000);
    libDo(() => libUpload(id, inp.files), "已存进本地库");
  }));
  const lr = $(".librow", d);
  if (lr) {
    lr.addEventListener("dragover", (e) => { if (hasFiles(e)) { e.preventDefault(); lr.classList.add("over"); } });
    lr.addEventListener("dragleave", (e) => { if (!lr.contains(e.relatedTarget)) lr.classList.remove("over"); });
    lr.addEventListener("drop", (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault(); lr.classList.remove("over");
      dropItems(e.dataTransfer).then((r) => {
        if (!r.items.length) return toast("只能拖压缩包或文件夹进来", 6000);
        toast("正在存进本地库…", 20000);
        libDo(async () => api(`/api/mods/${id}/lib-import`, await itemBody(r.items[0])), "已存进本地库");
      });
    });
  }
  if ($("#dLibOpen", d)) $("#dLibOpen", d).onclick = () => api(`/api/mods/${id}/lib-open`, {}).catch((e) => toast(e.message));
  if ($("#dLibInst", d)) $("#dLibInst", d).onclick = () => { toast("正在装…", 20000); libDo(() => api(`/api/mods/${id}/lib-install`, {}), "装好了，下次进游戏生效"); };
  if ($("#dLibCollect", d)) $("#dLibCollect", d).onclick = () => libDo(() => api(`/api/mods/${id}/lib-collect`, {}), "已从游戏里复制一份进本地库");
  if ($("#dSrc", d)) {
    let src = m.source || "";
    const paint = () => { d.querySelectorAll("#dSrc button").forEach((b) => b.classList.toggle("on", b.dataset.src === src)); $("#dCustom", d).style.display = src === "custom" ? "" : "none"; };
    const type = $("#dCustomType", d);
    let pending = Promise.resolve();
    d.saveSourceDraft = () => {
      const url = $("#dSrcUrl", d).value.trim();
      if (src === "naver" && !normNaver(url)) return Promise.reject(new Error("Naver 链接格式不对，" + NAVER_HINT));
      const patch = { source: src, source_url: url, ...(src === "custom" ? { custom_type: type.value } : {}) };
      pending = pending.catch(() => {}).then(async () => {
        if (Object.entries(patch).every(([k, v]) => (m[k] || "") === v)) return;
        const nm = await api(`/api/mods/${id}/update`, patch);
        if (nm && nm._rev) { if (state.rev === nm._rev0) state.rev = nm._rev; delete nm._rev; delete nm._rev0; }
        Object.assign(m, nm || patch);
        const i = state.mods.findIndex((x) => x.id === id);
        if (i >= 0) state.mods[i] = { ...state.mods[i], ...nm };
        render();
      });
      return pending;
    };
    type.onchange = () => { $("#dOriginalActions", d).classList.toggle("hidden", type.value !== "modified"); d.saveSourceDraft().catch((err) => toast(err.message, 6000)); };
    const originalDo = async (fn, ok) => {
      try { await d.saveSourceDraft(); await fn(); toast(ok); await load(); openDetail(id, true); }
      catch (err) { toast(err.message, 7000); }
    };
    $("#dOriginalChoose", d).onclick = () => chooseOriginalMod(id, originalDo);
    if ($("#dOriginalUnlink", d)) $("#dOriginalUnlink", d).onclick = () => originalDo(() => api(`/api/mods/${id}/update`, { original_mod_id: null }), "已取消关联");
    if ($("#dOriginalOpen", d)) $("#dOriginalOpen", d).onclick = () => api(`/api/mods/${id}/original-open`, {}).catch((err) => toast(err.message, 6000));
    const backupOriginal = (file) => {
      if (!file || !/\.(zip|7z|rar)$/i.test(file.name)) return toast("请选择原版压缩包（zip / 7z / rar）", 5000);
      originalDo(async () => api(`/api/mods/${id}/original-backup`, { name: file.name, data: await readB64(file) }), "原版已备份");
    };
    $("#dOriginalFile", d).onchange = (e) => { const file = e.target.files[0]; e.target.value = ""; if (file) backupOriginal(file); };
    const oa = $("#dOriginalActions", d);
    oa.addEventListener("dragover", (e) => { if (hasFiles(e)) { e.preventDefault(); e.stopPropagation(); } });
    oa.addEventListener("drop", (e) => { if (hasFiles(e)) { e.preventDefault(); e.stopPropagation(); backupOriginal(e.dataTransfer.files[0]); } });
    // 点来源马上保存（链接收起时也能改来源）
    d.querySelectorAll("#dSrc button").forEach((b) => (b.onclick = () => { src = b.dataset.src; paint(); d.saveSourceDraft().then(() => toast("来源已保存")).catch((err) => toast(err.message, 6000)); }));
    if ($("#dSrcEdit", d)) $("#dSrcEdit", d).onclick = () => {
      ["#dSrcLink", "#dSrcEdit"].forEach((q) => $(q, d).classList.add("hidden"));
      ["#dSrcUrl", "#dSrcSave"].forEach((q) => $(q, d).classList.remove("hidden"));
      $("#dSrcUrl", d).focus(); $("#dSrcUrl", d).select();
    };
    $("#dSrcUrl", d).onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); $("#dSrcSave", d).click(); } };
    $("#dSrcSave", d).onclick = async () => {
      try { await d.saveSourceDraft(); toast("来源已保存"); await load(); openDetail(id, true); }
      catch (err) { toast(err.message, 8000); }
    };
  }
  if ($("#dUnoffGet", d)) $("#dUnoffGet", d).onclick = () => unoffGet(id);
  if ($("#dUnoffFile", d)) $("#dUnoffFile", d).onchange = async (e) => {
    const f = e.target.files[0]; e.target.value = "";
    if (!f) return;
    toast("正在安装…");
    try { await api(`/api/mods/${id}/unoff-file`, { name: f.name, data: await readB64(f) }); toast("非官方版装好了"); await load(); openDetail(id, true); }
    catch (err) { toast(err.message, 8000); }
  };
  if ($("#dNxSave", d)) {
    const linkNow = async (v) => { try { await nxLink(id, v); await load(); openDetail(id, true); } catch (err) { toast(err.message, 6000); } };
    $("#dNxSave", d).onclick = () => { const v = $("#dNxId", d).value.trim(); if (!v) return toast("先填 Nexus 编号或链接"); linkNow(v); };
    $("#dNxId", d).onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); $("#dNxSave", d).click(); } };
    $("#dNxGuess", d).onclick = async (e) => {
      const b = e.currentTarget, box = $("#dNxCands", d);
      if (!state.cfg?.nexus_api_key_set) return toast("先在设置里填 Nexus API Key", 5000);
      b.disabled = true; b.innerHTML = `<span class="spin"></span>正在找…`;
      try {
        const list = (await api(`/api/mods/${id}/nexus-guess`, {})).items;
        box.innerHTML = list.length ? list.map(nxCandHtml).join("") : `<p class="muted small">没找到相近的，可以去 Nexus 搜到后把编号填在上面。</p>`;
        box.classList.remove("hidden");
        box.querySelectorAll("[data-nxpick]").forEach((x) => (x.onclick = () => linkNow(x.dataset.nxpick)));
      } catch (err) { toast(err.message, 6000); }
      b.disabled = false; b.textContent = "找相近的";
    };
  }
  if ($("#dNxUnlink", d)) $("#dNxUnlink", d).onclick = async () => {
    if (!(await askConfirm("取消对应 Nexus？", "这个 Mod 会变回非 Nexus，不再从 Nexus 检查更新。", "取消对应", "danger", null, "不了"))) return;
    try { await api(`/api/mods/${id}/nexus-unlink`, {}); toast("已取消对应"); await load(); openDetail(id, true); } catch (err) { toast(err.message, 6000); }
  };
  if ($("#dUnoffEdit", d)) $("#dUnoffEdit", d).onclick = () => {
    ["#dUnoffLink", "#dUnoffEdit"].forEach((q) => $(q, d).classList.add("hidden"));
    ["#dUnoff", "#dUnoffSave"].forEach((q) => $(q, d).classList.remove("hidden"));
    $("#dUnoff", d).focus(); $("#dUnoff", d).select();
  };
  if ($("#dUnoff", d)) $("#dUnoff", d).onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); $("#dUnoffSave", d).click(); } };
  if ($("#dUnoffSave", d)) $("#dUnoffSave", d).onclick = async () => {
    const u = $("#dUnoff", d).value.trim();
    if (u && !/^https?:\/\//.test(u)) return toast("要以 http 开头的链接");
    try { await api(`/api/mods/${id}/update`, { unofficial_url: u }); toast(u ? "已保存" : "已清掉"); await load(); openDetail(id, true); }
    catch (err) { toast(err.message, 7000); }
  };
  $("#dAi", d).onclick = () => rerun("ai");
  $("#rawGo", d).onclick = () => { const v = $("#rawText", d).value.trim(); if (!v) return toast("先粘贴原文"); rerun("ai", { text: v }); };
  bindActionBar(m, d);
  d.querySelectorAll("[data-rmpack]").forEach((b) => (b.onclick = () => removeFromPack(b.dataset.rmpack, [id]).then(() => openDetail(id, true))));
  $("#packAdd", d).onchange = (e) => {
    const v = e.target.value;
    if (!v) return;
    if (v === "\u0001new") openPackNew([id]); else addToPack(v, [id]).then(() => openDetail(id, true));
  };
  d.querySelectorAll("[data-open]").forEach((a) => (a.onclick = (e) => { e.preventDefault(); openDetail(+a.dataset.open); }));
  const setLink = async (key, val) => {
    const links = { ...(m.dep_links || {}) };
    if (val) links[key] = val; else delete links[key];  // val：已装 Mod 的 id，或 "nx:Nexus 编号"
    try { await api(`/api/mods/${id}/update`, { dep_links: links }); } catch (err) { toast(err.message, 6000); return; }
    if (typeof val !== "string") toast(val ? "好了，以后按你选的算" : "已取消，按自动识别算");
    await load(); openDetail(id, true);
  };
  const nxPick = (key, name) => findDepOnNexus(name, async (nid) => {
    await setLink(key, "nx:" + nid);
    const r = await api("/api/fix-deps", { items: [{ url: NX_PAGE + nid }] }).catch((err) => { toast(err.message, 7000); });
    if (r) await fixDepsDone(r);
  });
  d.querySelectorAll("[data-depfind]").forEach((b) => (b.onclick = () => nxPick(b.dataset.depfind, b.dataset.depname)));
  d.querySelectorAll("[data-depskip]").forEach((b) => (b.onclick = async () => { await setLink(b.dataset.depskip, b.dataset.unskip ? 0 : "skip"); if (!b.dataset.unskip) toast("好了，以后不算缺这个前置"); }));
  d.querySelectorAll("[data-deplink]").forEach((b) => (b.onclick = () => pickInstalled(`「${b.dataset.depname}」是哪个？`, id, (pick) => setLink(b.dataset.deplink, pick))));
  d.querySelectorAll("[data-adddep], [data-fixdep]").forEach((b) => (b.onclick = async () => {
    b.disabled = true; b.innerHTML = `<span class="spin"></span>处理中`;
    const item = b.dataset.fixdep ? { id: +b.dataset.fixdep } : { url: b.dataset.adddep, name: b.dataset.depname };
    const r = await api("/api/fix-deps", { items: [item] }).catch((err) => { toast(err.message, 7000); b.disabled = false; b.textContent = "重试"; });
    if (r) await fixDepsDone(r);
  }));
}

function contentSection(m) {
  const c = m.content;
  if (!m.installed || !c) return `<section><h3>内容</h3><p class="muted small">${m.installed ? "点一次「刷新 Mod 状态」就能看到这个 Mod 改了什么。" : "这个 Mod 没装在游戏里，读不到它的文件。装好后点「刷新 Mod 状态」就能看到它改了什么。"}</p></section>`;
  const fw = (c.frameworks || []).map((f) => ({ CP: "Content Patcher", AT: "Alternative Textures", FF: "Furniture Framework", JA: "Json Assets（旧式）", FS: "Fashion Sense", DGA: "DGA（旧式）", CF: "Custom Furniture（旧式）", SMAPI: "SMAPI 插件（代码类）" }[f] || f));
  const fmt = (c.formats || []).length ? ` · CP 格式 ${c.formats.map(esc).join(" / ")}${c.formats.some((f) => (vt(f)[0] || 0) < 2) ? `<span class="old">旧格式</span>` : ""}` : "";
  // 2026-11-22 Hazel：替换原版 / 新增内容 的逐项清单太冗余，只留数量
  const cnt = [["替换", c.replace], ["新增", c.add], ["修改数据", c.edit], ["AT 皮肤", c.skin]].filter(([, l]) => l && l.length).map(([t, l]) => `${t} ${l.length} 项`);
  return `<section><h3>内容</h3>
    <div class="muted small">${[fw.length ? "类型：" + fw.join("、") + fmt : "", ...cnt].filter(Boolean).join(" · ")}</div>
    ${cnt.length ? "" : `<p class="muted small">${(c.frameworks || []).includes("SMAPI") ? "这是代码类插件，改的是游戏逻辑，读不出具体替换了什么。" : "没有读到具体改动。"}</p>`}
  </section>`;
}

// ---------------------------------------------------------- 下载 / 更新
async function ensureNxm() {
  if (state.cfg.nxm || !state.cfg.is_windows) return;
  const ok = await askConfirm("用管理器接管 Nexus 下载？", "免费账号 Nexus不允许程序直接下载，需要你在 Nexus页面点一下下载。\n\n要让 Nexus的「Mod Manager Download / Slow download」按钮直接交给星露管理器吗？这样点完就会自动下载、解压、放进 Mods 文件夹。\n（如果你在用 Vortex，之后可以在设置里还给它）", "好", "primary", null, "不用");
  if (!ok) return;
  await api("/api/nxm/register", { on: true });
  await loadCfg();
}
// 下载非官方版（填了非官方链接的 Nexus Mod）
async function unoffGet(id) {
  try {
    const r = await api(`/api/mods/${id}/unoff-fetch`, {});
    if (r.open) { await ensureNxm(); openExt(r.open, true); toast("在 Nexus点「Slow download」，下好会自动装"); }
    else if (r.page) return unoffManual(id, r.page);
    else dlProgress(id);
    load();
  } catch (err) { if (/^需要手动安装/.test(err.message)) unoffManual(id, allMods().find((x) => x.id === id)?.unofficial_url, err.message.replace(/^需要手动安装：?/, "")); else toast(err.message, 8000); }
}
// 下载进度小弹窗：下到多少、在解压还是装好了；可以点「后台处理」先关掉
function dlProgress(id) {
  let d = $("#dlprog");
  if (!d) { d = document.createElement("dialog"); d.id = "dlprog"; d.className = "modal dlprog"; document.body.appendChild(d); }
  const m = allMods().find((x) => x.id === id) || {};
  d.innerHTML = `<div class="mhead"><h2>下载安装</h2><button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
    <p class="dpname">${esc(title(m))}${m.installed ? `<span class="muted small">　覆盖安装，旧文件先放进备份</span>` : ""}</p>
    <div class="dpbar"><i></i></div>
    <p class="dpmsg muted">开始下载…</p>
    <div class="row end"><button class="primary" id="dpBg">后台处理</button></div>`;
  d.querySelector("[data-close]").onclick = () => d.close();
  $("#dpBg", d).onclick = () => d.close();
  if (!d.open) d.showModal();
  const bar = d.querySelector(".dpbar"), fill = bar.querySelector("i"), msg = d.querySelector(".dpmsg"), btn = $("#dpBg", d);
  let seen = false, t0 = Date.now();
  clearTimeout(dlProgress.t);
  const tick = async () => {
    let r;
    try { r = await api(`/api/mods/${id}/progress`, {}); } catch (e) { dlProgress.t = setTimeout(tick, 1500); return; }
    const st = r.status || "";
    if (st) {
      seen = true;
      msg.textContent = /·/.test(st) ? st : st.replace(/…$/, "") + "…";  // 带速度的不加省略号
      const p = st.match(/(\d+)%/);
      bar.classList.toggle("busy", !p);
      fill.style.width = p ? p[1] + "%" : "";
      if (/解压/.test(st)) { bar.classList.remove("busy"); fill.style.width = "100%"; }
    } else if (r.error) {
      bar.classList.remove("busy"); bar.classList.add("bad"); fill.style.width = "100%";
      if (/^需要手动安装/.test(r.error)) { d.close(); return unoffManual(id, m.unofficial_url, r.error.replace(/^需要手动安装：?/, "")); }
      if (!d.open) toast(`「${title(m)}」没装上：${r.error}`, 8000);
      msg.textContent = r.error; btn.textContent = "关闭";
      const cb = document.createElement("button"); cb.type = "button"; cb.className = "tcopy"; cb.textContent = "复制错误信息"; cb.onclick = () => copyErr(r.error, m); msg.appendChild(cb);
      return;
    } else if (seen || Date.now() - t0 > 4000) {
      bar.classList.remove("busy"); bar.classList.add("ok"); fill.style.width = "100%";
      msg.textContent = (m.installed ? "已覆盖安装" : "装好了") + (r.unofficial && r.unofficial.version ? "：v" + r.unofficial.version : "");
      btn.textContent = "完成"; load();
      if (!d.open) toast(`「${title(m)}」装好了`, 5000);
      return;
    }
    dlProgress.t = setTimeout(tick, 800);
  };
  dlProgress.t = setTimeout(tick, 500);
}
// 不能自动下载的：提示手动安装（网页上下好压缩包，选它或拖进管理器）
function unoffManual(id, url, why = "") {
  const d = $("#files"), m = allMods().find((x) => x.id === id) || {};
  d.innerHTML = `<div class="mhead"><h2>需要手动安装</h2><button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
    <p class="muted">${why ? esc(why) + "。" : "「" + esc(title(m)) + "」的非官方版不能自动下载。"}在网页上下载压缩包，然后选它，或者直接拖进管理器。</p>
    <div class="row end">${url ? `<a class="btn" href="${esc(url)}" target="_blank">打开网页</a>` : ""}<button class="primary" id="umPick">选压缩包</button><input type="file" accept=".zip,.7z,.rar" hidden></div>`;
  if (!d.open) d.showModal();
  $("#umPick", d).onclick = () => $("input[type=file]", d).click();
  $("input[type=file]", d).onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    d.close(); toast("正在安装…");
    try { await api(`/api/mods/${id}/unoff-file`, { name: f.name, data: await readB64(f) }); toast("非官方版装好了"); load(); }
    catch (err) { toast(err.message, 8000); }
  };
}
async function installMod(id, fileId, update = false) {
  const um = allMods().find((x) => x.id === id);
  if (!fileId && um && um.unofficial_url) return unoffGet(id);  // 填了非官方链接：下载、更新都走它
  state.dlPending.set(id, Date.now());
  if (state.cat === NOTINST || state.cat === ISSUE) render();  // 点了就先从「未下载」「下载失败」里拿走
  try {
    const r = await api(`/api/mods/${id}/install`, fileId ? { file_id: fileId } : update ? { update: true } : {});
    if (r.choose) { state.dlPending.delete(id); return openFiles(id, update); }
    if (r.open) {
      await ensureNxm();
      openExt(r.open, true);
    } else toast("开始下载，装好后会自动放进 Mods 文件夹");
    $("#files").close(); load();
  } catch (err) { state.dlPending.delete(id); toast(err.message, 8000); load(); }
}
// ---------------------------------------------------------- 操作（详情页和批量操作栏用同一套按钮、同一套说法）
const AI_ = (d) => `<svg class="ico" viewBox="0 0 24 24" aria-hidden="true">${d}</svg>`;
const ACT_ICON = {
  uninstall: AI_(`<path d="M3 7l9-4 9 4v10l-9 4-9-4z"/><path d="M3 7l9 4 9-4M12 11v10"/>`),
  on: AI_(`<rect x="2" y="7" width="20" height="10" rx="5"/><circle cx="16" cy="12" r="2.5"/>`),
  off: AI_(`<rect x="2" y="7" width="20" height="10" rx="5"/><circle cx="8" cy="12" r="2.5"/>`),
  ignore: AI_(`<path d="M3 3l18 18"/><path d="M10.6 6.1Q11.3 6 12 6c5 0 9 6 9 6a15 15 0 0 1-2.6 3.2M6.6 7.6C4.4 9.1 3 12 3 12s4 6 9 6a8.5 8.5 0 0 0 4-1"/>`),
  unignore: AI_(`<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>`),
  manual: AI_(`<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.8-3.8a6 6 0 0 1-7.9 7.9l-6.9 6.9a2.1 2.1 0 0 1-3-3l6.9-6.9a6 6 0 0 1 7.9-7.9z"/>`),
  remove: AI_(`<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>`),
  track: AI_(`<path d="M6 3h12v18l-6-4-6 4z"/>`),
  search: AI_(`<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>`),
  redo: AI_(`<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>`),
  tag: AI_(`<path d="M3 12V3h9l9 9-9 9z"/><circle cx="7.5" cy="7.5" r="1.5"/>`),
  sliders: AI_(`<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>`),
  folder: AI_(`<path d="M3 6a1 1 0 0 1 1-1h5l2 2h9a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/>`),
  zh: AI_(`<path d="M3 5h10M8 3v2M10.5 5c-1 4-3.5 7-7 9M5.5 9c1.5 2.5 3.5 4 6 5"/><path d="m13 21 4-9 4 9M14.5 18h5"/>`),
};
const abtn = (id, text, { cls = "", dis = "", tip = "" } = {}) =>
  `<button id="${id}" class="abtn ${cls}" ${dis ? `disabled data-why="${esc(dis)}"` : ""} title="${esc(dis || tip)}"><span>${text}</span></button>`;

// 同一大型 Mod 打开共同上级目录；散装组件仍可选择具体文件夹。
function folderBtn(m) {
  const fs = (m.local_folders || []);
  if (m.installed && m.game_parent) return abtn("aFolder", "打开文件夹", { tip: "打开整个 Mod 的文件夹" });
  if (!m.installed || fs.length < 2) return abtn("aFolder", "打开文件夹", { dis: m.installed && fs.length ? "" : "没装在游戏里", tip: "打开它在游戏 Mods 里的文件夹，可以改 config.json" });
  return `<details class="menu up"><summary class="btn abtn" title="它装成了 ${fs.length} 个文件夹，选一个打开"><span>打开文件夹</span></summary><div class="pop">
    ${fs.map((f, i) => `<button data-gopen="${i}"><b>${esc(f.split(/[\\/]/).pop().replace(/^\./, ""))}</b>${f.split(/[\\/]/).pop().startsWith(".") ? "<span>已停用</span>" : ""}</button>`).join("")}</div></details>`;
}
// 详情页底部：按「改的是哪里」分成三组，每个按钮永远在同一个位置，用不了就变灰并说明原因
function actionBar(m) {
  const inst = inGame(m);
  const trk = m.tracked;
  return `<div class="dact foot">
    <div class="agrp"><span class="acap">Nexus</span><div>
      ${abtn("aTrack", m.nexus_id && trk === undefined ? "追踪" : trk ? "追踪中" : "未追踪", { cls: trk ? "on" : "", dis: !m.nexus_id ? "不是 Nexus上的 Mod" : !state.cfg?.nexus_api_key_set ? "先在设置里填 Nexus API Key" : "", tip: trk ? "在你的 Nexus账号里追踪着，点一下取消追踪" : trk === false ? "Nexus上没追踪，点一下追踪" : "点一下在 Nexus追踪它" })}
      ${abtn("aSearch", "找同类", { tip: "按功能在 Nexus上找做同一类事的 Mod" })}
    </div></div>
    <div class="agrp"><span class="acap">游戏里</span><div>
      ${folderBtn(m)}
      ${abtn("aCfg", "改设置", { dis: inGame(m) ? "" : "没装在游戏里", tip: "直接改这个 Mod 的设置（config.json），改完重进游戏生效" })}
      ${abtn("aUninst", uninstalling.has(m.id) ? "正在卸载…" : "卸载", { cls: "danger", dis: uninstalling.has(m.id) ? "正在移动文件到回收站，请稍候" : inst ? "" : "没装在游戏里", tip: "删掉游戏 Mods 文件夹里的它（先放进备份），管理器里留着，变回「未下载」" })}
    </div></div>
    <div class="agrp"><span class="acap">管理器里</span><div>
      ${m.ignored ? abtn("aIgnore", "取消忽略", { cls: "on", tip: "回到列表里" }) : abtn("aIgnore", "忽略", { tip: "不在列表里显示，扫描和导入追踪也不会再加回来；侧栏「已忽略」里找回" })}
      ${abtn("aRemove", "移除…", { cls: "danger", tip: "从管理器里删掉这条记录，可选同时删游戏文件、取消 Nexus追踪" })}
    </div></div>
    <div class="agrp end"><span class="acap">&nbsp;</span><div>
      <details class="menu up"><summary class="btn abtn"><span>重新处理</span></summary><div class="pop">
        ${m.nexus_id ? `<button id="dRefresh"><b>重新抓取</b><span>重读 Nexus 简介、图片、依赖</span></button>` : ""}
        <button id="dAi"><b>重新 AI 处理</b><span>只重做翻译、分类、说明</span></button>
        ${m.nexus_id && m.installed ? `<button id="dFiles"><b>重新下载</b><span>${m.unofficial_url ? "从非官方链接重新下载" : "选个版本重新下载"}</span></button>` : ""}
      </div></details>
    </div></div>
  </div>`;
}

async function runAction(ids, action, extra = {}) {
  const uninstall = action === "uninstall";
  if (uninstall) {
    if (uninstalling.size) throw new Error("正在卸载，请稍候");
    ids.forEach(id => uninstalling.add(id));
  }
  let r;
  try { r = await api("/api/bulk", { ids, action, ...extra }); }
  finally { if (uninstall) uninstalling.clear(); }
  if (r.errors && r.errors.length) toast(r.errors.join("\n"), 9000);
  await load();
  return r;
}

function bindActionBar(m, d) {
  const id = m.id, again = () => openDetail(id, true);
  const un = $("#aUninst", d);
  if (!un.disabled) un.onclick = async () => {
    if (!un.classList.contains("confirm")) {
      un.classList.add("confirm"); un.querySelector("span").textContent = "确定卸载？";
      setTimeout(() => { if (un.isConnected && !un.disabled) { un.classList.remove("confirm"); un.querySelector("span").textContent = "卸载"; } }, 3500);
      return;
    }
    un.classList.remove("confirm"); un.disabled = true; un.querySelector("span").textContent = "正在卸载…";
    try {
      const r = await runAction([id], "uninstall");
      if (r.ok) {
        if (un.isConnected) un.querySelector("span").textContent = "卸载";
        toast("已卸载，游戏文件在「设置 → 回收站」里留 30 天", 6000);
        openUnusedDeps(id);  // load() 已自动刷新详情，不再重复打开一次
      } else if (d.open && state.openId === id) again();
    } catch (err) {
      toast(err.message, 8000);
      if (un.isConnected) { un.disabled = false; un.querySelector("span").textContent = "卸载"; }
      else if (d.open && state.openId === id) again();
    }
  };
  $("#aIgnore", d).onclick = async () => {
    await runAction([id], m.ignored ? "unignore" : "ignore");
    toast(m.ignored ? "已取消忽略，它回到列表里了" : "已忽略，侧栏「已忽略」里能找回");
    again();
  };
  $("#aRemove", d).onclick = () => openRemove([m]);
  const tr = $("#aTrack", d);
  if (!tr.disabled) tr.onclick = async () => {
    const on = !m.tracked;
    tr.disabled = true;
    const r = await runAction([id], on ? "track" : "untrack").catch((err) => { toast(err.message, 7000); return null; });
    if (r && !(r.errors || []).length) toast(on ? "已在 Nexus追踪" : "已在 Nexus取消追踪（管理器里还留着它）");
    setTimeout(again, 1200);
  };
  $("#aSearch", d).onclick = () => openNexusSearch(m);
  const gopen = (i) => api(`/api/mods/${id}/game-open`, { i }).catch((err) => toast(err.message, 6000));
  if ($("#aFolder", d) && !$("#aFolder", d).disabled) $("#aFolder", d).onclick = () => gopen();
  if ($("#aCfg", d) && !$("#aCfg", d).disabled) $("#aCfg", d).onclick = () => openModConfig(m);
  d.querySelectorAll("[data-gopen]").forEach((b) => (b.onclick = () => { b.closest("details").removeAttribute("open"); gopen(+b.dataset.gopen); }));
  const closeMenu = () => d.querySelectorAll("details.menu[open]").forEach((x) => x.removeAttribute("open"));
  const rerun = (kind, body = {}) => api(`/api/mods/${id}/${kind}`, body).then(() => { toast("已加入处理队列"); load(); });
  if ($("#dRefresh", d)) $("#dRefresh", d).onclick = () => { closeMenu(); rerun("refresh"); };
  if ($("#dFiles", d)) $("#dFiles", d).onclick = () => { closeMenu(); m.unofficial_url ? unoffGet(id) : openFiles(id); };
  $("#dAi", d).onclick = () => { closeMenu(); rerun("ai"); };
}

// 移除：单个和批量共用。默认只删管理器里的记录
function openRemove(list) {
  const d = $("#files");
  const inst = list.filter(inGame).length;
  const nx = list.filter((m) => m.nexus_id).length;
  const one = list.length === 1;
  d.innerHTML = `<div class="mhead"><h2>移除${one ? `「${esc(title(list[0]))}」` : ` ${list.length} 个 Mod`}</h2><button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
    <p>从管理器里删掉${one ? "这条" : "这些"}记录，备注也会一起删掉。</p>
    ${inst ? `<label class="chk-line"><input type="checkbox" id="rmFiles" checked> 同时删掉游戏里的文件${one ? "" : `（其中 ${inst} 个装着）`}<span class="muted small">　先放进回收站，30 天内能恢复</span></label>` : ""}
    ${nx ? `<label class="chk-line"><input type="checkbox" id="rmUntrack" checked> 同时在 Nexus取消追踪${one ? "" : `（${nx} 个）`}</label>` : ""}
    ${inst ? `<p class="muted small" id="rmHint">不删游戏文件的 Mod 将改为「忽略」，可在「已忽略」中找回。</p>` : `<p class="muted small">只是不想看到它的话，用「忽略」更合适，随时能找回。</p>`}
    <div class="row end"><button data-close>取消</button><button class="primary danger-fill" id="rmGo">移除</button></div>`;
  if (!d.open) d.showModal();
  $("#rmGo", d).onclick = async () => {
    const files = !!($("#rmFiles", d) || {}).checked, untrack = !!($("#rmUntrack", d) || {}).checked;
    $("#rmGo", d).disabled = true;
    const r = await runAction(list.map((m) => m.id), files ? "all" : "remove", { untrack }).catch((err) => toast(err.message, 7000));
    d.close();
    if (!r) return;
    const ign = files ? 0 : inst, bad = (r.errors || []).length;  // 有失败的：按实际结果说，不说「全部放进回收站」（GPT 查出，11-24）
    const okMsg = (r.ok - ign > 0 ? `已移除 ${r.ok - ign} 个` : "") + (ign ? `${r.ok - ign > 0 ? "，" : ""}${ign} 个已改为忽略` : "")
      + (files && r.ok > 0 ? "，游戏文件已放进回收站" : "") + (untrack && nx && r.ok > 0 ? "，Nexus 已取消追踪" : "");
    toast(bad ? `${okMsg ? okMsg + "；" : ""}${bad} 个没处理成功：${r.errors.join("；")}` : okMsg, bad ? 10000 : 6000);
    if ($("#detail").open && list.some((m) => m.id === state.openId)) $("#detail").close();
    state.sel.clear(); render();
  };
}

// AI 找 Mod：从详情页「找同类」（按这个 Mod 做的事找）或主界面搜索框的 AI 按钮（按你的描述找）进来。
// AI 先把意思变成搜索词，再在你的列表里和 Nexus上找；Nexus的简介默认翻成中文
const openNexusSearch = (m, opts = {}) => openFinder({ mod: m, ...opts });
state.trOn = true;
async function openFinder(src = {}) {
  const d = $("#similar"), m = src.mod;
  const X = `<button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button>`;
  const head = `<div class="mhead"><h2>${m ? "找同类：" + esc(title(m)) : "AI 找 Mod"}</h2>${X}</div>`;
  const ask = m ? "" : `<div class="row"><input id="fdText" value="${esc(src.text || "")}" style="flex:1" placeholder="说说想要什么样的 Mod，比如：坐下能恢复体力；也能填 Nexus 编号、尾号或链接"><button class="primary" id="fdGo">${ACT_ICON.search}找</button></div>`;
  if (!d.open) d.showModal();
  const bindAsk = () => {
    if (!$("#fdGo", d)) return;
    $("#fdGo", d).onclick = () => { const t = $("#fdText", d).value.trim(); if (t) openFinder({ text: t }); };
    $("#fdText", d).onkeydown = (e) => { if (e.key === "Enter") $("#fdGo", d).click(); };
  };
  if (!m && !src.text && !src.keywords) {
    d.innerHTML = head + ask + `<p class="muted small">AI 会把你的描述变成搜索词，先在你自己的列表里找，再去 Nexus上找（每次几百 token，同样的描述第二次不再花）。</p>`;
    bindAsk(); setTimeout(() => $("#fdText", d).focus(), 50); return;
  }
  d.innerHTML = head + ask + `<p class="muted"><span class="spin"></span>${src.keywords || (m && m.similar_kw && !src.refresh) ? "正在搜…" : "AI 正在理解你要找什么，然后去搜…"}</p>`;
  bindAsk();
  let r;
  try {
    const off = src.offset || 0;
    r = m ? await api(`/api/mods/${m.id}/similar`, { keywords: src.keywords, refresh: src.refresh, offset: off })
      : await api("/api/find", { text: src.text, keywords: src.keywords, zh_terms: src.zh_terms, refresh: src.refresh, offset: off, avoid: src.avoid });
  } catch (err) {
    d.innerHTML = head + ask + `<p class="er">${esc(err.message)}</p>`; bindAsk(); return;
  }
  if (m) m.similar_kw = r.keywords;
  const byId = r.by_id;  // 输入的是尾号 / 编号 / 链接：列表里按编号和尾号对，Nexus 上只查这一个
  if (byId) {
    const tl = (x) => (x.source_url || x.url || "").split(/[?#]/)[0].replace(/\/+$/, "").split("/").pop().toLowerCase();
    r.idLocal = allMods().filter((x) => (byId.nexus && +x.nexus_id === byId.nexus) || (byId.tail && tl(x) === String(byId.tail).toLowerCase()));
  }
  // 你自己列表里的（按 AI 给的中英文关键词在名字、简介、备注里找）
  let local = [], scored = [], cand = [];
  if (byId) local = r.idLocal;
  else if (!src.offset) {  // 找同类也要先看你自己的列表
    // 用你输入的原词 + AI 给的中英文关键词去匹配。英文按整词算（免得 ai 匹配到 rain）。
    // 中文名和中文简介最可靠，分数高；英文名、英文简介常写着「用 AI 辅助制作」之类的话，只给 1 分，单靠它们进不了结果
    const mk = (t) => {
      t = t.toLowerCase().trim();
      if (!/[a-z0-9]/.test(t)) return (x) => x.includes(t);
      const re = new RegExp("(?<![a-z0-9])" + t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\s+/g, "\\s+") + "(?![a-z0-9])");
      return (x) => re.test(x);
    };
    const own = (src.text || "").split(/[\s,，、。;；]+/).filter((t) => t.length > 1 || /[^\x00-\x7f]/.test(t));
    const terms = [...own.map((t) => [mk(t), 4, 3]), ...[...(r.zh_terms || []), ...r.keywords.flatMap((k) => k.split(/[\s+]+/).filter(Boolean))].filter((t) => t.length > 1).map((t) => [mk(t), 3, 2])];
    scored = allMods().filter((x) => !m || x.id !== m.id).map((x) => {
      const zhN = (x.name_zh || "").toLowerCase(), zhS = [x.summary_zh, x.note].join(" ").toLowerCase();
      const en = [x.name, x.summary].join(" ").toLowerCase(), guide = (x.guide_zh || "").toLowerCase();
      const noZh = !zhN && !x.summary_zh;
      let n = 0;
      for (const [f, wn, ws] of terms) n += f(zhN) ? wn : f(zhS) ? ws : f(en) ? (noZh ? ws : 1) : f(guide) ? 1 : 0;
      return [x, n];
    });
    local = scored.filter(([, n]) => n >= 2).sort((a, b) => b[1] - a[1]).slice(0, 20).map(([x]) => x);
    // 交给 AI 核对的候选：关键词沾边的 + 中文简介和「要找的是」那句话字面最像的（两字词按稀有程度加分）
    const grams = (t) => { const o = new Set(); for (const w of (t || "").toLowerCase().match(/[a-z0-9]{2,}|[\u4e00-\u9fff]+/g) || []) { if (/^[a-z0-9]/.test(w)) o.add(w); else for (let i = 0; i < w.length - 1; i++) o.add(w.slice(i, i + 2)); } return o; };
    const docs = scored.map(([x]) => grams((x.name_zh || "") + " " + (x.summary_zh || ""))), df = new Map();
    docs.forEach((g) => g.forEach((b) => df.set(b, (df.get(b) || 0) + 1)));
    const qg = [...grams([src.text, r.zh, ...(r.zh_terms || [])].join(" "))].filter((b) => df.get(b) && df.get(b) < docs.length / 8);
    const sim = docs.map((g, i) => [i, qg.reduce((a, b) => a + (g.has(b) ? Math.log(docs.length / df.get(b)) : 0), 0)]).filter(([, v]) => v > 0).sort((a, b) => b[1] - a[1]).slice(0, 25);
    cand = [...new Set([...scored.filter(([, n]) => n >= 1).sort((a, b) => b[1] - a[1]).slice(0, 35).map(([x]) => x.id), ...sim.map(([i]) => scored[i][0].id)])];
  }
  const fmt = (n) => n >= 10000 ? (n / 10000).toFixed(1).replace(/\.0$/, "") + " 万" : String(n);
  const row = (x, i) => `<div class="simrow">
      ${x.thumb ? `<img src="${esc(x.thumb)}" alt="" loading="lazy">` : `<div class="ph"></div>`}
      <div class="simtxt"><a href="${esc(x.url)}" target="_blank"><b data-nm="${i}">${esc(x.name)}</b></a><span class="muted small" data-nmen="${i}"></span><span class="muted small"> · ${esc(x.author)} · 赞 ${fmt(x.endorsements)} · 下载 ${fmt(x.downloads)}${x.updated ? " · 最近更新 " + esc(String(x.updated).slice(0, 10)) : ""}</span>
        <div class="small simsum" data-sum="${i}">${esc(x.summary)}</div></div>
      <div class="simact">${x.lib_id ? `<a href="#" class="small" data-simopen="${x.lib_id}">已在列表</a>` : `<button class="small-btn" data-simadd="${esc(x.url)}">＋加入</button>`}</div>
    </div>`;
  // AI 按简介挑过的放上面，其余收起来（关键词碰巧对上、但功能不对的都在里面）
  const ranked = r.results.some((x) => x.fit !== undefined), step = r.step || 30;
  const fits = [], rest = [];
  r.results.forEach((x, i) => { const h = row(x, i); (ranked && !x.fit ? rest : fits).push(h); });
  const lrow = (x) => `<div class="simrow local" data-simopen="${x.id}">${thumb(x, "lthumb")}<div class="simtxt"><b>${esc(title(x))}</b><span class="muted small"> · ${esc(catLabel(x))}</span><div class="small simsum">${esc((x.summary_zh || x.summary || "").slice(0, 80))}</div></div><div class="simact">${lifeHtml(x)}</div></div>`;
  const aiLocal = !src.offset && cand.length && state.cfg?.ai_api_key_set;
  const localHtml = (list, note = "") => `<h4 class="simh">你的列表里（${list.length}）${note}</h4>${list.length ? list.map(lrow).join("") : `<p class="muted small">没找到。</p>`}`;
  d.innerHTML = head + ask + `
    ${r.zh ? `<p class="muted small">${m ? "它属于" : "要找的是"}：${esc(r.zh)}</p>` : ""}
    ${byId ? `<p class="muted small">按${[byId.nexus ? "Nexus 编号 " + byId.nexus : "", byId.tail ? "Naver 尾号 " + esc(byId.tail) : ""].filter(Boolean).join("、")}找，不用 AI。</p>` : ""}
    <div class="row${byId ? " hidden" : ""}"><label class="search simsearch"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><input id="simKw" value="${esc(r.keywords.join(", "))}" placeholder="物品 类型，比如 sprinkler retexture，多个用逗号分开"><button id="simAi" class="aibtn" type="button" title="让 AI 重新想一批不同的关键词">AI</button></label><button id="simGo">搜索</button></div>
    ${byId ? "" : `<p class="muted small">按「物品 类型」搜 Nexus 上的 Mod 名字，可以直接改了再搜；点框里的 AI 换一批。</p>`}
    ${r.error ? `<p class="er">${esc(r.error)}</p>` : ""}
    <div class="simlist">
      ${!src.offset ? `<div id="simLocal">${localHtml(local, aiLocal ? `<span class="muted small" style="font-weight:400"><span class="spin"></span>AI 正在看简介核对…</span>` : "")}</div><h4 class="simh">Nexus上</h4>` : ""}
      ${fits.length ? fits.join("") : `<p class="muted small">${r.error ? "" : rest.length ? "AI 看了这批的简介，没有真正符合的。" : (byId ? (byId.nexus ? "Nexus 上没有这个编号的 Mod。" : "Naver 尾号只在你自己的列表里找。") : "没搜到，换几个搜索词试试。")}</p>`}
      ${rest.length ? `<details class="simrest"${fits.length ? "" : " open"}><summary class="muted small">${ranked ? `其余 ${rest.length} 个看简介不太相关` : `另外 ${rest.length} 个`}</summary>${rest.join("")}</details>` : ""}
    </div>
    <div class="row end">
      <span class="muted small" style="margin-right:auto">${r.total ? `Nexus检索到 ${r.total} 个候选，这批 ${r.results.length} 个${ranked ? `里 AI 看简介挑出 ${fits.length} 个` : ""}` : ""}</span>
      ${src.offset ? `<button id="simPrev">上一批</button>` : ""}
      ${(src.offset || 0) + step < r.total ? `<button id="simNext">下一批</button>` : ""}
      ${r.results.length ? `<span id="simTrNote" class="muted small"><span class="spin"></span>正在翻译简介…</span><button id="simTr" style="display:none">切换回英文</button>` : ""}
      <button id="simWeb">去 Nexus看更多</button>
    </div>`;
  bindAsk();
  const bindOpen = (root) => root.querySelectorAll("[data-simopen]").forEach((a) => (a.onclick = (e) => { if (e.target.closest("button")) return; e.preventDefault(); d.close(); openDetail(+a.dataset.simopen); }));
  if (aiLocal) {
    api("/api/find-local", { goal: r.zh || src.text, ids: cand }).then((j) => {
      const box = $("#simLocal", d);
      if (!box || !Array.isArray(j.ids)) return;
      const byId = new Map(allMods().map((x) => [x.id, x]));
      const list = j.ids.map((i) => byId.get(i)).filter(Boolean);
      box.innerHTML = localHtml(list, `<span class="muted small" style="font-weight:400"> · AI 看简介挑过</span>`);
      bindOpen(box);
    }).catch(() => { const n = $("#simLocal .simh .spin", d); if (n) n.parentNode.textContent = " · AI 核对没成功，先按关键词显示"; });
  }
  const kws = () => $("#simKw", d).value.split(/[,，]/).map((x) => x.trim()).filter(Boolean);
  const again = (o) => openFinder(m ? { mod: m, ...o } : { text: src.text, zh_terms: r.zh_terms, ...o });
  $("#simGo", d).onclick = () => { const k = kws(); if (k.length) again({ keywords: k }); };
  $("#simKw", d).onkeydown = (e) => { if (e.key === "Enter") $("#simGo", d).click(); };
  $("#simAi", d).onclick = (e) => { e.preventDefault(); e.stopPropagation(); openFinder(m ? { mod: m, refresh: true } : { text: src.text, refresh: true, avoid: r.keywords }); };
  const page = (o) => openFinder(m ? { mod: m, keywords: r.keywords, offset: o } : { text: src.text, keywords: r.keywords, zh_terms: r.zh_terms, offset: o });
  if ($("#simNext", d)) $("#simNext", d).onclick = () => page((src.offset || 0) + step);
  if ($("#simPrev", d)) $("#simPrev", d).onclick = () => page(Math.max(0, (src.offset || 0) - step));
  $("#simWeb", d).onclick = () => openExt(byId?.nexus ? `https://www.nexusmods.com/stardewvalley/mods/${byId.nexus}` : `https://www.nexusmods.com/games/stardewvalley/mods?keyword=${encodeURIComponent(kws()[0] || "")}&sort=endorsements`);
  if (byId) { $("#simWeb", d).textContent = "去 Nexus 打开"; $("#simWeb", d).classList.toggle("hidden", !byId.nexus); }
  bindOpen(d);
  d.querySelectorAll("[data-simadd]").forEach((b) => (b.onclick = async () => {
    b.disabled = true;
    try {
      const x = await api("/api/batch", { text: b.dataset.simadd });
      b.outerHTML = `<span class="small okk">${x.added ? "已加入" : "已在列表"}</span>`;
      load();
    } catch (err) { toast(err.message, 6000); b.disabled = false; }
  }));
  // 简介默认翻成中文（翻过的会记住），按钮切回英文
  const tb = $("#simTr", d);
  if (!tb) return;
  const en = r.results.map((x) => x.summary), names = r.results.map((x) => x.name), N = names.length;
  let zh = null;
  const show = () => {
    d.querySelectorAll("[data-sum]").forEach((el) => { const i = +el.dataset.sum; el.textContent = state.trOn && zh && zh[i] ? zh[i] : en[i]; });
    d.querySelectorAll("[data-nm]").forEach((el) => {
      const i = +el.dataset.nm, z = zh && zh[N + i], on = state.trOn && z && z !== names[i];
      el.textContent = on ? z : names[i];
      const sub = d.querySelector(`[data-nmen="${i}"]`); if (sub) sub.textContent = on ? " " + names[i] : "";
    });
    tb.textContent = state.trOn ? "切换回英文" : "切换成中文";
  };
  const note = $("#simTrNote", d);
  tb.onclick = () => { state.trOn = !state.trOn; show(); };
  if ((state.cfg?.translator || "microsoft") === "ai" && !state.cfg?.ai_api_key_set && !state.cfg?.translate_fallback) { note.textContent = "AI 没设置，显示英文"; note.title = "设置里填好 AI，或者调整翻译顺序"; return; }
  try {
    const res = await fetch("/api/translate-list", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ items: [...r.results.map((x) => ({ id: x.nexus_id, text: x.summary })), ...r.results.map((x) => ({ id: "n" + x.nexus_id, text: x.name }))] }) });
    const j = await res.json();
    if (!res.ok) throw new Error(j.error || "翻译失败");
    zh = j.zh;
    if (!tb.isConnected) return;
    const want = state.cfg?.translator || "microsoft", NAME = { microsoft: "微软翻译", google: "谷歌翻译", ai: "AI" };
    if (j.used && j.used !== want) toast(`${NAME[want]}没及时回应，这次用了${NAME[j.used]}`, 5000);
    note.remove(); tb.style.display = ""; show();
  } catch (err) {
    if (note.isConnected) { note.textContent = "没翻译成，显示英文"; note.title = err.message + "\n可以在设置里换一种翻译方式"; }
  }
}

// 识别规则：名字 / 文件夹名 / 包里说明里有某个词 → 认成某个来源；名字里要去掉的词。存在设置里，导入时服务器按它认
function rulesEditor(box, after) {
  const cur = state.cfg.import_rules || { src: [], strip: [] };
  const rules = cur.src.map((x) => ({ ...x }));
  const srcBtns = (v) => Object.entries(SOURCES).map(([k, t]) => `<button type="button" data-src="${k}" class="${k === v ? "on" : ""}">${t}</button>`).join("");
  const draw = () => {
    box.innerHTML = `<p class="muted small">导入时，文件名、文件夹名或包里的说明文字里出现这个词，就认成对应来源。从上往下，先对上的算；都没对上，再看有没有 Naver 链接、韩文。</p>
      <div class="rl-list">${rules.map((x, i) => `<div class="rl-row" data-i="${i}"><input data-kw value="${esc(x.kw)}" placeholder="词，比如 私享"><span class="muted">→</span><span class="segsw">${srcBtns(x.src)}</span><button class="x" data-rldel title="删掉这条" aria-label="删掉"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>`).join("")}</div>
      <button class="mini" id="rlAdd" type="button">＋ 加一条</button>
      <label>名字里要去掉的词<input id="rlStrip" value="${esc((cur.strip || []).join("，"))}" placeholder="用逗号分开，比如：[스타듀]，合并发"></label>
      <div class="row end"><span class="small muted" id="rlMsg" style="margin-right:auto"></span><button class="primary mini" id="rlSave" type="button">保存并重新识别</button></div>`;
    box.querySelectorAll(".rl-row").forEach((row) => {
      const x = rules[+row.dataset.i];
      $("[data-kw]", row).oninput = (e) => { x.kw = e.target.value; };
      row.querySelectorAll(".segsw button").forEach((b) => (b.onclick = () => { x.src = b.dataset.src; row.querySelectorAll(".segsw button").forEach((y) => y.classList.toggle("on", y === b)); }));
      $("[data-rldel]", row).onclick = () => { rules.splice(+row.dataset.i, 1); draw(); };
    });
    $("#rlAdd", box).onclick = () => { rules.push({ kw: "", src: "gift" }); draw(); box.querySelector(".rl-row:last-child [data-kw]").focus(); };
    $("#rlSave", box).onclick = async () => {
      const body = { src: rules.filter((x) => x.kw.trim()), strip: $("#rlStrip", box).value.split(/[,，、\n]+/).map((w) => w.trim()).filter(Boolean) };
      try {
        await api("/api/config", { import_rules: body });
        await loadCfg();
        cur.src = state.cfg.import_rules.src; cur.strip = state.cfg.import_rules.strip;
        $("#rlMsg", box).textContent = "已保存";
        after && after();
      } catch (err) { toast(err.message, 6000); }
    };
  };
  draw();
}

// 批量导入：一次拖进多个压缩包 / 文件夹，逐个自动识别，列成表确认后一起导入
// ---------------------------------------------------------- 合集：一批 Mod 存成一组，一键启用 / 单独启用 / 停用
const AUTO_PACK = "切换前的状态";
// 存合集：传一个「拿现在的合集算出新合集」的函数。一次只存一个；别处刚改过就按最新的再算一次（GPT 查出，11-24）
let packsQ = Promise.resolve();
function savePacks(fn) {
  const run = async () => {
    for (let k = 0; k < 3; k++) {
      const prev = state.packs || [];
      const r = await api("/api/packs", { packs: fn(prev), prev });
      if (!r.conflict) { state.packs = r; render(); return r; }
      state.packs = r.packs;
    }
    throw new Error("合集没存上，请再试一次");
  };
  const p = packsQ.then(run, run);
  packsQ = p.catch(() => {});
  return p;
}
async function addToPack(name, ids) {
  const p = state.packs.find((x) => x.name === name);
  if (!p) return;
  const before = p.ids.length;
  await savePacks((ps) => ps.map((x) => (x.name === name ? { ...x, ids: [...new Set([...x.ids, ...ids])] } : x)));
  toast(`已加入「${name}」${state.packs.find((x) => x.name === name).ids.length - before} 个`);
}
async function removeFromPack(name, ids) {
  await savePacks((ps) => ps.map((x) => (x.name === name ? { ...x, ids: x.ids.filter((i) => !ids.includes(i)) } : x)));
}
function openPackNew(ids) {
  const d = $("#files"), onNow = state.mods.filter((m) => m.installed && !m.disabled).length;
  d.innerHTML = `<div class="mhead"><h2>新建合集</h2><button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
    <p class="muted small">把想一起玩的 Mod 存成一个合集，比如「魔法包」「童话包」。之后在侧栏点开它，一键启用；需要的前置会自动带上。</p>
    <label>名字<input id="pkName" placeholder="比如：魔法包"></label>
    ${ids.length ? `<p class="small">会放进刚才选的 ${ids.length} 个 Mod。</p>` : `<label class="chk-line" style="margin-top:12px"><input type="checkbox" id="pkCur"> 把现在已启用的 ${onNow} 个 Mod 放进去</label><p class="muted small">不勾的话先建个空合集，之后在 Mod 详情页或「批量操作」里加进来。</p>`}
    <div class="row end"><button data-close>取消</button><button class="primary" id="pkGo">新建</button></div>`;
  if (!d.open) d.showModal();
  setTimeout(() => $("#pkName", d).focus(), 50);
  $("#pkName", d).onkeydown = (e) => { if (e.key === "Enter") $("#pkGo", d).click(); };
  $("#pkGo", d).onclick = async () => {
    const name = $("#pkName", d).value.trim();
    if (!name) return toast("先起个名字");
    if (state.packs.some((p) => p.name === name)) return toast("已经有同名合集了");
    const pick = ids.length ? ids : ($("#pkCur", d) || {}).checked ? state.mods.filter((m) => m.installed && !m.disabled).map((m) => m.id) : [];
    await savePacks((ps) => [...ps.filter((p) => !p.auto), { name, ids: pick }, ...ps.filter((p) => p.auto)]);
    d.close(); state.multi = []; state.cat = PACK; state.pack = name; state.sub = ""; render();
    toast(`已新建合集「${name}」` + (pick.length ? `，放进了 ${pick.length} 个 Mod` : ""));
  };
}
async function applyPack(name, mode) {
  if (mode === "only" && !(curPack() || {}).auto && !(await askConfirm(`单独启用「${name}」？`, `启用合集里的 Mod 和它们需要的前置，其他不在合集里的 Mod 都停用（前置框架不动）。\n\n现在的启用状态会先存成「${AUTO_PACK}」，随时能一键切回来。`, "单独启用", "primary"))) return;
  let r;
  try { r = await api("/api/packs/apply", { name, mode }); } catch (err) { return toast(err.message, 7000); }
  const msg = [];
  if (r.on) msg.push(`启用了 ${r.on} 个`);
  if (r.off) msg.push(`停用了 ${r.off} 个`);
  if (!r.on && !r.off) msg.push(mode === "off" ? "合集里的 Mod 本来就是停用的" : "合集里的 Mod 本来就都启用着");
  if (r.deps.length) msg.push(`自动带上前置：${r.deps.slice(0, 5).join("、")}${r.deps.length > 5 ? ` 等 ${r.deps.length} 个` : ""}`);
  if (r.missing.length && mode !== "off") msg.push(`还没下载 ${r.missing.length} 个：${r.missing.slice(0, 3).join("、")}${r.missing.length > 3 ? "…" : ""}`);
  if (r.errors.length) msg.push("出错：" + r.errors.slice(0, 3).join("；"));
  toast(msg.join("；") + (r.on || r.off ? "。下次进游戏生效" : ""), 9000);
  await load();
}

function openBatchImport(items = []) {
  const d = $("#files");
  d.classList.add("wide");
  d.addEventListener("close", () => d.classList.remove("wide"), { once: true });
  d.innerHTML = `<div class="mhead"><h2>导入非 Nexus Mod</h2><button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
    <p class="muted small">Naver、自制、私享等，可直接拖入压缩包或文件夹。管理器只记录，不查更新、不自动下载。拖进来的会自动认出名字、来源和链接，不对的直接在表里改。已装进 Mods 文件夹的，点「刷新 Mod 状态」后在详情选来源。</p>
    <details class="birules"><summary>识别规则</summary><div id="biRules"></div></details>
    ${DROP_ZONE}
    <div class="bimp" id="biList"></div>
    <a href="#" class="small" id="biBlank">没有文件，只记一条</a>
    <div class="row end bifoot"><label class="chk-line"><input type="checkbox" id="biInst" checked> 存好后直接装到游戏里</label><span id="biSum" class="muted small"></span><button data-close>取消</button><button class="primary" id="biGo" disabled>全部导入</button></div>`;
  if (!d.open) d.showModal();
  const rows = [], list = $("#biList", d), names = new Set(allMods().flatMap((x) => [x.name, x.name_zh].filter(Boolean).map((n) => n.trim().toLowerCase())));
  let queue = Promise.resolve(), busy = false;
  const ok = (r) => r.on && r.name.value.trim() && (r.src !== "naver" || normNaver(r.url.value));
  const sum = () => {
    const live = rows.filter((r) => !r.done), sel = live.filter((r) => r.on), good = sel.filter(ok), wait = live.filter((r) => r.wait).length;
    $("#biSum", d).textContent = !rows.length ? "" : wait ? `正在识别，还剩 ${wait} 个…` : sel.length > good.length ? `${sel.length - good.length} 个缺名字或 Naver 链接，补上才会导入` : "";
    $("#biGo", d).disabled = busy || wait > 0 || !good.length;
    $("#biGo", d).textContent = good.length ? `导入 ${good.length} 个` + (sel.length > good.length ? `，跳过 ${sel.length - good.length} 个` : "") : "全部导入";
  };
  const add = (it) => {
    const el = document.createElement("div");
    el.className = "birow";
    el.innerHTML = `<input type="checkbox" data-on checked title="勾上的才导入">
      <div class="bimain"><input data-name placeholder="名字（必填）"><div class="small muted bifile">${it ? esc(itemDesc(it)) : "没有文件，只记一条"}</div><div class="small binote"></div></div>
      <div class="bisrc"><span class="segsw">${Object.entries(SOURCES).map(([k, v]) => `<button type="button" data-src="${k}">${v}</button>`).join("")}</span>
        <input data-url placeholder="Naver 链接或尾号"><div class="small biurl"></div></div>
      <button class="x" data-rm title="不导入这个" aria-label="移除"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button>`;
    list.appendChild(el);
    const r = { it, el, on: true, wait: !!it, src: "naver", token: "", author: "", name: $("[data-name]", el), url: $("[data-url]", el), note: $(".binote", el) };
    rows.push(r);
    const paint = () => {
      el.querySelectorAll(".segsw button").forEach((b) => b.classList.toggle("on", b.dataset.src === r.src));
      const v = r.url.value.trim(), nav = r.src === "naver", bad = nav && !normNaver(v);
      r.url.placeholder = nav ? "Naver 链接或尾号（必填）" : "来源链接（可留空）";
      r.url.classList.toggle("bad", r.on && bad && !r.wait);
      $(".biurl", el).textContent = nav && v && !bad ? (normNaver(v) === v ? "" : "会记成 " + normNaver(v)) : nav && v ? "格式不对，填完整链接或尾号" : "";
      $(".biurl", el).className = "small biurl " + (nav && v && bad ? "er" : "muted");
      r.name.classList.toggle("bad", r.on && !r.wait && !r.name.value.trim());
      el.classList.toggle("off", !r.on);
      sum();
    };
    r.paint = paint;
    el.querySelectorAll(".segsw button").forEach((b) => (b.onclick = () => { r.src = b.dataset.src; paint(); }));
    r.url.oninput = paint; r.name.oninput = paint;
    $("[data-on]", el).onchange = (e) => { r.on = e.target.checked; paint(); };
    $("[data-rm]", el).onclick = () => { el.remove(); rows.splice(rows.indexOf(r), 1); sum(); };
    paint();
    r.inspect = () => {
      if (!it) return;
      r.wait = true; r.note.className = "small binote muted"; r.note.innerHTML = `<span class="spin"></span>正在识别…`; paint();
      queue = queue.then(async () => {
      try {
        const g = await api("/api/lib-inspect", await itemBody(it));
        r.token = g.token; r.author = g.author || "";
        if (g.name) r.name.value = g.name;
        r.src = g.source || (g.url ? "naver" : "other");
        if (g.url) r.url.value = g.url;
        const bits = [];
        if (g.found.length) bits.push(`依据：${g.found.slice(0, 4).map(esc).join("、")}`);
        let warn = "";
        r.unoff = g.unoff_for || null;
        if (r.unoff) { r.name.value = r.unoff.name; r.src = "other"; r.url.value = ""; }
        if (r.unoff) bits.length = 0;
        else if (g.nexus_id) warn = `manifest 里写着 Nexus编号 ${g.nexus_id}，是 Nexus上的 Mod，建议用「粘贴链接」加（能查更新），默认不导入`;
        else if (names.has((g.name || "").trim().toLowerCase())) warn = "列表里已经有同名的 Mod，默认不导入";
        if (warn) { r.on = false; $("[data-on]", el).checked = false; }
        r.note.className = "small binote " + (warn ? "er" : "muted");
        if (!g.source && !g.url) bits.unshift("没认出来源，先记成「其他」");
        r.note.innerHTML = r.unoff ? `是「${esc(r.unoff.name)}」的非官方版，导入后替换原版` : warn ? esc(warn) : bits.join(" · ") || "没认出什么，手动填一下";
      } catch (err) { r.note.className = "small binote er"; r.note.textContent = "识别失败：" + err.message + "（照样可以导入）"; }
      r.wait = false; paint();
      });
    };
    if (it) r.inspect(); else { r.wait = false; paint(); r.name.focus(); }
    return r;
  };
  const addAll = (its) => { its.forEach(add); sum(); };
  $("#biBlank", d).onclick = (e) => { e.preventDefault(); add(null); sum(); };
  rulesEditor($("#biRules", d), () => rows.filter((r) => !r.done).forEach((r) => r.inspect()));
  bindDrop(d, addAll);
  addAll(items);
  const importedIds = [];
  $("#biGo", d).onclick = async () => {
    busy = true; sum();
    const inst = $("#biInst", d).checked, todo = rows.filter((r) => !r.done && ok(r));
    let done = 0, fail = 0, instFail = 0, lastId = 0;
    for (const r of todo) {
      r.note.className = "small binote muted"; r.note.innerHTML = `<span class="spin"></span>正在导入…`;
      try {
        if (r.unoff) {
          await api(`/api/mods/${r.unoff.id}/unoff-file`, r.token ? { token: r.token } : await itemBody(r.it));
          r.note.className = "small binote okk"; r.note.textContent = "非官方版装好了";
          lastId = r.unoff.id; r.done = true; r.el.classList.add("done"); r.el.querySelectorAll("input,button").forEach((x) => (x.disabled = true));
          done++; continue;
        }
        const m = r.made || await api("/api/add-manual", { source: r.src, name: r.name.value, url: r.url.value, author: r.author });
        r.made = m;  // 记录建好了、文件没进库：重试时接着用这条，不再建一条（GPT 查出，11-24）
        if (!m.nexus_id && r.it) {
          await api(`/api/mods/${m.id}/lib-import`, r.token ? { token: r.token } : await itemBody(r.it));
          if (inst) { try { await api(`/api/mods/${m.id}/lib-install`, {}); } catch (err) { instFail++; r.note.className = "small binote er"; r.note.textContent = "存进库了，但没装上：" + err.message; } }
        }
        if (!r.note.classList.contains("er")) { r.note.className = "small binote okk"; r.note.textContent = m.nexus_id ? "是 Nexus的链接，已按 Nexus Mod 加入" : !r.it ? "已记下" : inst ? "已导入并装好" : "已导入"; }
        if (!m.nexus_id) importedIds.push(m.id);
        lastId = m.id; r.done = true; r.el.classList.add("done"); r.el.querySelectorAll("input,button").forEach((x) => (x.disabled = true));
        done++;
      } catch (err) { fail++; r.note.className = "small binote er"; r.note.textContent = "没导入：" + err.message; }
    }
    busy = false; sum();
    await load();
    toast(`导入了 ${done} 个${fail ? `，${fail} 个失败（看表里红字）` : ""}${instFail ? `，${instFail} 个没装上` : ""}`, fail || instFail ? 8000 : 4000);
    if (!fail && !instFail && !rows.some((r) => !r.done && r.on)) { d.close(); importDetails.push(...new Set(importedIds)); if (importDetails.length) openDetail(importDetails.shift()); else if (done === 1) openDetail(lastId); }
  };
}

// 换封面：从 Nexus图库 / 说明里的图挑一张，或者用电脑里的图片
async function openCollage(id, pick) {
  const d = $("#files");
  d.innerHTML = `<div class="mhead"><h2>素材拼图</h2><button class="x" data-close aria-label="关闭">×</button></div>
    <p class="muted small" id="collageStatus">正在查找素材…</p>
    <canvas id="collageCanvas" width="1200" height="750" class="hidden" style="display:block;width:100%;height:auto;background:#fff;border:1px solid var(--line);border-radius:8px"></canvas>
    <div class="row end"><button id="collageBack">返回</button><button class="primary" id="collageSave" disabled>设为封面</button></div>`;
  const canvas = $("#collageCanvas", d), status = $("#collageStatus", d), save = $("#collageSave", d);
  const release = () => { canvas.width = 0; canvas.height = 0; canvas.remove(); };
  d.addEventListener("close", release, { once: true });
  $("#collageBack", d).onclick = () => { release(); openCovers(id); };
  const alive = () => d.open && canvas.isConnected;
  try {
    const { assets, limited } = await api(`/api/mods/${id}/collage-assets`);
    if (!alive()) return;
    if (!assets.length) { status.textContent = "没有找到可用图片素材。请先将 Mod 文件存入本地库或安装到游戏里。"; return; }
    const ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height;
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, w, h); ctx.imageSmoothingEnabled = false;
    const cols = Math.ceil(Math.sqrt(assets.length * w / h)), rows = Math.ceil(assets.length / cols);
    const cw = w / cols, ch = h / rows;
    let drawn = 0;
    for (let i = 0; i < assets.length; i++) {
      if (!alive()) return;
      status.textContent = `生成中 ${i + 1}/${assets.length}…`;
      let bitmap;
      try {
        const r = await fetch(assets[i].url, { cache: "no-store" });
        if (!r.ok) continue;
        bitmap = await createImageBitmap(await r.blob());
        if (!alive()) return;
        const row = Math.floor(i / cols), inRow = Math.min(cols, assets.length - row * cols);
        const cx = (w - inRow * cw) / 2 + (i % cols + 0.5) * cw, cy = (row + 0.5) * ch;
        let scale = Math.min((cw - 18) / bitmap.width, (ch - 18) / bitmap.height, 8);
        if (scale >= 1) scale = Math.max(1, Math.floor(scale));
        const dw = Math.max(1, Math.round(bitmap.width * scale)), dh = Math.max(1, Math.round(bitmap.height * scale));
        ctx.drawImage(bitmap, Math.round(cx - dw / 2), Math.round(cy - dh / 2), dw, dh);
        drawn++;
      } catch (_) { /* 单张损坏素材跳过 */ }
      finally { if (bitmap) bitmap.close(); }
    }
    if (!alive()) return;
    if (!drawn) { status.textContent = "没有能读取的图片素材。"; return; }
    canvas.classList.remove("hidden");
    status.textContent = `已拼合 ${drawn} 张素材${limited ? "（最多 12 张）" : ""}`;
    save.disabled = false;
    save.onclick = async () => { save.disabled = true; await pick({ data: canvas.toDataURL("image/png") }); if (save.isConnected) save.disabled = false; };
  } catch (err) { if (alive()) status.textContent = err.message; }
}

async function openCovers(id) {
  const d = $("#files"), m = allMods().find((x) => x.id === id) || {};
  const head = `<div class="mhead"><h2>换封面</h2><button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>`;
  const local = `<label class="btn secondary covfile">使用本地图片<input type="file" accept="image/png,image/jpeg,image/gif,image/webp" hidden></label>`;
  d.innerHTML = head + `<p class="muted">正在读取 Nexus上的图片…</p><div class="row end">${local}<button data-close>取消</button></div>`;
  if (!d.open) d.showModal();
  const pick = async (body) => {
    try { await api(`/api/mods/${id}/cover`, body); } catch (err) { return toast(err.message, 7000); }
    d.close(); toast("封面换好了"); await load(); openDetail(id, true);
  };
  const bindFile = () => ($(".covfile input", d).onchange = (e) => {
    const f = e.target.files[0]; if (!f) return;
    const r = new FileReader(); r.onload = () => pick({ data: r.result }); r.readAsDataURL(f);
  });
  bindFile();
  let urls = [];
  if (m.nexus_id) { try { urls = (await api(`/api/mods/${id}/covers`, {})).urls; } catch (err) { toast(err.message, 6000); } }
  if (!d.open) return;
  d.innerHTML = head + (urls.length
    ? `<p class="muted">点一张设为封面，点右上角 × 可以删掉不想要的${m.cover ? "（当前封面是你之前选的）" : ""}。这里每次都会重新读 Nexus上作者传的全部图片，不受「最多存几张」的设置影响。</p><div class="covgrid">${urls.map((u) => `<div class="covitem"><button data-cov="${esc(u)}"><img src="${esc(u)}" loading="lazy" alt=""></button><button class="covdel" data-covdel="${esc(u)}" title="不要这张（以后换封面时不再显示）" aria-label="删除这张"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>`).join("")}</div>`
    : m.nexus_id ? `<p class="muted">Nexus不让管理器读它的图库。</p>` : "") +
    (m.nexus_id ? `<div class="covpaste"><span>在 <a href="https://www.nexusmods.com/stardewvalley/mods/${m.nexus_id}?tab=images" target="_blank">Nexus图库</a> 的图片上右键「复制图片」，回到这里按 Ctrl+V</span>
      <input id="covUrl" placeholder="也可以粘贴图片地址"><button id="covUse" class="mini">用这张</button></div>` : "") +
    `<div class="row end"><span class="covactions">${local}${!m.nexus_id ? '<button id="covCollage">素材拼图</button>' : ""}</span><button data-close>取消</button></div>`;
  bindFile();
  if ($("#covCollage", d)) $("#covCollage", d).onclick = () => openCollage(id, pick);
  if ($("#covUse", d)) $("#covUse", d).onclick = () => { const u = $("#covUrl", d).value.trim(); if (/^https?:\/\//.test(u)) pick({ url: u }); else toast("这不是图片地址"); };
  // Ctrl+V：剪贴板里是图片就直接用，是链接就当图片地址
  d.addEventListener("close", () => (d.onpaste = null), { once: true });
  d.onpaste = (e) => {
    const it = [...(e.clipboardData?.items || [])].find((x) => x.type.startsWith("image/"));
    if (it) { e.preventDefault(); const r = new FileReader(); r.onload = () => pick({ data: r.result }); r.readAsDataURL(it.getAsFile()); return; }
    const t = (e.clipboardData?.getData("text") || "").trim();
    if (/^https?:\/\/\S+$/.test(t) && e.target.id !== "covUrl") { e.preventDefault(); pick({ url: t }); }
  };
  d.querySelectorAll("[data-cov]").forEach((b) => (b.onclick = () => { b.classList.add("busy"); pick({ url: b.dataset.cov }); }));
  d.querySelectorAll("[data-covdel]").forEach((b) => (b.onclick = async (e) => {
    e.stopPropagation();
    try { await api(`/api/mods/${id}/cover`, { hide: b.dataset.covdel }); } catch (err) { return toast(err.message, 6000); }
    b.closest(".covitem").remove();
  }));
}
async function openFiles(id, update = false) {
  const d = $("#files");
  d.innerHTML = `<div class="mhead"><h2>选择要下载的文件</h2><button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div><p class="muted">正在读取 Nexus的文件列表…</p>`;
  if (!d.open) d.showModal();
  let r;
  try { r = await api(`/api/mods/${id}/files`, update ? { update: true } : {}); } catch (err) { d.close(); return toast(err.message, 7000); }
  const label = { MAIN: "主文件", OPTIONAL: "可选文件", UPDATE: "更新补丁", MISCELLANEOUS: "其他文件" };
  let html = "", fx = 0;
  const shown = [];
  for (const cat of ["MAIN", "OPTIONAL", "UPDATE", "MISCELLANEOUS"]) {
    const fs = r.files.filter((f) => f.category === cat);
    shown.push(...fs);
    if (!fs.length) continue;
    html += `<div class="fh">${label[cat]}</div>` + fs.map((f) => `<div class="fi ${f.file_id === r.best ? "best" : ""}"><div><b>${esc(f.name)}</b> <span class="muted small">v${esc(f.version)} · ${f.size_kb > 1024 ? (f.size_kb / 1024).toFixed(1) + " MB" : f.size_kb + " KB"}${update && (r.targets || []).some(t => t.file_id === f.file_id) ? " · 对应已安装组件的更新文件" : ""}</span>
      ${f.description ? `<div class="fd">${esc(f.description)}</div>` : ""}${r.version_blocks?.[f.file_id] ? `<div class="muted small">${esc(r.version_blocks[f.file_id])}</div>` : ""}</div><button class="${f.file_id === r.best ? "primary" : ""}" data-fid="${f.file_id}">下载</button></div>`).join("");
    html = html.replace(/<div class="fi /g, () => `<div data-fx="${fx++}" class="fi `);
  }
  d.innerHTML = `<div class="mhead"><h2>选择要下载的文件</h2><button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
    <p class="muted small">${update ? "请根据当前组件选择对应的文件。未明确匹配的文件可能是其他分支、可选文件，不能仅按版本号选择。" : "一般下载「主文件」就行；有多个主文件时通常是不同版本或不同风格，选一个即可。"}${r.premium ? "" : "<br>免费账号：点下载会打开 Nexus页面，在那里点「Slow download」，之后会自动安装。"}</p>
    <div class="flist">${html || `<p class="muted" style="padding:12px">Nexus上没有可下载的文件</p>`}</div>
    <div class="row end"><a class="btn left" href="${esc(r.page)}" target="_blank">在 Nexus看文件页<svg class="ico ext" viewBox="0 0 24 24" aria-hidden="true"><path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg></a><button data-close>关闭</button></div>`;
  d.querySelectorAll("[data-fid]").forEach((b) => (b.onclick = async () => {
    const reason = r.version_blocks?.[b.dataset.fid];
    if (reason && !await askConfirm("确认手动安装？", reason + "。继续可能覆盖当前版本，请确认已核对作者说明。", "仍然安装", "danger")) return;
    installMod(id, +b.dataset.fid);
  }));
  trFiles(d, shown);
}
// 文件名和说明翻成中文（英文原文放在鼠标悬停提示里）
async function trFiles(d, fs) {
  if (!fs.length || ((state.cfg?.translator || "microsoft") === "ai" && !state.cfg?.ai_api_key_set && !state.cfg?.translate_fallback)) return;
  const items = fs.flatMap((f) => [{ id: "fn" + f.file_id, text: f.name }, { id: "fd" + f.file_id, text: f.description || "" }]);
  let zh;
  try { zh = (await api("/api/translate-list", { items })).zh; } catch { return; }
  if (!zh || !d.open) return;
  fs.forEach((f, i) => {
    const el = d.querySelector(`[data-fx="${i}"]`);
    if (!el) return;
    const b = el.querySelector("b"), fd = el.querySelector(".fd"), n = zh[2 * i], t = zh[2 * i + 1];
    if (b && n && n !== f.name) { b.textContent = n; b.title = f.name; }
    if (fd && t) { fd.textContent = t; fd.title = f.description; }
  });
}
async function updateAll() {
  if (!state.mods.some(hasUpdate)) return toast("现在没有需要更新的 Mod。可以先在「管理 → 检查更新」查一下");
  try {
    toast("正在准备更新…");
    const r = await api("/api/update-all", {});
    if (r.guided) { await ensureNxm(); toast(`共 ${r.guided} 个要更新，已弹出第一个的下载页${r.manual_ids?.length ? `；另有 ${r.manual_ids.length} 个请单独选择文件` : ""}`, 6000); state.updLine = { left: r.guided }; pollLine(); }
    else { const pv = pickVersions(r, true); toast(`已开始更新 ${r.queued} 个` + (pv ? "；" + pv : ""), 9000); }
    load();
  } catch (err) { toast(err.message, 8000); }
}
// 本地 Mod 对上 Nexus（11-24 Hazel）：管理器按名字、作者猜几个像的，玩家点「是这个」；不像就自己填编号
const nxCandHtml = (c) => `<div class="nxc">${c.thumb ? `<img src="${esc(c.thumb)}" alt="" loading="lazy">` : '<i class="nxph"></i>'}
  <div class="nxcm"><span class="nxct"><b>${esc(c.name)}</b>${c.score >= 85 ? '<span class="nxlike">很像</span>' : ""}</span>
  <span class="muted small">作者 ${esc(c.uploader || c.author || "未知")} · 编号 ${c.nexus_id}${c.used_by ? ` · 游戏里已装着<a href="#" data-godetail="${c.used_id}">「${esc(c.used_by)}」</a>` : ""}</span></div>
  <a class="btn mini" href="${esc(c.url)}" target="_blank">查看Nexus页面</a><button type="button" class="mini primary" data-nxpick="${c.nexus_id}"${c.used_by ? " disabled" : ""}>是这个</button></div>`;
async function nxLink(id, value) {
  const r = await api(`/api/mods/${id}/nexus-link`, { value });
  toast(`已对应 Nexus ${r.nexus_id}，正在读取简介和图片`);
  return r;
}
// 匹配 Nexus 来源（点「刷新 Mod 状态」后弹出）：列出所有认不出来源的本地 Mod，一个个找相近的
// after：关掉后接着做的事（刷新 Mod 状态后还要问追踪）；quiet：没有要匹配的就不提示
async function openNxMatch(after, quiet) {
  if (typeof after !== "function") after = null;
  document.querySelectorAll("details.menu[open]").forEach((x) => x.removeAttribute("open"));
  const skip = (t) => { if (!quiet && t) toast(t, 5000); if (after) after(); return false; };
  if (!state.cfg?.nexus_api_key_set) return skip("先在设置里填 Nexus API Key");
  let items, pendingGroups;
  try { const r = await api("/api/nexus-unlinked"); items = r.items || []; pendingGroups = r.pending_groups || []; } catch (err) { return skip(err.message); }
  const pendingHint = pendingGroups.length ? `有 ${pendingGroups.length} 个共享目录待确认，暂不移动或单独匹配组件。可在「管理 → 识别大型 Mod」确认。` : "";
  if (!items.length) { skip(pendingHint ? "" : "没有需要匹配的本地 Mod"); if (pendingHint) toast(pendingHint, 9000); return false; }
  const d = $("#files"), run = {};
  d.innerHTML = `<div class="mhead"><h2>匹配 Nexus 来源</h2><button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
    <p class="muted small">这些 Mod 认不出 Nexus 来源。确认后会和 Nexus 上的 Mod 一样显示信息、检查更新。</p>${pendingHint ? `<p class="muted small">${esc(pendingHint)}</p>` : ""}
    <div class="nxlist">${items.map((x) => `<div class="nxrow" data-nxrow="${x.id}"><div class="nxlocal"><b>${esc(x.name_zh || x.name)}</b>
      <span class="muted small">${esc(x.name)}${x.author ? " · 作者 " + esc(x.author) : ""}${x.version ? " · v" + esc(x.version) : ""}</span></div>
      <div class="nxg" data-nxg="${x.id}"><span class="muted small">等待查找…</span></div></div>`).join("")}</div>
    <div class="row end"><span id="nxSum" class="muted small"></span><button data-close>关闭</button><button class="primary" id="nxAll" disabled>确认全部「是这个」</button></div>`;
  d.classList.add("nxwide");
  if (!d.open) d.showModal();
  d.addEventListener("close", () => { run.stop = true; d.classList.remove("nxwide"); load().then(() => after && after()); }, { once: true });
  const best = {}, done = new Set();
  const sum = () => {
    const like = Object.keys(best).filter((k) => !done.has(+k) && best[k]);
    $("#nxAll", d).disabled = !like.length;
    $("#nxAll", d).textContent = like.length ? `确认全部「是这个」（${like.length}）` : "确认全部「是这个」";
    $("#nxSum", d).textContent = `已对应 ${done.size} / ${items.length}`;
  };
  const markDone = (id, c) => {
    done.add(id);
    $(`[data-nxg="${id}"]`, d).innerHTML = `<span class="okk small"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 5 5 9-10"/></svg>已对应：${esc(c ? c.name : "你填的编号")}</span>`;
    sum();
  };
  const pick = async (id, value, c) => {
    try { await nxLink(id, value); markDone(id, c); } catch (err) { toast(err.message, 6000); }
  };
  const draw = (id, list) => {
    const box = $(`[data-nxg="${id}"]`, d);
    if (!box) return;
    best[id] = list[0] && list[0].score >= 85 && !list[0].used_by ? list[0] : null;
    box.innerHTML = (list.length ? nxCandHtml(list[0]) : `<span class="muted small">没找到相近的</span>`)
      + `<div class="nxops">${list.length > 1 ? `<button type="button" class="mini" data-nxmore title="展开其他可能对应的 Nexus Mod">其他候选（${list.length - 1}）</button>` : ""}
        <input data-nxin placeholder="自己填 Nexus 编号或链接"><button type="button" class="mini" data-nxok>确定</button>
        <button type="button" class="mini" data-nxnone title="以后不在这里列出">不在 Nexus</button></div>
      <div class="nxmore hidden">${list.slice(1).map(nxCandHtml).join("")}</div>`;
    box.querySelectorAll("[data-nxpick]").forEach((b) => (b.onclick = () => pick(id, b.dataset.nxpick, list.find((c) => c.nexus_id === +b.dataset.nxpick))));
    if ($("[data-nxmore]", box)) $("[data-nxmore]", box).onclick = (e) => { $(".nxmore", box).classList.toggle("hidden"); e.target.textContent = $(".nxmore", box).classList.contains("hidden") ? `其他候选（${list.length - 1}）` : "收起候选"; };
    const inp = $("[data-nxin]", box);
    $("[data-nxok]", box).onclick = () => { if (!inp.value.trim()) return toast("先填 Nexus 编号或链接"); pick(id, inp.value.trim(), null); };
    inp.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); $("[data-nxok]", box).click(); } };
    $("[data-nxnone]", box).onclick = async () => {
      try { await api(`/api/mods/${id}/nexus-none`, {}); } catch (err) { return toast(err.message, 6000); }
      delete best[id]; box.closest(".nxrow").remove(); sum();
    };
    sum();
  };
  $("#nxAll", d).onclick = async () => {
    const ids = Object.keys(best).filter((k) => !done.has(+k) && best[k]).map(Number);
    $("#nxAll", d).disabled = true;
    for (const id of ids) await pick(id, best[id].nexus_id, best[id]);
    sum();
  };
  sum();
  for (const x of items) {  // 一个一个查，别一下子问太多
    if (run.stop) break;
    const box = $(`[data-nxg="${x.id}"]`, d);
    if (!box) continue;
    box.innerHTML = `<span class="muted small"><span class="spin"></span>正在找…</span>`;
    try { draw(x.id, (await api(`/api/mods/${x.id}/nexus-guess`, {})).items); }
    catch (err) { box.innerHTML = `<span class="bad small">${esc(err.message)}</span>`; if (/API Key/.test(err.message)) break; }
    await new Promise((r) => setTimeout(r, 300));
  }
}
// 「前置」页面：补齐 / 清理 / 更正 三个标签（11-27 Hazel：管理菜单里三个按钮合成一个）
const DEP_TABS = [["fix", "补齐缺的"], ["clean", "清理没用的"], ["corr", "更正认错的"]];
function depHead(cur) {
  return `<div class="mhead"><h2>前置</h2><div class="row"><div class="segsw" data-deptabs>${DEP_TABS.map(([k, t]) => `<button type="button" data-deptab="${k}" class="${k === cur ? "on" : ""}">${t}</button>`).join("")}</div>${XBTN}</div></div>`;
}
function bindDepTabs(d) {
  d.querySelectorAll("[data-deptab]").forEach((b) => (b.onclick = () => openDeps(b.dataset.deptab)));
}
function openDeps(tab) {
  if (!tab) tab = missingDepPlan().length || !unusedDepPlan(true).length ? "fix" : "clean";
  for (const q of ["#files", "#depCorrections"]) { const x = $(q); if (x.open && !(tab === "corr" ? q === "#depCorrections" : q === "#files")) x.close(); }
  if (tab === "fix") openFixDeps(); else if (tab === "clean") openUnusedDeps(); else openDepCorrections();
}
// 补齐前置：把所有「缺必需前置」合在一起列出来，勾选后一次处理（停用的启用、没装的下载）
function missingDepPlan() {
  const map = new Map();
  for (const m of state.mods) for (const d of missingRequired(m)) {
    const k = d.lib ? "id" + d.lib.id : d.key;
    let e = map.get(k);
    if (!e) map.set(k, (e = { d, by: [] }));
    if (!e.by.includes(m)) e.by.push(m);
  }
  return [...map.values()].map((e) => {
    const d = e.d, lib = d.lib;
    let act = "", item = null;
    if (lib && lib.installed && lib.disabled) { act = "启用"; item = { id: lib.id }; }
    else if (lib && lib.nexus_id) { act = lib.status ? lib.status : "下载安装"; item = lib.status ? null : { id: lib.id }; }
    else if (lib) act = "不是 Nexus的，要自己装";
    else if (d.url && /nexusmods\.com\/(games\/)?stardewvalley\/mods\/\d+/i.test(d.url)) { act = "加进列表并下载"; item = { url: d.url }; }
    else if (d.unique_id) { act = "按编号去找"; item = { uid: d.unique_id }; }
    else act = "只知道名字，要自己去 Nexus搜";
    if (item) item.name = d.name;
    return { ...e, name: lib ? title(lib) : d.name || d.unique_id, act, item };
  }).sort((a, b) => !!b.item - !!a.item || b.by.length - a.by.length);
}
// 有好几个版本、管理器不知道下哪个的：直接弹出第一个的版本列表让你选，不叫你自己去找（11-24 Hazel）
function pickVersions(r, update = false) {
  const ids = r.manual_ids || [];
  if (!ids.length) return "";
  setTimeout(() => openFiles(ids[0], update), 300);
  const m = allMods().find((x) => x.id === ids[0]);
  return `「${m ? title(m) : r.manual[0]}」有好几个版本，选一个下载` + (ids.length > 1 ? `（另外 ${ids.length - 1} 个之后点它们卡片上的按钮再选）` : "");
}
async function fixDepsDone(r) {
  const bits = [r.enabled && `启用了 ${r.enabled} 个`, r.queued && `开始下载 ${r.queued} 个`, r.guided && `${r.guided} 个要在弹出的页面点「Slow download」`,
        r.failed.length && `${r.failed.length} 个没找到下载页：${r.failed.slice(0, 3).join("、")}`].filter(Boolean);
  const pv = pickVersions(r);
  if (pv) bits.push(pv);
  toast(bits.join("；") || "没有需要处理的", 10000);
  state.detailSig = null;  // 详情页按钮回到最新状态
  if (r.guided) { await ensureNxm(); state.updLine = { left: r.guided }; pollLine(); }
  load();
}
function openFixDeps() {
  const plan = missingDepPlan(), d = $("#files");
  if (!plan.length) {
    d.innerHTML = `${depHead("fix")}<p class="muted">没有缺必需前置的 Mod。</p><div class="row end"><button class="primary" data-close>好的</button></div>`;
    bindDepTabs(d); if (!d.open) d.showModal(); return;
  }
  const ok = plan.filter((x) => x.item);
  d.innerHTML = `${depHead("fix")}
    <p class="muted small">已安装的 Mod 一共缺 ${plan.length} 个必需前置。勾上的会一次处理：停用的直接启用，没装的去 Nexus下载（会员自动下，免费账号会一个个弹出下载页，点「Slow download」后自动弹下一个）。</p>
    <div class="fixlist">${plan.map((x, i) => `<label class="fixrow${x.item ? "" : " off"}"><input type="checkbox" data-fx="${i}" ${x.item ? "checked" : "disabled"}>
      <span class="fxname"><b>${x.d.lib ? `<a href="#" class="fxlink" data-godetail="${x.d.lib.id}">${esc(x.name)}</a>` : `<a href="#" class="fxlink" data-fxs="${i}" title="打开 Nexus 页面">${esc(x.name)}</a>`}</b><span class="muted small">${x.by.slice(0, 4).map((m) => `<a href="#" class="fxlink" data-godetail="${m.id}">${esc(title(m))}</a>`).join("、")}${x.by.length > 4 ? ` 等 ${x.by.length} 个` : ""} 需要</span></span>
      <span class="fxside"><span class="small ${x.item ? "" : "muted"}">${x.item ? esc(x.act) : `${esc(x.act)} <a href="#" data-fxs="${i}">去 Nexus搜</a>`}</span>${x.d.lib ? `<button type="button" class="mini" data-godetail="${x.d.lib.id}">详情</button>` : ""}<button type="button" class="mini" data-fxskip="${i}" title="其实用不到这个前置，以后不算缺">不需要</button></span></label>`).join("")}</div>
    <div class="row end"><button data-close>取消</button><button class="primary" id="fxGo" ${ok.length ? "" : "disabled"}>补齐 ${ok.length} 个</button></div>`;
  bindDepTabs(d);
  if (!d.open) d.showModal();
  const cnt = () => { const n = d.querySelectorAll("[data-fx]:checked").length; $("#fxGo", d).textContent = `补齐 ${n} 个`; $("#fxGo", d).disabled = !n; };
  d.querySelectorAll("[data-fx]").forEach((c) => (c.onchange = cnt));
  d.querySelectorAll("[data-fxskip]").forEach((b) => (b.onclick = async (e) => {
    e.preventDefault();
    const x = plan[+b.dataset.fxskip], names = x.by.slice(0, 3).map(title).join("、") + (x.by.length > 3 ? ` 等 ${x.by.length} 个` : "");
    const ok = await askChoice(`不需要「${x.name}」？`, `${names} 以后不算缺它。之后可以在这个 Mod 详情的前置里点「取消」改回来。`, null, [{ key: null, text: "取消" }, { key: 1, text: "不需要", cls: "primary" }]);
    if (!ok) return;
    try {
      for (const m of x.by) {
        const latest = await api(`/api/mods/${m.id}`), links = { ...(latest.dep_links || {}) };
        const dd = depsOf(latest).find((y) => y.key === x.d.key) || x.d;
        links[dd.link || x.d.link] = "skip";
        await api(`/api/mods/${m.id}/update`, { dep_links: links });
      }
    } catch (err) { toast(err.message, 7000); return; }
    await load(); toast("好了，以后不算缺这个前置");
    if (missingDepPlan().length) openFixDeps(); else d.close();
  }));
  d.querySelectorAll("[data-fxs]").forEach((a) => (a.onclick = (e) => { e.preventDefault(); openExt(depLink(plan[+a.dataset.fxs].d)); }));
  $("#fxGo", d).onclick = async () => {
    const items = [...d.querySelectorAll("[data-fx]:checked")].map((c) => plan[+c.dataset.fx].item);
    $("#fxGo", d).disabled = true; $("#fxGo", d).innerHTML = `<span class="spin"></span>正在处理…`;
    try {
      const r = await api("/api/fix-deps", { items });
      d.close();
      await fixDepsDone(r);

    } catch (err) { toast(err.message, 8000); cnt(); }
  };
}
// 清理没用的前置：装着、但现在没有任何已装 Mod（含停用的）用到的前置；前置的前置也跟着算（2026-11-23 Hazel：卸了大 Mod 后前置一键卸）
function unusedDepPlan(offToo) {
  return withLibraryLookup(() => {
  const inst = state.mods.filter((m) => m.installed);
  const user = (u) => !(offToo && u.disabled);  // 勾了「也列出停用 Mod 的前置」：只有停用的 Mod 要的前置也列出来
  const listers = new Map();  // 前置 id → 列过它的 Mod（不管装没装）
  for (const m of allMods()) for (const d of depsOf(m)) if (d.lib && !d.smapi) {
    if (!listers.has(d.lib.id)) listers.set(d.lib.id, []);
    listers.get(d.lib.id).push(m);
  }
  const isFw = (m) => sortedTags(m).some((a) => a.category === "前置框架");
  // 按文件判断（Hazel 11-23：从代码出发，不靠分类）：只有纯代码（只有 DLL、没有内容包、不改游戏图片/数据）的 Mod 才可能是框架；
  // 内容包（CP/JA/FS… 的 content pack）和改了游戏内容的都是你要玩的，不列。还没扫描出文件信息的，退回看分类
  const codeOnly = (m) => {
    const c = m.content;
    if (!c || !(c.frameworks || []).length) return null;
    return c.frameworks.every((f) => f === "SMAPI") && !["replace", "add", "edit", "skin"].some((k) => (c[k] || []).length);
  };
  const cand = inst.filter((m) => { const c = codeOnly(m); return c === null ? isFw(m) : c && (listers.has(m.id) || m.dep_auto || isFw(m)); });
  const gone = new Set();
  for (let changed = true; changed;) {
    changed = false;
    for (const m of cand) {
      if (gone.has(m.id)) continue;
      const used = (listers.get(m.id) || []).some((u) => u.installed && u.id !== m.id && !gone.has(u.id) && user(u));
      if (!used) { gone.add(m.id); changed = true; }
    }
  }
  return cand.filter((m) => gone.has(m.id)).map((m) => {
    const by = (listers.get(m.id) || []).filter((u) => u.id !== m.id);
    return { m, by, offBy: by.filter((u) => u.installed && u.disabled), sure: listers.has(m.id) || !!m.dep_auto };
  });
  });
}
function openUnusedDeps(onlyFor, offToo = false) {
  let plan = unusedDepPlan(offToo);
  if (onlyFor) { const f = new Set([].concat(onlyFor)); plan = plan.filter((x) => x.by.some((u) => f.has(u.id))); if (!plan.length) return; }
  const d = $("#files");
  if (!plan.length && !offToo && !onlyFor && unusedDepPlan(true).length) return openUnusedDeps(onlyFor, true);  // 只剩停用 Mod 在用的：直接把勾打开
  if (!plan.length) {
    d.innerHTML = `${depHead("clean")}<p class="muted">没有闲着的前置。</p><div class="row end"><button class="primary" data-close>好的</button></div>`;
    bindDepTabs(d); if (!d.open) d.showModal(); return;
  }
  d.innerHTML = `${onlyFor ? `<div class="mhead"><h2>这些前置没人用了</h2>${XBTN}</div>` : depHead("clean")}
    <p class="muted small">${offToo ? "没有启用的 Mod 在用它们。" : "没有 Mod 在用它们。"}勾上的会卸载，放进回收站。</p>
    <label class="chk-line"><input type="checkbox" id="uxOff" ${offToo ? "checked" : ""}> 也列出停用 Mod 的前置</label>
    <div class="fixlist">${plan.map((x, i) => `<label class="fixrow"><input type="checkbox" data-ux="${i}" ${x.sure ? "checked" : ""}>
      <span class="fxname"><b>${esc(title(x.m))}</b><span class="muted small">${x.offBy.length ? `停用的 ${esc(x.offBy.slice(0, 3).map(title).join("、"))}${x.offBy.length > 3 ? ` 等 ${x.offBy.length} 个` : ""} 在用` : x.by.length ? `原来给 ${esc(x.by.slice(0, 3).map(title).join("、"))}${x.by.length > 3 ? ` 等 ${x.by.length} 个` : ""} 用` : "没有 Mod 写明要它"}</span></span>
      <span class="fxside"><span class="small muted">${x.m.disabled ? "已停用" : ""}</span><button type="button" class="mini" data-godetail="${x.m.id}">详情</button></span></label>`).join("")}</div>
    <div class="row end"><button data-close>${onlyFor ? "先留着" : "取消"}</button><button class="danger-fill" id="uxGo">卸载</button></div>`;
  if (!onlyFor) bindDepTabs(d);
  if (!d.open) d.showModal();
  const cnt = () => { const n = d.querySelectorAll("[data-ux]:checked").length; $("#uxGo", d).textContent = `卸载 ${n} 个`; $("#uxGo", d).disabled = !n; };
  cnt();
  d.querySelectorAll("[data-ux]").forEach((c) => (c.onchange = cnt));
  $("#uxOff", d).onchange = (e) => openUnusedDeps(onlyFor, e.target.checked);
  $("#uxGo", d).onclick = async () => {
    const ids = [...d.querySelectorAll("[data-ux]:checked")].map((c) => plan[+c.dataset.ux].m.id);
    $("#uxGo", d).disabled = true; $("#uxGo", d).innerHTML = `<span class="spin"></span>正在卸载…`;
    try {
      const r = await runAction(ids, "uninstall");
      d.close();
      if (r.ok !== undefined) toast(`卸载了 ${r.ok} 个前置，在「设置 → 回收站」里留 30 天`, 6000);
    } catch (err) { toast(err.message, 8000); cnt(); }
  };
}
// ---------------------------------------------------------- 一键汉化：原 Mod 没有简中时，在 Nexus「Mods using this mod」里找汉化包
function zhLine(m) {
  if (!m.zh_for) return "";
  const t = state.mods.find((x) => x.id === m.zh_for);
  return ` · ${t ? `<a href="#" data-open="${t.id}">${esc(title(t))}</a> 的汉化` : "汉化"}` +
    (m.zh_stale ? ` · <span class="upd" title="原 Mod 更新后这些文件变了，旧汉化没盖上去，等汉化作者更新">${m.zh_stale} 个文件待汉化更新</span>` : "");
}
const XBTN = `<button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button>`;
// 这个 Mod 装了汉化没有（放进原 Mod 的、单独装的都算）
const zhOn = (m) => !!m.zh_by || state.mods.some((x) => x.zh_for === m.id && x.installed);
async function zhUndo(m, quiet) {
  if (!quiet && !(await askConfirm(`撤销「${title(m)}」的汉化？`, "卸掉汉化，换回原来的文件，汉化放进回收站。以后想要可以在「管理 → 全部汉化」里再装。", "撤销汉化"))) return false;
  try { await api("/api/zh/undo", { id: m.id }); toast(`「${title(m)}」的汉化已撤销`); load(); return true; }
  catch (err) { toast(err.message, 8000); return false; }
}
// 汉化装好后弹的结果窗口（11-26 Hazel：要固定的弹窗，不会自己消失；每行能撤销）
state.zhSeq = 0; state.zhItems = [];
async function zhDoneCheck(seq) {
  if (!seq || seq === state.zhSeq) return;
  const busy = state.mods.some((m) => m.zh_for && m.status) || (state.updLine && state.updLine.left > 0);
  const d0 = $("#zhdone");
  if (busy || document.querySelector(`dialog[open]:not(#zhdone):not(#detail):not(#stackView)`)) return;  // 还在下的、开着别的弹窗：等一会儿再弹
  let r;
  try { r = await api("/api/zh/done", {}); } catch (e) { return; }
  state.zhSeq = seq;
  if (!r.items.length) return;
  state.zhItems = (d0 && d0.open ? state.zhItems : []).concat(r.items);
  zhDoneShow();
}
function zhDoneShow() {
  let d = $("#zhdone");
  if (!d) { d = document.createElement("dialog"); d.id = "zhdone"; d.className = "modal"; document.body.appendChild(d); }
  const it = state.zhItems, ok = it.filter((x) => !x.error).length, bad = it.length - ok;
  const row = (x, i) => {
    const how = x.error ? `<span class="bad">没汉化成：${esc(x.error)}</span>`
      : x.mode === "mod" && !x.rep && !x.add ? "装成单独的 Mod" : [x.rep && `替换 ${x.rep} 个文件`, x.add && `新加 ${x.add} 个文件`].filter(Boolean).join(" · ") || "已装好";
    return `<div class="zdrow"><span class="fxname"><b>${x.target ? `<a href="#" data-zdopen="${x.target}">${esc(x.name)}</a>` : esc(x.name)}</b><span class="muted small">${how}</span></span>
      ${x.error || !x.target ? "" : `<button data-zdundo="${i}">撤销</button>`}</div>`;
  };
  d.innerHTML = `<div class="mhead"><h2>汉化结果</h2>${XBTN}</div>
    <p class="muted small">${[ok && `${ok} 个汉化好了，下次进游戏生效`, bad && `${bad} 个没汉化成`].filter(Boolean).join("；")}。</p>
    <div class="zdlist">${it.map(row).join("")}</div>
    <div class="row end"><button class="primary" data-close>好的</button></div>`;
  d.querySelectorAll("[data-close]").forEach((b) => (b.onclick = () => d.close()));
  d.querySelectorAll("[data-zdopen]").forEach((a) => (a.onclick = (e) => { e.preventDefault(); d.close(); openDetail(+a.dataset.zdopen); }));
  d.querySelectorAll("[data-zdundo]").forEach((b) => (b.onclick = async () => {
    const x = it[+b.dataset.zdundo], m = state.mods.find((y) => y.id === x.target);
    if (!m) return;
    b.disabled = true; b.innerHTML = `<span class="spin"></span>撤销中`;
    if (await zhUndo(m, true)) { b.textContent = "已撤销"; b.closest(".zdrow").querySelector(".small").textContent = "已换回原来的文件"; }
    else { b.disabled = false; b.textContent = "撤销"; }
  }));
  if (!d.open) d.showModal();
}
async function openZhAll(ids) {
  const d = $("#files");
  d.innerHTML = `<div class="mhead"><h2>全部汉化</h2>${XBTN}</div><p class="muted"><span class="spin"></span>正在 Nexus找汉化…</p>`;
  if (!d.open) d.showModal();
  let r;
  try { r = await api("/api/zh/scan", ids ? { ids } : {}); } catch (err) { d.close(); return toast(err.message, 7000); }
  const failNote = [r.failed && `${r.failed} 个查询未完成，稍后重试`, r.pending && `${r.pending} 个等待补查，再点「全部汉化」继续`].filter(Boolean).join("；");
  const skipNote = [r.has_zh && `${r.has_zh} 个自带简中，不用找`, r.no_nexus && `${r.no_nexus} 个没对上 Nexus，找不了（在「刷新 Mod 状态」里匹配 Nexus 来源后再试）`].filter(Boolean).join("；");
  if (!r.found.length) { d.close(); return toast((r.checked ? `已检查 ${r.checked} 个没有简中的 Mod，未找到汉化` : failNote ? "本次尚未完成检查" : "没有需要汉化的 Mod") + (failNote ? `；${failNote}` : "") + (skipNote ? `。${skipNote}` : ""), 9000); }
  d.innerHTML = `<div class="mhead"><h2>全部汉化</h2>${XBTN}</div>
    <p class="muted small">已检查 ${r.checked} 个 Mod，${r.found.length} 个找到了汉化。有好几个汉化的，在右边下拉里选。${failNote ? `<br>${esc(failNote)}。` : ""}${skipNote ? `<br>${skipNote}。` : ""}</p>
    <div class="fixlist">${r.found.map((f, i) => `<label class="fixrow"><input type="checkbox" data-zx="${i}" ${f.cands[0].installed ? "disabled" : f.cands[0].byname ? "" : "checked"}>
      <span class="fxname"><b>${esc(f.name)}</b><span class="muted small">${esc(f.cands[0].name)}${f.cands[0].pinned ? "（你填的）" : f.cands[0].byname ? "（按名字找到，确认一下）" : ""}</span></span>
      ${f.cands.length > 1 ? `<select data-zs="${i}">${f.cands.map((c, j) => `<option value="${j}">${esc(c.name)}${c.author ? " · " + esc(c.author) : ""}${c.updated ? " · " + esc(c.updated) : ""}</option>`).join("")}</select>` : `<span class="small">${f.cands[0].installed ? "已装" : ""}</span>`}</label>`).join("")}</div>
    <div class="row end"><button data-close>取消</button><button class="primary" id="zxGo">汉化</button></div>`;
  const cnt = () => { const n = d.querySelectorAll("[data-zx]:checked").length; $("#zxGo", d).textContent = `汉化 ${n} 个`; $("#zxGo", d).disabled = !n; };
  cnt();
  d.querySelectorAll("[data-zx]").forEach((c) => (c.onchange = cnt));
  d.querySelectorAll("[data-zs]").forEach((s) => (s.onchange = () => {
    const f = r.found[+s.dataset.zs], c = f.cands[+s.value], box = d.querySelector(`[data-zx="${s.dataset.zs}"]`);
    s.closest("label").querySelector(".fxname .small").textContent = c.name;
    box.disabled = c.installed; if (c.installed) box.checked = false; cnt();
  }));
  $("#zxGo", d).onclick = async () => {
    const pairs = [...d.querySelectorAll("[data-zx]:checked")].map((c) => {
      const i = +c.dataset.zx, s = d.querySelector(`[data-zs="${i}"]`);
      return [r.found[i].id, r.found[i].cands[s ? +s.value : 0].nexus_id];
    });
    $("#zxGo", d).disabled = true; $("#zxGo", d).innerHTML = `<span class="spin"></span>正在处理…`;
    try {
      const x = await api("/api/zh/install-many", { pairs });
      d.close();
      toast([x.queued && `开始下载 ${x.queued} 个`, x.guided && `${x.guided} 个要在弹出的页面点「Slow download」`, x.failed.length && `${x.failed.length} 个没下成`].filter(Boolean).join("；") || "没有要处理的", 9000);
      if (x.guided) { await ensureNxm(); state.updLine = { left: x.guided }; pollLine(); }
      load();
    } catch (err) { toast(err.message, 8000); cnt(); }
  };
}
// 免费账号逐个更新：看看还剩几个，剩 0 就收起提示条
async function updLine(body = {}) {
  try { state.updLine = await api("/api/update-line", body); } catch (e) { return; }
  if (body.stop) toast("已停止逐个更新");
  render();
  return state.updLine;
}
async function pollLine() {
  clearTimeout(pollLine.t);
  const l = await updLine();
  if (l && l.left > 0) pollLine.t = setTimeout(pollLine, 3000);
  else load();
}
function renderAccount() {
  const c = state.cfg, a = c.account || {}, box = $("#acctBox");
  // 两个 Key 旁边各写是哪个账号
  const tag = (name, prem, err) => !a.checked ? "已保存 · 确认中…" : err ? `<span class="bad">已保存 · 失效</span>` : `已保存 · ${esc(name || "?")}（${prem ? "会员" : "免费"}）`;
  $("#nexusSet").innerHTML = c.nexus_api_key_set ? (c.nexus_dl_key_set ? tag(a.read_name, a.read_premium, a.read_error) : tag(a.name, a.premium, a.error)) : "";
  $("#nexusDlSet").innerHTML = c.nexus_dl_key_set ? tag(a.name, a.premium, a.error) : `<span class="muted">没填，用上面那个</span>`;
  if (!c.nexus_api_key_set) { box.innerHTML = ""; return; }
  box.innerHTML = [...new Set([a.error, a.read_error].filter(Boolean))].map((e) => `<div class="er">${esc(e)}</div>`).join("") + (c.is_windows ? `<div class="row"><span class="muted small">Nexus「Mod Manager Download」按钮：${c.nxm ? "已交给星露管理器 ✓" : "没有交给星露管理器"}</span>
    <button type="button" class="mini" id="nxmBtn">${c.nxm ? "还给原来的程序" : "交给星露管理器"}</button></div>` : "");
  if ($("#nxmBtn")) $("#nxmBtn").onclick = async () => {
    try { await api("/api/nxm/register", { on: !c.nxm }); await loadCfg(); renderAccount(); toast("已设置"); } catch (err) { toast(err.message, 6000); }
  };
  // 页面打开时账号还没查完，之后不会自己更新：这里主动问一次
  if (!a.checked && !renderAccount.asking) {
    renderAccount.asking = true;
    api("/api/account", {}).then((r) => { c.account = r; }).catch((err) => { c.account = { checked: true, error: err.message }; })
      .finally(() => { renderAccount.asking = false; renderAccount(); });
  }
}

// ---------------------------------------------------------- 设置
async function loadCfg() { state.cfg = await api("/api/config"); rulesMark(); gameNamesMark(); testMark(); lookMark(); }
// 设置 → 常规 → 外观（11-24）：颜色（跟随系统/浅色/深色）、界面大小（桌面窗口用，重开后生效）
function applyTheme(t) {
  if (t) document.documentElement.dataset.theme = t; else delete document.documentElement.dataset.theme;
  try { localStorage.setItem("smm-theme", t || ""); } catch (e) {}
}
// 设置 → 常规 → 无图封面（11-26 Hazel：完全自定义，背景图、位置、字号、颜色都能改）
const GC_DEF = { on: true, bg: "", fg: "", en: true, au: true, img: "", fade: 0, pos: "c", size: "m", wt: "b" };
const gcCfg = () => ({ ...GC_DEF, ...((state.cfg || {}).gen_cover || {}) });
function gcApply() {
  const g = gcCfg(), r = document.documentElement.style;
  const set = (k, v) => (v ? r.setProperty(k, v) : r.removeProperty(k));
  set("--gc-bg", g.bg); set("--gc-fg", g.fg);
  set("--gc-img", g.img ? `url("${g.img}")` : ""); set("--gc-fade", g.img ? String((g.fade || 0) / 100) : "");
  set("--gc-k", { s: "0.82", m: "", l: "1.2" }[g.size] || "");
}
function gcMark() {
  const g = gcCfg(), cs = getComputedStyle(document.documentElement);
  gcApply();
  if (!$("#gcOn")) return;
  $("#gcOn").checked = g.on; $("#gcEn").checked = g.en; $("#gcAu").checked = g.au;
  const hex = (v) => { const m = String(v).trim().match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i); if (!m) return "#ffffff"; return m[1].length === 3 ? "#" + [...m[1]].map((c) => c + c).join("") : "#" + m[1]; };
  $("#gcBg").value = g.bg || hex(cs.getPropertyValue("--bg")); $("#gcFg").value = g.fg || hex(cs.getPropertyValue("--ink"));
  for (const [id, v] of [["#gcPos", g.pos], ["#gcSize", g.size], ["#gcWt", g.wt]]) $(id).querySelectorAll("button").forEach((b) => b.classList.toggle("on", b.dataset.v === v));
  $("#gcImg").textContent = g.img ? "换图片" : "上传图片"; $("#gcImgDel").classList.toggle("hidden", !g.img);
  $("#gcFadeRow").classList.toggle("hidden", !g.img); $("#gcFade").value = g.fade || 0; $("#gcFadeV").textContent = (g.fade || 0) + "%";
  $("#gcRow .gcopts").classList.toggle("off", !g.on);
  const ex = state.mods.find((m) => !(m.images || []).length && m.name_zh && m.author) || state.mods.find((m) => m.name_zh && m.author)
    || { name: "Bakery Furniture", name_zh: "烘焙家具", author: "Mika" };
  $("#gcPrev").innerHTML = `<div class="thumb">${genCover({ ...ex, images: [] }, "cover")}</div>`;
}
async function gcSave(patch) {
  state.cfg.gen_cover = { ...gcCfg(), ...patch }; gcMark(); render();
  await api("/api/config", { gen_cover: state.cfg.gen_cover }).catch((err) => toast(err.message, 6000));
}
$("#gcOn").onchange = (e) => gcSave({ on: e.target.checked });
$("#gcEn").onchange = (e) => gcSave({ en: e.target.checked });
$("#gcAu").onchange = (e) => gcSave({ au: e.target.checked });
for (const [id, k] of [["#gcPos", "pos"], ["#gcSize", "size"], ["#gcWt", "wt"]]) $(id).onclick = (e) => { const b = e.target.closest("button"); if (b) gcSave({ [k]: b.dataset.v }); };
const gcLive = (k) => (e) => { state.cfg.gen_cover = { ...gcCfg(), [k]: k === "fade" ? +e.target.value : e.target.value }; gcApply(); if (k === "fade") $("#gcFadeV").textContent = e.target.value + "%"; };
$("#gcBg").oninput = gcLive("bg"); $("#gcFg").oninput = gcLive("fg"); $("#gcFade").oninput = gcLive("fade");
$("#gcBg").onchange = (e) => gcSave({ bg: e.target.value });
$("#gcFg").onchange = (e) => gcSave({ fg: e.target.value });
$("#gcFade").onchange = (e) => gcSave({ fade: +e.target.value });
$("#gcImg").onclick = () => $("#gcImgFile").click();
$("#gcImgFile").onchange = (e) => {
  const f = e.target.files[0]; e.target.value = "";
  if (!f) return;
  if (f.size > 15 * 1024 * 1024) return toast("图片太大了（超过 15MB）");
  const rd = new FileReader();
  rd.onload = async () => {
    try { const r = await api("/api/gen-cover-bg", { data: rd.result }); await gcSave({ img: r.url, fade: gcCfg().img ? gcCfg().fade : 30 }); }
    catch (err) { toast(err.message, 6000); }
  };
  rd.readAsDataURL(f);
};
$("#gcImgDel").onclick = () => gcSave({ img: "" });
$("#gcReset").onclick = () => gcSave({ ...GC_DEF });
function lookMark() {
  const c = state.cfg || {};
  gcMark();
  applyTheme(c.theme || "");
  $("#themeSeg")?.querySelectorAll("button").forEach((b) => b.classList.toggle("on", b.dataset.v === (c.theme || "")));
  const sc = String(+c.ui_scale || 0);
  $("#scaleSeg")?.querySelectorAll("button").forEach((b) => b.classList.toggle("on", String(+b.dataset.v) === sc));
  $("#scaleSeg")?.classList.toggle("hidden", !c.app_window);
  $("#scaleTip")?.classList.toggle("hidden", !!c.app_window);
}
$("#themeSeg").onclick = async (e) => {
  const b = e.target.closest("button"); if (!b) return;
  applyTheme(b.dataset.v); state.cfg.theme = b.dataset.v; lookMark(); render();
  await api("/api/config", { theme: b.dataset.v }).catch((err) => toast(err.message, 6000));
};
$("#scaleSeg").onclick = async (e) => {
  const b = e.target.closest("button"); if (!b) return;
  const v = +b.dataset.v;
  if (v === (+state.cfg.ui_scale || 0)) return;
  try { await api("/api/config", { ui_scale: v }); } catch (err) { return toast(err.message, 6000); }
  state.cfg.ui_scale = v; lookMark();
  // 界面大小要整个窗口重开才生效：直接帮你重开（11-24 Hazel：设了没反应）
  if (await askConfirm("调整界面大小", "新的界面大小需重新打开窗口后生效，是否立即重新打开？", "立即重新打开", "primary", null, "稍后")) {
    const r = await api("/api/reopen-window", {}).catch(() => null);
    if (!r?.ok) toast("关掉管理器，再从桌面图标打开，就是新大小。", 8000);
  }
};
// 测试模式：标题和左上角写「测试版」，免得和正式版搞混（11-24）
function testMark() {
  const on = !!state.cfg?.test_mode;
  document.title = on ? "星露管理器（测试版）" : "星露管理器";
  const logo = $(".logo");
  if (logo && on && !$(".testtag", logo)) logo.insertAdjacentHTML("beforeend", `<span class="testtag" title="只用这个文件夹里的「测试Mods」，不动游戏 Mods 文件夹">测试版</span>`);
}

// ---------------------------------------------------------- 分类单编辑页
const SV = (d) => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${d}"/></svg>`;
const IC = { tog: SV("m9 6 6 6-6 6"), up: SV("M12 19V5M6 11l6-6 6 6"), down: SV("M12 5v14M6 13l6 6 6-6"), del: SV("M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3") };
const GRIP = `<span class="grip" title="按住拖动排序" aria-label="拖动排序"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="6" r="1.4"/><circle cx="15" cy="6" r="1.4"/><circle cx="9" cy="12" r="1.4"/><circle cx="15" cy="12" r="1.4"/><circle cx="9" cy="18" r="1.4"/><circle cx="15" cy="18" r="1.4"/></svg></span>`;
const IB = (cls, t, title_) => `<button type="button" class="ib ${cls}" title="${title_}" aria-label="${title_}">${IC[cls] || t}</button>`;
function subRow(name = "", desc = "") {
  const d = document.createElement("div");
  d.className = "sr"; d.dataset.orig = name;
  d.innerHTML = `${GRIP}<input class="sn" placeholder="子分类名" value="${esc(name)}"><input class="sd" placeholder="放什么（给 AI 看，可留空）" value="${esc(desc)}">${IB("del", "×", "删除")}`;
  return d;
}
function catCard(c = { name: "", desc: "", subs: [], sub_desc: {} }, open = false) {
  const d = document.createElement("div");
  d.className = "cc" + (open ? " open" : ""); d.dataset.orig = c.name;
  d.innerHTML = `<div class="cch">${GRIP}${IB("tog", "›", "展开 / 收起")}<input class="cn" placeholder="大分类名" value="${esc(c.name)}"><span class="cnt"></span>${IB("del", "×", "删除这个大分类")}</div>
    <div class="ccb"><input class="cd" placeholder="这个大分类放什么（给 AI 看）" value="${esc(c.desc)}"><div class="lbl">子分类（没有就留空，只有一层）</div><div class="subs"></div><button type="button" class="addsub">＋ 添加子分类</button></div>`;
  const box = d.querySelector(".subs");
  (c.subs || []).forEach((x) => box.appendChild(subRow(x, (c.sub_desc || {})[x] || "")));
  return d;
}
function countCards() {
  document.querySelectorAll("#catList .cc").forEach((cc) => {
    const n = cc.querySelectorAll(".sr").length;
    cc.querySelector(".cnt").textContent = n ? `${n} 个子分类` : "没有子分类";
  });
}
function openCats() {
  if ($("#settings").open) $("#settings").close();  // 不叠两层弹窗
  const list = $("#catList");
  list.innerHTML = "";
  (state.cfg.categories || []).forEach((c) => list.appendChild(catCard(c)));
  countCards();
  $("#catEdit").showModal();
}
$("#catList").addEventListener("click", async (e) => {
  const b = e.target.closest(".ib, .addsub");
  if (!b) return;
  const row = b.closest(".sr") || b.closest(".cc");
  if (b.classList.contains("tog")) row.classList.toggle("open");
  else if (b.classList.contains("addsub")) { const r = subRow(); row.querySelector(".subs").appendChild(r); r.querySelector(".sn").focus(); }
  else if (b.classList.contains("del")) {
    const name = row.querySelector(".cn, .sn").value.trim();
    const n = state.mods.filter((m) => row.classList.contains("cc") ? m.category === row.dataset.orig : (m.category === row.closest(".cc").dataset.orig && m.subcategory === row.dataset.orig)).length;
    if (n && !(await askConfirm(`删除分类「${name}」？`, `里面现在有 ${n} 个 Mod，保存时可以让 AI 把它们重新分到别的分类。`))) return;
    row.remove();
  }
  countCards();
});
// 按住左边的六个点拖动排序：大分类在大分类之间挪，子分类只在自己的大分类里挪
$("#catList").addEventListener("pointerdown", (e) => {
  const g = e.target.closest(".grip");
  if (!g || e.button > 0) return;
  e.preventDefault();
  const row = g.closest(".sr") || g.closest(".cc"), box = row.parentNode, list = $("#catList");
  const sel = row.classList.contains("sr") ? ":scope > .sr" : ":scope > .cc";
  row.classList.add("dragging"); document.body.classList.add("sorting");
  // 位置都用布局坐标（offsetTop，不含动画里的 transform），判断才不会抖
  const grabOff = e.clientY - row.getBoundingClientRect().top;
  const py = (y) => y - list.getBoundingClientRect().top - list.clientTop + list.scrollTop;
  const head = (x) => (x.querySelector(":scope > .cch") || x).offsetHeight;
  // 只能在自己那一组里拖：大分类在整个列表里，子分类在自己的大分类里，不会拖出框
  const top = (y) => {
    const lo = box === list ? 0 : box.offsetTop, hi = lo + (box === list ? list.scrollHeight : box.offsetHeight) - row.offsetHeight;
    return Math.max(lo, Math.min(hi, py(y) - grabOff));
  };
  const follow = (y) => { row.style.transform = `translateY(${top(y) - row.offsetTop}px)`; };
  let lastY = e.clientY, scrollT = 0;
  const move = (ev) => {
    lastY = ev.clientY;
    const sibs = [...box.querySelectorAll(sel)].filter((x) => x !== row);
    const y = top(lastY) + head(row) / 2;  // 用被拖那行的中线来比
    const after = sibs.find((x) => y < x.offsetTop + head(x) / 2);
    const moved = after ? row.nextElementSibling !== after : sibs.length && sibs[sibs.length - 1].nextElementSibling !== row;
    if (moved) {
      const before = new Map(sibs.map((x) => [x, x.offsetTop]));  // FLIP：记下位置 → 换位置 → 从旧位置滑到新位置
      if (after) box.insertBefore(row, after); else sibs[sibs.length - 1].after(row);
      for (const x of sibs) {
        const d = before.get(x) - x.offsetTop;
        if (!d) continue;
        x.style.transition = "none"; x.style.transform = `translateY(${d}px)`;
        x.offsetHeight;  // 强制重排，让下面的过渡生效
        x.style.transition = "transform .2s cubic-bezier(.2,.8,.2,1)"; x.style.transform = "";
      }
    }
    follow(lastY);
    const lr = list.getBoundingClientRect();  // 拖到列表边上时自动滚动
    cancelAnimationFrame(scrollT);
    const edge = lastY < lr.top + 36 ? -1 : lastY > lr.bottom - 36 ? 1 : 0;
    if (edge) { const tick = () => { list.scrollTop += edge * 8; follow(lastY); scrollT = requestAnimationFrame(tick); }; scrollT = requestAnimationFrame(tick); }
  };
  const up = () => {
    cancelAnimationFrame(scrollT);
    document.body.classList.remove("sorting");
    row.style.transition = "transform .2s cubic-bezier(.2,.8,.2,1), box-shadow .2s"; row.style.transform = "";
    row.classList.add("dropping"); row.classList.remove("dragging");
    setTimeout(() => { row.classList.remove("dropping"); row.style.transition = ""; }, 220);
    document.removeEventListener("pointermove", move); document.removeEventListener("pointerup", up); document.removeEventListener("pointercancel", up);
  };
  // 挂在 document 上：拖动时行在 DOM 里换位置，挂在手柄上会丢掉指针
  document.addEventListener("pointermove", move); document.addEventListener("pointerup", up); document.addEventListener("pointercancel", up);
});
function collectCats() {
  const seen = new Set(), renames = {}, sub_renames = {};
  const cats = [...document.querySelectorAll("#catList .cc")].map((cc) => {
    const name = cc.querySelector(".cn").value.trim();
    if (cc.dataset.orig && name && cc.dataset.orig !== name) renames[cc.dataset.orig] = name;
    const subs = [], sub_desc = {}, ss = new Set();
    cc.querySelectorAll(".sr").forEach((r) => {
      const sn = r.querySelector(".sn").value.trim();
      if (!sn || ss.has(sn)) return;
      ss.add(sn); subs.push(sn);
      const sd = r.querySelector(".sd").value.trim();
      if (sd) sub_desc[sn] = sd;
      if (r.dataset.orig && r.dataset.orig !== sn) (sub_renames[name] = sub_renames[name] || {})[r.dataset.orig] = sn;
    });
    return { name, desc: cc.querySelector(".cd").value.trim(), subs, sub_desc, orig: cc.dataset.orig };
  }).filter((c) => c.name && !seen.has(c.name) && seen.add(c.name));
  // 哪些大分类有改动（新加的、说明变了、子分类变了）→ 保存后问要不要重新归类这些
  const old = Object.fromEntries((state.cfg.categories || []).map((c) => [c.name, c]));
  const sig = (c) => JSON.stringify([c.desc || "", c.subs || [], c.sub_desc || {}]);
  const changed = cats.filter((c) => !old[c.orig] || sig(old[c.orig]) !== sig(c)).map((c) => c.name);
  return { categories: cats.map(({ orig, ...c }) => c), renames, sub_renames, changed };
}
async function saveCats(ask = true) {
  const body = collectCats();
  if (!body.categories.length) { toast("分类单至少要有一个分类"); return null; }
  const r = await api("/api/config", body);
  await loadCfg(); await load();
  $("#catEdit").close(); fillSettings();
  if (ask && r.touched) {
    const what = r.changed.length ? `「${r.changed.slice(0, 3).join("」「")}」${r.changed.length > 3 ? "等" : ""}有改动` : "有 Mod 的分类已经不在分类单里了";
    if (await askConfirm("重新归类？", `已保存。${what}，要让 AI 把相关的 ${r.touched} 个 Mod 按新分类单重新分一遍吗？\n只重新分类，不翻译；手动改过分类的不动。`, "重新归类", "primary", null, "不用")) {
      const rr = await api("/api/reclassify", { cats: r.changed });
      toast(`已安排 ${rr.count} 个 Mod 重新归类`); load();
      return r;
    }
  }
  toast("分类单已保存");
  return r;
}

// 翻译顺序：拖动排序（第一个是平时用的）
const TR_NAME = { microsoft: "微软翻译", google: "谷歌翻译", ai: "AI 翻译" };
const TR_TIP = { microsoft: "免费", google: "免费", ai: "用 AI 模型，花一点 token" };
const trOrder = () => [...document.querySelectorAll("#trOrder li")].map((li) => li.dataset.tr);
function drawTrOrder(order) {
  const ol = $("#trOrder");
  order = [...order.filter((x) => TR_NAME[x]), ...Object.keys(TR_NAME).filter((x) => !order.includes(x))];
  ol.innerHTML = order.map((x) => `<li draggable="true" data-tr="${x}"><span class="trn"></span><span class="trt"><b>${TR_NAME[x]}</b><span>${TR_TIP[x]}</span></span><svg class="grip" viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="6" r="1.4"/><circle cx="15" cy="6" r="1.4"/><circle cx="9" cy="12" r="1.4"/><circle cx="15" cy="12" r="1.4"/><circle cx="9" cy="18" r="1.4"/><circle cx="15" cy="18" r="1.4"/></svg></li>`).join("");
  let drag = null;
  ol.querySelectorAll("li").forEach((li) => {
    li.ondragstart = (e) => { drag = li; li.classList.add("dragging"); e.dataTransfer.effectAllowed = "move"; };
    li.ondragend = () => { li.classList.remove("dragging"); drag = null; };
    li.ondragover = (e) => {
      e.preventDefault();
      if (!drag || drag === li) return;
      const r = li.getBoundingClientRect();
      ol.insertBefore(drag, e.clientY < r.top + r.height / 2 ? li : li.nextSibling);
    };
  });
}
function fillSettings() {
  const f = $("#setForm"), c = state.cfg;
  for (const k of ["ai_provider", "ai_base_url", "ai_model", "mods_folder", "max_images"]) f.elements[k].value = c[k] ?? "";
  drawTrOrder(c.translate_order || [c.translator || "microsoft"]);
  refreshRetranslate();
  f.elements.translate_fallback.checked = !!c.translate_fallback;
  $("#modelPick").classList.add("hidden"); f.elements.ai_model.classList.remove("hidden");
  syncFsel(f);
  const cs = c.categories || [];
  $("#catSummary").textContent = `${cs.length} 个大分类、${cs.reduce((n, x) => n + x.subs.length, 0)} 个子分类`;
  f.elements.nexus_api_key.value = ""; f.elements.ai_api_key.value = ""; f.elements.nexus_dl_key.value = "";
  $("#nexusSet").classList.toggle("hidden", !c.nexus_api_key_set);
  f.elements.nexus_api_key.placeholder = c.nexus_api_key_set ? "留空不改" : "粘贴你的个人 API Key";
  f.elements.ai_api_key.placeholder = c.ai_api_key_set ? "留空不改" : "";
  f.elements.nexus_dl_key.placeholder = c.nexus_dl_key_set ? "留空不改" : "可不填，不填就用上面那个";
  $("#nexusDlClear").classList.toggle("hidden", !c.nexus_dl_key_set);
  $("#nexusDlClear").onclick = async () => { await api("/api/config", { nexus_dl_key_clear: true }); await loadCfg(); fillSettings(); toast("下载改回用读取的 Key"); };
  $("#aiSet").classList.toggle("hidden", !c.ai_api_key_set);
  renderAccount();
}

// ---------------------------------------------------------- 事件
function requestDialogClose(d) {
  if (!d?.open) return;
  if (typeof d.requestClose === "function") d.requestClose();
  else if (d.dispatchEvent(new Event("cancel", { cancelable: true }))) d.close();
}
document.addEventListener("click", (e) => {
  const close = e.target.closest("[data-close]");
  if (close) { requestDialogClose(close.closest("dialog")); return; }
  const cat = e.target.closest(".nav-item[data-cat]"), sub = e.target.closest(".sub-item");
  if ((cat || sub) && (e.ctrlKey || e.metaKey)) {
    const c = (cat || sub).dataset.cat, s_ = sub ? sub.dataset.sub : "";
    if (cat && !catNames().includes(c)) return;  // 筛选项（已安装、缺前置…）不参与多选
    if (!state.multi.length && catNames().includes(state.cat)) state.multi = [{ c: state.cat, s: state.sub || "" }];
    state.multi = multiHas(c, s_) ? state.multi.filter((x) => !(x.c === c && x.s === s_)) : [...state.multi, { c, s: s_ }];
    if (state.multi.length === 1) { state.cat = state.multi[0].c; state.sub = state.multi[0].s; }
    if (state.multi.length < 2) state.multi = state.multi.length ? state.multi : [];
    render(); return;
  }
  if (cat || sub) state.multi = [];
  const pkd = e.target.closest("[data-pkdel]");
  if (pkd) { e.stopPropagation(); delPack(pkd.dataset.pkdel); return; }
  const pk = e.target.closest("[data-pack]");
  if (pk) { state.multi = []; state.cat = PACK; state.pack = pk.dataset.pack; state.sub = ""; render(); return; }
  if (e.target.closest("#newPack")) { openPackNew([]); return; }
  const pa = e.target.closest("[data-papply]");
  if (pa) { applyPack(state.pack, pa.dataset.papply); return; }
  if (e.target.closest("[data-prename]")) {
    askInput("重命名合集", state.pack).then((n) => {
      if (!n || n === state.pack) return;
      if (state.packs.some((p) => p.name === n)) return toast("已经有同名合集了");
      const old = state.pack;
      savePacks((ps) => ps.map((p) => (p.name === old ? { ...p, name: n, auto: false } : p))).then(() => { state.pack = n; render(); }, (err) => toast(err.message, 6000));
    });
    return;
  }
  if (e.target.closest("[data-pdel]")) {
    delPack(state.pack);
    return;
  }
  if (e.target.closest("[data-pshare]")) { openModSheet(state.pack); return; }
  if (e.target.closest("[data-pdl]")) { packDownload(state.pack); return; }
  const mall = e.target.closest("[data-mall]");
  if (mall) { state.mAll = mall.dataset.mall === "1"; render(); return; }
  if (e.target.closest("[data-mclr]")) { const f = state.multi[0]; state.multi = []; if (f) { state.cat = f.c; state.sub = f.s; } render(); return; }
  if (cat) {  // 没固定时，再点一下已展开的大分类就收起来（还停在这个分类）
    const again = state.cat === cat.dataset.cat && !state.sub;
    state.fold = again && !state.pinAll ? !state.fold : false;
    if (cat.dataset.cat === ISSUE && state.cat !== ISSUE) state.issue = "";
    if (cat.dataset.cat === UPD) state.updReview = false;
    state.cat = cat.dataset.cat; state.sub = ""; render(); return;
  }
  if (sub) {
    const same = state.cat === sub.dataset.cat && state.sub === sub.dataset.sub;
    state.cat = sub.dataset.cat; state.sub = same ? "" : sub.dataset.sub; render(); return;
  }
  if (e.target.closest("#editCats")) { openCats(); return; }
  if (e.target.closest("#pinBtn")) {
    state.pinAll = !state.pinAll;
    try { localStorage.setItem("smm-pin", state.pinAll ? "1" : "0"); } catch (err) {}
    render(); return;
  }
  const st = e.target.closest("[data-star]");
  if (st && !st.closest("#detail")) { e.stopPropagation(); toggleStar(+st.dataset.star); return; }
  const tg = e.target.closest("[data-tog]");
  if (tg) { toggleMod(+tg.dataset.tog); return; }
  const gd = e.target.closest("[data-godetail]");
  if (gd) { e.preventDefault(); openDetail(+gd.dataset.godetail); return; }  // 清理前置 / 补齐前置 列表里的「详情」
  if (e.target.closest("[data-fixdeps-d]")) { openFixDeps(); return; }
  if (e.target.closest("[data-fixpill]")) { e.stopPropagation(); openFixDeps(); return; }  // 卡片上的「缺前置」直接点开补齐
  const dl = e.target.closest("[data-dl]");
  if (dl) { dl.disabled = true; installMod(+dl.dataset.dl, undefined, dl.hasAttribute("data-update")).finally(() => { dl.disabled = false; }); return; }
  const sk = e.target.closest("[data-stack]");
  if (sk) { openStackView(sk.dataset.stack, sk); return; }
  const skc = e.target.closest("[data-stackclose]");
  if (skc) { state.openStacks.delete(skc.dataset.stackclose); render(); return; }
  const c = e.target.closest(".card, .item");
  if (c && state.selMode) {
    const id = +c.dataset.id;
    state.sel.has(id) ? state.sel.delete(id) : state.sel.add(id);
    render(); return;
  }
  if (c) openDetail(+c.dataset.id).then(() => { if (!$("#detail").open) clog("detail did not open for " + c.dataset.id); }, (err) => clog("openDetail failed: " + (err && err.stack || err)));
});
// 点弹窗外面的灰色区域请求关闭，与 ESC 共用 cancel 守卫；动态确认/输入框不支持遮罩取消。
// 按下在弹窗里面（比如拖动排序拖出了框）就不算。
document.querySelectorAll("dialog").forEach((d) => {
  let downOut = false;
  d.addEventListener("pointerdown", (e) => { downOut = e.target === d; });
  d.addEventListener("click", (e) => { if (e.target === d && downOut) requestDialogClose(d); downOut = false; });
});
// 只认详情页自己的「取消」（按 Esc）。文件选择框关掉时，<input type=file> 也会冒泡一个 cancel 上来，不能当成关详情页
$("#detail").addEventListener("cancel", (e) => { if (e.target !== $("#detail")) return; e.preventDefault(); closeDetailChecked(); });
$("#detail").addEventListener("close", () => (state.openId = null));
$("#lightbox").onclick = () => $("#lightbox").close();
$("#search").oninput = (e) => { state.q = e.target.value; render(); };
// 搜索记录：只留最近 5 个，点框时弹出，每条可以 × 删掉（浏览器自带的记录关掉）
const sIn = $("#search");
const sHist = document.createElement("div"); sHist.className = "shist hidden"; sIn.parentNode.appendChild(sHist);
function searchHistFill() {
  const all = prefGet("searchHist", []) || [], q = sIn.value.trim().toLowerCase();
  const list = all.filter((x) => !q || (x.toLowerCase().includes(q) && x.toLowerCase() !== q));
  sHist.innerHTML = list.map((x) => `<div class="shi" data-q="${esc(x)}"><span>${esc(x)}</span><button type="button" class="shx" title="删掉这条记录" aria-label="删掉">×</button></div>`).join("");
  sHist.classList.toggle("hidden", !list.length || document.activeElement !== sIn);
}
sIn.setAttribute("autocomplete", "off");
sIn.addEventListener("focus", searchHistFill);
sIn.addEventListener("input", searchHistFill);
sIn.addEventListener("blur", () => sHist.classList.add("hidden"));
sHist.addEventListener("mousedown", (e) => e.preventDefault());  // 点记录时框不失焦
sHist.addEventListener("click", (e) => {
  const row = e.target.closest(".shi"); if (!row) return;
  const q = row.dataset.q;
  if (e.target.closest(".shx")) { prefSet("searchHist", (prefGet("searchHist", []) || []).filter((x) => x !== q)); return searchHistFill(); }
  sIn.value = q; state.q = q; render(); searchHistAdd(); sHist.classList.add("hidden");
});
function searchHistAdd() {
  const q = sIn.value.trim(), old = prefGet("searchHist", []) || [];
  if (!q || old[0] === q) return;
  prefSet("searchHist", [q, ...old.filter((x) => x !== q)].slice(0, 5));
}
sIn.addEventListener("change", searchHistAdd);
sIn.addEventListener("keydown", (e) => { if (e.key === "Enter") { searchHistAdd(); sHist.classList.add("hidden"); } else if (e.key === "Escape") sHist.classList.add("hidden"); });

// 下拉菜单：点了菜单项或点外面就收起；同时只开一个
document.addEventListener("click", (e) => {
  document.querySelectorAll("details.menu[open]").forEach((d) => {
    if (!d.contains(e.target) || e.target.closest(".pop button")) d.open = false;
  });
});
document.querySelectorAll("details.menu").forEach((d) => d.addEventListener("toggle", () => {
  if (d.open) document.querySelectorAll("details.menu[open]").forEach((o) => o !== d && (o.open = false));
}));

$("#btnBatch").onclick = () => $("#batch").showModal();
$("#batchManual").onclick = (e) => { e.preventDefault(); $("#batch").close(); openBatchImport(); };
$("#batchGo").onclick = async () => {
  try {
    const text = $("#batchText").value;
    let msg = [];
    if (text.trim()) {
      const r = await api("/api/batch", { text });
      msg.push(r.found ? `找到 ${r.found} 个链接，新增 ${r.added} 个${r.skipped ? `，${r.skipped} 个已存在` : ""}` : "没找到星露谷 Nexus链接");
    }
    toast(msg.join("；") || "什么都没填");
    $("#batchText").value = "";
    $("#batch").close(); load();
  } catch (err) { toast("出错了：" + err.message, 6000); }
};

$("#btnStack").onclick = () => { state.stack = !state.stack; state.openStacks.clear(); prefSet("stackAuthor", state.stack); render(); };
$("#btnSelect").onclick = () => { document.querySelectorAll("details.menu[open]").forEach((d) => d.removeAttribute("open")); state.selMode = !state.selMode; state.sel.clear(); render(); };
let retranslateTimer;
async function refreshRetranslate() {
  clearTimeout(retranslateTimer);
  const b = $("#trRedo"), status = $("#trRedoStatus");
  try {
    const r = await api("/api/translate-status");
    b.disabled = r.running;
    if (r.running) {
      status.textContent = `正在翻译 ${r.done}/${r.total}${r.failed ? `，失败 ${r.failed}` : ""}…`;
      retranslateTimer = setTimeout(refreshRetranslate, 1500);
    } else if (r.total || r.error) {
      status.textContent = `已处理 ${r.done}/${r.total}${r.failed ? `，失败 ${r.failed}` : ""}${r.error ? `：${r.error}` : "。"}${r.left ? ` 还剩 ${r.left} 个，点「继续翻译」接着来。` : ""}`;
    }
    else if (r.left) status.textContent = `上次还剩 ${r.left} 个没翻完。`;
    b.textContent = !r.running && r.left ? "继续翻译" : "重新翻译";
  } catch (err) { status.textContent = "获取翻译进度失败：" + err.message; b.disabled = false; }
}
$("#trRedo").onclick = async () => {
  const b = $("#trRedo"), status = $("#trRedoStatus"), f = $("#setForm").elements;
  b.disabled = true;
  status.textContent = "正在启动翻译…";
  try {
    const order = trOrder();
    await api("/api/config", { translator: order[0], translate_order: order, translate_fallback: f.translate_fallback.checked });
    await loadCfg();
    await api("/api/translate-redo", {});
    await refreshRetranslate();
  } catch (err) { status.textContent = "失败：" + err.message; b.disabled = false; }
};
$("#aiFind").onclick = (e) => { e.preventDefault(); openFinder({ text: $("#search").value.trim() }); };
$("#btnBulk").onclick = () => { document.querySelectorAll("details.menu[open]").forEach((d) => d.removeAttribute("open")); openBatchImport(); };
$("#btnZhAll").onclick = () => { document.querySelectorAll("details.menu[open]").forEach((d) => d.removeAttribute("open")); openZhAll(); };
$("#btnDeps").onclick = () => { document.querySelectorAll("details.menu[open]").forEach((d) => d.removeAttribute("open")); openDeps(); };
$("#btnUpdAll").onclick = () => { document.querySelectorAll("details.menu[open]").forEach((d) => d.removeAttribute("open")); updateAll(); };
let componentReviewBusy = false;
async function openComponentCandidates(startup = false) {
  if (componentReviewBusy || document.querySelector("dialog[open]") || (startup && sessionStorage.getItem("componentReviewShown"))) return;
  componentReviewBusy = true;
  try {
    const { items = [], pending_groups: pending = [] } = await api("/api/component-candidates");
    if (document.querySelector("dialog[open]")) return;
    if (!items.length) {
      if (pending.length) { sessionStorage.setItem("componentReviewShown", "1"); toast(`发现 ${pending.length} 个共享目录待确认，已保留文件位置。可在「管理 → 识别大型 Mod」确认。`, 9000); }
      return;
    }
    sessionStorage.setItem("componentReviewShown", "1");
    const d = $("#files");
    d.innerHTML = `<div class="mhead"><h2>发现被拆分的 Mod（${items.length} 组）</h2><button class="x" data-close aria-label="关闭">×</button></div>
      <p class="muted small">这些记录可能是同一个 Mod 的不同组件。勾选确认后合并，游戏文件不动，原记录会备份。</p>
      <label class="chk-line"><input type="checkbox" id="componentAll" checked> 全选</label>
      <div class="fixlist">${items.map((x, i) => `<label class="fixrow"><input type="checkbox" data-component="${i}" checked><div class="grow"><b>${esc(x.parent.split(/[\\/]/).pop().replace(/^\.+/, ""))}</b> <span class="muted small">${x.records} 条记录 · ${x.folders} 个组件</span><div class="muted small">${esc(x.parent)}</div><div class="muted small">合并至：${esc(x.name)}${x.members?.length ? " · " + esc(x.members.join("、")) : ""}</div><div data-component-status="${i}" class="small"></div></div></label>`).join("")}</div>
      <div class="row end"><span id="componentSum" class="muted small"></span><button data-close>以后再说</button><button class="primary" id="componentGo">合并所选</button></div>`;
    const boxes = [...d.querySelectorAll("[data-component]")], all = $("#componentAll", d), go = $("#componentGo", d);
    let working = false;
    const sum = () => {
      const available = boxes.filter(b => !b.disabled), checked = available.filter(b => b.checked);
      all.checked = !!available.length && checked.length === available.length;
      all.indeterminate = checked.length > 0 && checked.length < available.length;
      go.disabled = working || !checked.length;
      go.textContent = `合并 ${checked.length} 组`;
    };
    boxes.forEach(b => b.onchange = sum);
    all.onchange = () => { boxes.filter(b => !b.disabled).forEach(b => { b.checked = all.checked; }); sum(); };
    d.oncancel = e => { if (working) e.preventDefault(); };
    go.onclick = async () => {
      const chosen = boxes.filter(b => b.checked && !b.disabled);
      working = true;
      const closes = [...d.querySelectorAll("[data-close]")]; closes.forEach(b => { b.disabled = true; });
      all.disabled = true; boxes.forEach(b => { b.disabled = true; }); go.disabled = true;
      let ok = 0, failed = 0;
      for (const box of chosen) {
        const i = Number(box.dataset.component), x = items[i], status = $(`[data-component-status="${i}"]`, d);
        status.textContent = "正在合并…";
        try {
          await api("/api/merge-components", { ids: x.ids, confirm: true, primary: x.primary, suggested: true });
          status.className = "small okk"; status.textContent = "已合并"; box.checked = false; box.dataset.done = "1"; ok++;
        } catch (e) { status.className = "small er"; status.textContent = e.message || "合并失败"; failed++; }
      }
      // 刷新完成前也不能关闭并进入另一个 files 视图，避免旧任务关闭新视图。
      try { await load(); } catch (err) { toast("合并结果已保存，列表刷新失败：" + err.message, 8000); }
      if (!d.open || !go.isConnected) return;
      working = false; all.disabled = false; closes.forEach(b => { b.disabled = false; });
      boxes.forEach(b => { b.disabled = b.dataset.done === "1"; }); sum();
      $("#componentSum", d).textContent = `已合并 ${ok} 组${failed ? `，${failed} 组未合并` : ""}`;
      if (!failed && boxes.every(b => b.disabled)) { d.close(); toast(`已合并 ${ok} 组 Mod`); }
    };
    sum(); d.showModal();
    await new Promise(resolve => d.addEventListener("close", () => { d.oncancel = null; resolve(); }, { once: true }));
  } catch (err) { if (!startup) toast("识别拆分组件失败：" + err.message, 6000); }
  finally { componentReviewBusy = false; }
}

// 「刷新 Mod 状态」：先读游戏 Mods 文件夹，再和 Nexus 对一遍（11-27 Hazel：原来「扫描已安装」和「刷新 Mod 状态」两个按钮合成一个）
$("#btnScan").onclick = async () => {
  const b = $("#btnScan");
  if (b.disabled) return;
  b.disabled = true; b.innerHTML = `<span class="spin"></span>读取 Mods 文件夹…`;
  let msg = "", r = null;
  try {
    const sc = await api("/api/scan", {});
    msg = `发现 ${sc.found} 个 Mod，新增 ${sc.added} 个，更新 ${sc.updated} 个`;
    const miss = sc.missing || [];
    if (miss.length) {
      const withNote = miss.filter((x) => x.note).length;
      const names = miss.slice(0, 8).map((x) => x.name).concat(miss.length > 8 ? [`…等 ${miss.length} 个`] : []);
      const ok = await askConfirm(`${miss.length} 个 Mod 不在游戏文件夹里了`, "要把它们从列表里删掉吗？" + (withNote ? `其中 ${withNote} 个写了备注，备注也会一起删掉。` : "") + "保留的话会标记为未下载。",
        "从列表删掉", "danger", names, "保留");
      await api("/api/remove", { ids: miss.map((x) => x.id), keep: !ok, missing: true });
      msg += ok ? `，已删除 ${miss.length} 个不在文件夹里的` : `，${miss.length} 个已标记为未安装`;
    }
    await loadCfg();
    if (state.cfg.nexus_api_key_set) {
      b.innerHTML = `<span class="spin"></span>和 Nexus 对一遍…`;
      try {
        r = await api("/api/sync-tracked", {});
        if (r.added) msg += `，Nexus 新追踪的 ${r.added} 个已拉进来`;
        await api("/api/check-updates", {});
        for (;;) {
          await new Promise((ok) => setTimeout(ok, 800));
          const s = await api("/api/update-status");
          if (s.running) { b.innerHTML = `<span class="spin"></span>检查更新 ${s.done}/${s.total || "…"}`; continue; }
          const failed = Array.isArray(s.failed) ? s.failed.length : Number(s.failed) || 0;
          const pending = Array.isArray(s.pending) ? s.pending.length : Number(s.pending) || 0;
          const unknown = Number(s.unknown) || 0;
          msg += [s.found ? `${s.found} 个有新版本` : "", unknown ? `${unknown} 个待核查` : "", pending ? `${pending} 个等待检查` : "", failed ? `${failed} 个检查失败` : "", s.error ? `检查更新没做完：${s.error}` : ""].filter(Boolean).map((x) => "，" + x).join("");
          break;
        }
      } catch (err) { msg += "，Nexus 没对完：" + err.message; }
    }
    await load();
    toast(msg, 6000);
    await openComponentCandidates();  // 先确认组归属，再匹配 Nexus，避免一个大包的组件被逐个对应
    if (r) {
      const next = () => { if ((r.never || []).length) openUntracked(r.never, msg); };
      openNxMatch(next, true);  // 认不出来源的本地 Mod：先对 Nexus，关掉后再问追踪（11-24 Hazel）
    }
  } catch (err) { toast(err.message, 7000); if (/手动/.test(err.message)) openSettings("gen"); }
  finally { b.disabled = false; b.textContent = "刷新 Mod 状态"; }
};
function openUntracked(list, msg) {
  const d = $("#files");
  d.innerHTML = `<div class="mhead"><h2>Nexus 上未追踪（${list.length}）</h2><button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
    ${msg ? `<p class="muted small">${esc(msg)}。</p>` : ""}
    <p>勾选的 Mod 将在 Nexus 上追踪。</p>
    <div class="fixlist">${list.map((x, i) => `<label class="fixrow"><input type="checkbox" data-nv="${i}" ${x.cancelled ? "" : "checked"}>
      <span class="fxname"><b>${esc(x.name)}</b></span><span class="small muted">${x.cancelled ? "你在 Nexus 上取消过" : x.installed ? "游戏里装着" : "没装"}</span></label>`).join("")}</div>
    <p class="muted small">每个 Mod 只提示一次。</p>
    <div class="row end"><button data-close>不用了</button><button class="primary" id="utGo">追踪</button></div>`;
  if (!d.open) d.showModal();
  const cnt = () => { const n = d.querySelectorAll("[data-nv]:checked").length; $("#utGo", d).textContent = `追踪 ${n} 个`; $("#utGo", d).disabled = !n; };
  d.querySelectorAll("[data-nv]").forEach((c) => (c.onchange = cnt)); cnt();
  $("#utGo", d).onclick = async () => {
    const ids = [...d.querySelectorAll("[data-nv]:checked")].map((c) => list[+c.dataset.nv].id);
    $("#utGo", d).disabled = true;
    try { await api("/api/bulk", { ids, action: "track" }); d.close(); toast(`已追踪 ${ids.length} 个`); load(); }
    catch (err) { toast(err.message, 7000); cnt(); }
  };
}

$("#btnTracked").onclick = async () => {
  try {
    const r = await api("/api/import-tracked", {});
    toast(r.found ? `Nexus追踪里有 ${r.found} 个星露谷 Mod，新增 ${r.added} 个` : "你的 Nexus追踪列表里没有星露谷 Mod", 6000);
    load();
  } catch (err) { toast(err.message, 7000); }
};

// ---------------------------------------------------------- 整理文件夹
function orgItem(x, bad) {
  return `<div class="og${bad ? " bad" : ""}"><b>${esc(x.name)}</b><div class="path">${esc(x.from)} → <span>${esc(x.to)}</span>${x.reason ? "　" + esc(x.reason) : ""}</div></div>`;
}
// 同一个 Mod 的几个文件夹合成一条（11-23 Hazel）
function orgGroups(list) {
  const by = new Map();
  for (const x of list) { const k = x.mod ?? x.from; if (!by.has(k)) by.set(k, []); by.get(k).push(x); }
  return [...by.values()];
}
function orgGroupItem(g, bad) {
  if (g.length === 1) return orgItem(g[0], bad);
  const dir = (p) => p.replace(/[\\/][^\\/]*$/, "");
  const same = (arr) => arr.every((v) => v === arr[0]);
  const froms = g.map((x) => dir(x.from)), tos = g.map((x) => dir(x.to));
  const reasons = [...new Set(g.map((x) => x.reason).filter(Boolean))];
  const path = same(froms) && same(tos) ? `${esc(froms[0] || "Mods")} → <span>${esc(tos[0])}</span>`
    : g.map((x) => `${esc(x.from)} → <span>${esc(x.to)}</span>`).join("<br>");
  return `<div class="og${bad ? " bad" : ""}"><b>${esc(g[0].name)}</b> <span class="muted">${g.length} 个文件夹</span><div class="path">${path}${reasons.length ? "　" + esc(reasons.join("；")) : ""}</div></div>`;
}
let orgPlanSignature = "", orgAllowShared = false;
async function openOrganize(allowShared = false) {
  orgAllowShared = allowShared === true;
  orgPlanSignature = "";
  $("#orgGo").disabled = true;
  let r;
  try { r = await api("/api/organize/plan", { allow_shared: orgAllowShared }); } catch (err) { return toast(err.message, 7000); }
  orgPlanSignature = r.signature;
  $("#orgRoot").textContent = "位置：" + r.root;
  const pg = orgGroups(r.plan), sg = orgGroups(r.skipped);
  let html = pg.length ? `<div class="oh">要移动 ${pg.length} 个 Mod</div>` + pg.map((g) => orgGroupItem(g)).join("") : "";
  if (sg.length) html += `<div class="oh">跳过 ${sg.length} 个 Mod</div>` + sg.map((g) => orgGroupItem(g, true)).join("");
  if (!html) html = `<div class="og muted">都已经在对的文件夹里了 ✓<div class="path">还没分好类的、没安装的 Mod 不会动。</div></div>`;
  $("#orgList").innerHTML = html;
  $("#orgGo").disabled = !r.plan.length;
  $("#orgUndo").disabled = !r.can_undo;
  $("#orgAuto").checked = !!state.cfg.auto_organize;
  $("#orgSharedRow").classList.toggle("hidden", !(orgAllowShared || r.skipped.some(x => x.shared)));
  $("#orgShared").checked = orgAllowShared;
  if (!$("#organize").open) $("#organize").showModal();
}
$("#btnOrganize").onclick = openOrganize;
$("#orgShared").onchange = e => openOrganize(e.target.checked);
$("#btnLargeMod").onclick = async () => {
  document.querySelectorAll("details.menu[open]").forEach(x => x.removeAttribute("open"));
  const d = $("#files");
  let current = ".", busy = false;
  const head = `<div class="mhead"><h2>识别大型 Mod</h2><button class="x" data-close aria-label="关闭">×</button></div>`;
  const working = on => { busy = on; d.querySelectorAll("button,input,select").forEach(x => { x.disabled = on; }); d.oncancel = on ? e => e.preventDefault() : null; };
  const renderDir = async (path = current) => {
    if (busy) return;
    working(true);
    try {
      const r = await api("/api/large-mod/browse", { path });
      current = r.current;
      d.innerHTML = head + `<p class="muted small">选择要识别的 Mod 文件夹（如「七宗罪」），自动识别其中的所有组件。</p>
        <div class="row"><input id="largePath" value="${esc(r.absolute)}" placeholder="游戏 Mods 内的文件夹路径"><button id="largeOpen">打开</button></div>
        <div class="row" style="margin:10px 0"><button id="largeUp" ${current === "." ? "disabled" : ""}>上一级</button><span class="muted small">${esc(current === "." ? "Mods" : current)}</span></div>
        <div class="fixlist large-mod-list">${r.dirs.map((x,i) => `<div class="large-folder-row"><button class="large-folder-name" data-large-dir="${i}"><span>${esc(x.name)}</span><span class="muted">${x.category ? "打开 ›" : "识别"}</span></button>${x.category ? "" : `<button class="mini" data-large-open="${i}" aria-label="打开 ${esc(x.name)}">打开 ›</button>`}</div>`).join("") || `<p class="muted small large-component">没有子文件夹</p>`}</div>
        <div class="row end"><button data-close>取消</button><button class="primary" id="largeInspect" ${r.selectable ? "" : "disabled"}>识别当前路径</button></div>`;
      $("#largeOpen", d).onclick = () => renderDir($("#largePath", d).value.trim());
      $("#largePath", d).onkeydown = e => { if (e.key === "Enter") { e.preventDefault(); $("#largeOpen", d).click(); } };
      $("#largeUp", d).onclick = () => renderDir(r.parent);
      d.querySelectorAll("[data-large-dir]").forEach(b => b.onclick = () => { const x = r.dirs[+b.dataset.largeDir]; return x.category ? renderDir(x.path) : inspect(x.path); });
      d.querySelectorAll("[data-large-open]").forEach(b => b.onclick = () => renderDir(r.dirs[+b.dataset.largeOpen].path));
      $("#largePath", d).oninput = () => { $("#largeInspect", d).disabled = !$("#largePath",d).value.trim() || (!r.selectable && $("#largePath",d).value.trim() === r.absolute); };
      $("#largeInspect", d).onclick = () => inspect($("#largePath", d).value.trim());
    } catch (err) { toast(err.message, 7000); }
    finally { busy = false; d.oncancel = null; if ($("#largeOpen",d)) { d.querySelectorAll("button,input").forEach(x => x.disabled = false); $("#largeUp",d).disabled = current === "."; $("#largePath",d).oninput(); } }
  };
  const inspect = async path => {
    if (busy) return;
    working(true);
    try {
      const r = await api("/api/large-mod/identify", { path });
      const choices = { "": "稍后确认", nexus: "Nexus", ...SOURCES };
      let source = r.nexus_id ? "nexus" : r.source || (r.suggested_nexus ? "nexus" : "");
      d.innerHTML = head + `<p class="muted small">已识别「${esc(r.parent.split(/[\\/]/).pop().replace(/^\.+/, ""))}」：${r.folders} 个组件，${r.records} 条已有记录。${r.already_grouped ? "已归为一个 Mod。" : `确认后归为「${esc(r.name)}」，游戏文件不动。`}</p>
        <div class="fixlist large-mod-list">${r.components.map(x => `<div class="large-component"><b>${esc(x.name)}</b>${x.disabled ? ' <span class="muted small">已停用</span>' : ""}<div class="muted small">${esc(x.unique_id)}</div><div class="muted small">${esc(x.folder)}</div></div>`).join("")}</div>
        ${r.already_grouped ? "" : `<div style="margin-top:14px"><p class="small muted">${r.nexus_id ? `已有 Nexus 来源 #${r.nexus_id}` : r.suggested_nexus ? `根据清单或 SMAPI 记录找到 Nexus #${r.suggested_nexus}，请确认来源。` : "没有可靠的 Nexus 编号。可手动填写，或合并后在详情页找相近的。"}</p>
        <div class="segsw" id="largeSources">${Object.entries(choices).map(([k,v])=>`<button type="button" data-large-source="${k}" ${r.nexus_id && k!=="nexus" ? "disabled" : ""}>${v}</button>`).join("")}</div>
        <div class="row" style="margin-top:9px"><input id="largeUrl" placeholder="来源链接"><select id="largeType"><option value="">选择类型</option><option value="original">原创</option><option value="modified">改制</option></select></div></div>`}
        <div class="row end"><button id="largeBack">返回</button><button data-close>取消</button><button class="primary" id="largeGo">${r.already_grouped ? "查看详情" : "确认识别"}</button></div>`;
      $("#largeBack",d).onclick = () => renderDir(current);
      const paintSource = () => {
        d.querySelectorAll("[data-large-source]").forEach(x=>x.classList.toggle("on",x.dataset.largeSource===source));
        const url=$("#largeUrl",d), type=$("#largeType",d);
        url.classList.toggle("hidden",!source); type.classList.toggle("hidden",source!=="custom");
        url.placeholder = source==="nexus" ? "Nexus 编号或链接" : source==="naver" ? "Naver 链接或尾号（必填）" : "来源链接（可留空）";
        url.value = source==="nexus" ? String(r.nexus_id || r.suggested_nexus || "") : source===r.source ? r.source_url : "";
        type.value = r.custom_type || "";
      };
      if (!r.already_grouped) { d.querySelectorAll("[data-large-source]").forEach(x=>x.onclick=()=>{source=x.dataset.largeSource;paintSource();}); paintSource(); }
      $("#largeGo",d).onclick = async () => {
        if (r.already_grouped) { d.close(); await load(); return openDetail(r.primary); }
        const selected = { source, url: $("#largeUrl",d).value.trim(), custom_type: $("#largeType",d).value };
        working(true);
        try {
          const result = await api("/api/large-mod/identify", { path: r.parent, confirm: true, primary: r.primary, signature: r.signature, source: selected });
          working(false); d.close(); await load(); toast("已识别为一个 Mod，原游戏文件未改动"); openDetail(result.primary);
        } catch (err) { toast(err.message, 7000); working(false); if(r.nexus_id)d.querySelectorAll('[data-large-source]').forEach(x=>x.disabled=x.dataset.largeSource!=="nexus"); }
      };
    } catch (err) { toast(err.message, 7000); working(false); if ($("#largePath", d)) { $("#largeUp", d).disabled = current === "."; $("#largePath", d).oninput(); } }
    finally { busy=false; d.oncancel=null; }
  };
  d.innerHTML = head + `<p class="muted small">正在读取 Mods 文件夹…</p>`;
  if (!d.open) d.showModal();
  await renderDir();
};
$("#orgAuto").onchange = async (e) => {
  await api("/api/config", { auto_organize: e.target.checked });
  await loadCfg();
  toast(e.target.checked ? "已开启：仅已确认整理的 Mod 会随分类自动移动" : "已关闭自动同步");
};
$("#orgGo").onclick = async () => {
  const b = $("#orgGo"); b.disabled = true;
  try {
    const r = await api("/api/organize/apply", { signature: orgPlanSignature, allow_shared: orgAllowShared });
    let msg = `已整理 ${r.moved} 个文件夹`;
    if (r.failed.length) msg += `，${r.failed.length} 个没挪动：${r.failed[0].name}（${r.failed[0].reason}）`;
    toast(msg, r.failed.length ? 9000 : 4000);
    $("#organize").close(); load();
  } catch (err) { toast(err.message, 7000); await openOrganize(orgAllowShared); }
};
$("#orgUndo").onclick = async () => {
  if (!(await askConfirm("撤销上次整理？", "把上一次整理挪动过的文件夹放回原处。", "撤销整理", "primary"))) return;
  try {
    const r = await api("/api/organize/undo", {});
    toast(`已放回 ${r.moved} 个` + (r.failed.length ? `，${r.failed.length} 个没放回（${r.failed[0].reason}）` : ""), 7000);
    $("#organize").close(); load();
  } catch (err) { toast(err.message, 7000); }
};

$("#catAdd").onclick = () => { const c = catCard(undefined, true); $("#catList").appendChild(c); countCards(); c.querySelector(".cn").focus(); };
$("#catSave").onclick = () => saveCats(true);
$("#catRedo").onclick = async () => {
  if (!(await askConfirm("全部重新归类？", "让 AI 按分类单把所有 Mod 重新归一次类。只重新分类，不翻译；手动改过分类的不动；会先保存分类单。", "重新归类", "primary"))) return;
  if (await saveCats(false)) reclassify(true);
};
$("#openCats").onclick = openCats;
// 版本号显示成一串数字：202611241308（旧格式 20261124-1114 去掉横杠）
const verNum = (v) => String(v || "").replace(/-/g, "");
async function showReleaseHistory(auto = false) {
  try {
    await prefsReady;
    const r = await api("/api/release-history"), d = $("#releaseHistory");
    const history = Array.isArray(r.history) ? r.history : [];
    if (auto && (!r.id || !history.length || prefGet("releaseNoticeSeen", "") === r.id)) return;
    if (d.open) return;
    d.innerHTML = `<div class="mhead"><h2>更新说明</h2><button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6l-12 12"/></svg></button></div><div class="flist">${history.length ? history.map(item => `<div class="fh">${esc(item.date || "")}</div><div class="fi"><div>${(Array.isArray(item.changes)?item.changes:[]).map(x => `<p class="small">${esc(x)}</p>`).join("")}</div></div>`).join("") : '<div class="fi muted">当前版本没有打包更新记录。</div>'}</div><p class="muted small">以后可在设置 → 常规 → 查看更新记录中查看。</p><div class="row end"><button type="button" class="primary" data-close>知道了</button></div>`;
    await new Promise(resolve => { d.addEventListener("close", () => { if (r.id) prefSet("releaseNoticeSeen", r.id); resolve(); }, {once:true}); d.showModal(); });
  } catch (err) { if (!auto) toast(err.message, 6000); }
}
$("#btnReleaseHistory").onclick = () => showReleaseHistory();
function openDepCorrections() {
  const d = $("#depCorrections");
  d.innerHTML = `${depHead("corr")}<input id="depCorrSearch" type="search" placeholder="搜索需要更正前置的 Mod（中英文名 / 尾号 / 备注）"><div id="depCorrList"></div>`;
  const q = $("#depCorrSearch", d), list = $("#depCorrList", d);
  const search = () => {
    const term = q.value.trim().toLowerCase();
    if (!term) { list.innerHTML = '<p class="muted small">搜索 Mod 后，选择需要更正的前置。</p>'; return; }
    const hits = allMods().filter(m => matchesSearch(m, term)).slice(0, 50);
    list.innerHTML = hits.length ? `<div class="flist">${hits.map(m => `<div class="fi"><div><b>${esc(title(m))}</b>${m.name !== title(m) ? `<div class="fd">${esc(m.name || "")}</div>` : ""}</div><button type="button" class="mini" data-corr-mod="${m.id}">选择</button></div>`).join("")}</div>` : '<p class="muted small">没有找到匹配的 Mod。</p>';
    list.querySelectorAll('[data-corr-mod]').forEach(b => b.onclick = () => showDeps(+b.dataset.corrMod));
  };
  const showDeps = async id => {
    let m;
    try { m = await api(`/api/mods/${id}`); } catch (err) { toast(err.message, 6000); return; }
    if (!d.open) return;
    const deps = depsOf(m).filter(x => !x.smapi);
    list.innerHTML = `<div class="row" style="margin-top:12px"><b>${esc(title(m))}</b><button type="button" class="mini" id="depCorrBack" style="margin-left:auto">返回搜索结果</button></div>${deps.length ? `<div class="flist">${deps.map((x,i) => `<div class="fi"><div><b>${esc(x.name)}</b><div class="fd">${x.skipped ? "标了不需要" : x.unused ? "你装的版本用不到" : x.required ? "必需" : "可选"} · 当前：${esc(x.lib ? title(x.lib) : "未识别")}${(m.dep_links || {})[x.link] && !x.skipped ? " · 手动指定" : ""}</div></div><button type="button" class="mini" data-corr-dep="${i}">更正</button></div>`).join("")}</div>` : '<p class="muted small">此 Mod 没有可更正的前置。</p>'}`;
    $("#depCorrBack", d).onclick = search;
    list.querySelectorAll('[data-corr-dep]').forEach(b => b.onclick = async () => {
      const x = deps[+b.dataset.corrDep];
      const pick = await askChoice(`更正「${x.name}」`, `当前识别：${x.lib ? title(x.lib) : "未识别"}`, null, [
        { key: null, text: "取消" }, ...((m.dep_links || {})[x.link] ? [{ key: "auto", text: "恢复自动识别" }] : []),
        ...(x.skipped ? [] : [{ key: "skip", text: "不需要" }]), { key: "nx", text: "在 Nexus 找" }, { key: "inst", text: "选已装的", cls: "primary" }]);
      const save = async val => {
        try {
          const latest = await api(`/api/mods/${id}`), links = {...(latest.dep_links || {})};
          if (val) links[x.link] = val; else delete links[x.link];
          await api(`/api/mods/${id}/update`, {dep_links:links});
          toast(val ? "已更正前置" : "已恢复自动识别");
          await load(); await showDeps(id); return true;
        } catch (err) { toast(err.message, 7000); return false; }
      };
      if (pick === "auto") await save(0);
      else if (pick === "skip") await save("skip");
      else if (pick === "inst") pickInstalled(`「${x.name}」是哪个？`, id, save);
      else if (pick === "nx") findDepOnNexus(x.name, async nid => {
        if (!await save("nx:" + nid)) return;
        const r = await api("/api/fix-deps", {items:[{url:NX_PAGE+nid}]}).catch(err => toast(err.message,7000));
        if (r) await fixDepsDone(r);
      });
    });
  };
  bindDepTabs(d);
  q.oninput = search; if (!d.open) d.showModal(); search(); q.focus();
}
$("#btnModSheet").onclick = () => openModSheet();
const resetModelPick = () => { $("#modelPick").classList.add("hidden"); $("#setForm").elements.ai_model.classList.remove("hidden"); };
// 设置页分页：记住上次看的那页
// 要记住的界面状态存在管理器里（浏览器的本地存储有时会丢）
// state.prefs 只在这里改（state.ui 是界面版本号，别撞名），不跟着设置重新读取被覆盖
state.prefs = null;
const prefsReady = api("/api/ui-prefs").then((j) => { state.prefs = { ...(j || {}), ...(state.prefs || {}) }; }).catch(() => { state.prefs = state.prefs || {}; });
prefsReady.then(() => { const v = state.prefs?.stackAuthor; if (v !== undefined && !!v !== state.stack) { state.stack = !!v; render(); } });
function prefGet(k, dflt) { const v = state.prefs?.[k] ?? state.cfg?.ui?.[k]; if (v !== undefined && v !== null) return v; try { const x = localStorage.getItem(k); if (x !== null) return JSON.parse(x); } catch (e) {} return dflt; }
const prefWrites = new Map();
function prefSet(k, v) {
  state.prefs = { ...(state.prefs || {}), [k]: v };
  try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {}
  const write = async () => {
    try { await api("/api/ui-pref", { k, v }); }
    catch (err) {
      await new Promise(r => setTimeout(r, 500));
      try { await api("/api/ui-pref", { k, v }); }
      catch (err2) { if (state.prefs?.[k] === v) toast("设置未保存到管理器，请稍后重新修改：" + err2.message, 8000); }
    }
  };
  const p = (prefWrites.get(k) || Promise.resolve()).then(write);
  prefWrites.set(k, p);
  p.finally(() => { if (prefWrites.get(k) === p) prefWrites.delete(k); });
  return p;
}
function setTab(t) {
  t = t || "gen";  // Hazel：每次打开都从常规开始，不记上次的页
  if (!document.querySelector(`#setForm .settabs [data-tab="${t}"]`)) t = "gen";
  document.querySelectorAll("#setForm .settabs button").forEach((b) => b.classList.toggle("on", b.dataset.tab === t));
  let first = true;
  document.querySelectorAll("#setForm .setpanes section").forEach((x) => { const on = x.dataset.tab === t; x.classList.toggle("on", on); x.classList.toggle("first", on && first); if (on) first = false; });
  $("#setForm .setpanes").scrollTop = 0;
  if (t === "bk") { renderBkList(); renderStorage(); }
  if (t === "trash") renderTrash();
}
$("#setForm .settabs").addEventListener("click", (e) => { const b = e.target.closest("[data-tab]"); if (b) setTab(b.dataset.tab); });
function openSettings(t) { fillSettings(); setTab(t); if (!$("#settings").open) $("#settings").showModal(); smapiMark(); }
// 设置 → 常规 → SMAPI：装了哪个版本、有没有新版（11-23）
async function smapiMark() {
  const info = $("#smapiInfo"), b = $("#btnSmapi");
  if (!info) return;
  try {
    const c = await api("/api/game/check"), s = c.smapi;
    info.textContent = !s.installed ? "还没装 SMAPI，Mod 要靠它才能用" : (s.version ? `已安装 ${s.version}` : "已安装") + (s.latest ? ` · 新版本 ${s.latest}` : "");
    info.classList.toggle("newver", !s.installed || !!s.latest);
    b.textContent = !s.installed ? "去下载 SMAPI" : s.latest ? "去更新 SMAPI" : "去 SMAPI 官网";
    b.classList.toggle("primary", !s.installed || !!s.latest);
    b.onclick = () => openExt(s.page);
  } catch (e) { info.textContent = "没查到"; }
}
$("#btnSettings").onclick = () => openSettings();
$("#aiPreset").onchange = (e) => {
  if (!e.target.value) return;
  const [p, u, m] = e.target.value.split("|"), f = $("#setForm");
  f.elements.ai_provider.value = p; f.elements.ai_base_url.value = u; f.elements.ai_model.value = m; resetModelPick(); syncFsel(f);
};
$("#btnModels").onclick = async () => {
  const f = $("#setForm").elements, btn = $("#btnModels"), pick = $("#modelPick");
  btn.disabled = true; btn.textContent = "拉取中…";
  try {
    const r = await api("/api/models", { ai_provider: f.ai_provider.value, ai_base_url: f.ai_base_url.value.trim(), ai_api_key: f.ai_api_key.value.trim() });
    if (!r.models.length) return toast("这个服务没有返回模型，可以手动填", 5000);
    const cur = f.ai_model.value.trim();
    const list = cur && !r.models.includes(cur) ? [cur, ...r.models] : r.models;
    pick.innerHTML = list.map((m) => `<option ${m === cur ? "selected" : ""}>${esc(m)}</option>`).join("") + `<option value="\u0001">手动输入…</option>`;
    pick.classList.remove("hidden"); f.ai_model.classList.add("hidden"); syncFsel(f);
    if (!cur) f.ai_model.value = pick.value;
    toast(`拉到 ${r.models.length} 个模型`);
  } catch (err) { toast(err.message, 7000); }
  finally { btn.disabled = false; btn.textContent = "拉取模型"; }
};
$("#modelPick").onchange = (e) => {
  const f = $("#setForm").elements;
  if (e.target.value === "\u0001") { e.target.classList.add("hidden"); f.ai_model.classList.remove("hidden"); f.ai_model.focus(); return; }
  f.ai_model.value = e.target.value;
};
$("#btnDetect").onclick = async () => {
  const r = await api("/api/detect-folders");
  if (r.length) { $("#setForm").elements.mods_folder.value = r[0]; toast(r.length > 1 ? `找到 ${r.length} 个，先填了第一个` : "找到了 ✓"); }
  else toast("没自动找到，请手动填写（游戏目录下的 Mods 文件夹）", 5000);
};
$("#setSave").onclick = async () => {
  const f = $("#setForm").elements;
  const body = {
    ai_provider: f.ai_provider.value, ai_base_url: f.ai_base_url.value.trim(), ai_model: f.ai_model.value.trim(),
    mods_folder: f.mods_folder.value.trim(), max_images: +f.max_images.value || 8, translator: trOrder()[0], translate_order: trOrder(), translate_fallback: f.translate_fallback.checked,
  };
  if (f.nexus_api_key.value.trim()) body.nexus_api_key = f.nexus_api_key.value.trim();
  if (f.nexus_dl_key.value.trim()) body.nexus_dl_key = f.nexus_dl_key.value.trim();
  if (f.ai_api_key.value.trim()) body.ai_api_key = f.ai_api_key.value.trim();
  const b = $("#setSave"); b.disabled = true;
  try { await api("/api/config", body); }
  catch (err) { toast("没保存上：" + err.message, 7000); return; }
  finally { b.disabled = false; }
  toast("已保存");
  ["nexus_api_key", "nexus_dl_key", "ai_api_key"].forEach((k) => { f[k].value = ""; });
  loadCfg().then(() => { renderAccount(); return load(); }).catch(() => {});
};

// 备份全部数据
function bkSize(n) { return n > 1 << 30 ? (n / (1 << 30)).toFixed(1) + " GB" : n >= 1 << 20 ? (n / (1 << 20)).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB"; }
async function bkPoll() {
  const b = $("#btnBackup"), st = $("#bkStatus");
  let r;
  try { r = await api("/api/backup-status", {}); } catch (err) { b.disabled = false; st.textContent = "失败：" + err.message; return; }
  if (r.running) {
    b.disabled = true; b.innerHTML = `<span class="spin"></span>备份中…`;
    st.textContent = r.total ? `${r.done}/${r.total} 个文件` : "";
    setTimeout(bkPoll, 800); return;
  }
  b.disabled = false; b.textContent = "备份数据";
  renderBkList();
  if (r.error) st.textContent = "失败：" + r.error;
  else if (r.path) st.innerHTML = `已备份 ${bkSize(r.size)} <a href="#" id="bkOpen">打开所在文件夹</a>`;
}
// 回收站（11-23）：删掉的合集、移除的 Mod、卸载的游戏文件，留 30 天
async function renderTrash() {
  const box = $("#trashList");
  let r;
  try { r = await api("/api/trash", {}); } catch (e) { box.innerHTML = ""; return; }
  const it = r.items || [];
  const day = (t) => { const d = new Date(t * 1000), z = (n) => String(n).padStart(2, "0"); return `${d.getMonth() + 1}-${z(d.getDate())} ${z(d.getHours())}:${z(d.getMinutes())}`; };
  const left = (t) => Math.max(1, Math.ceil((t + r.days * 86400 - Date.now() / 1000) / 86400));
  $("#trashEmpty").disabled = !it.length;
  $("#trashCount").textContent = it.length ? `共 ${it.length} 项` : "";
  box.innerHTML = it.length ? `<ul>${it.map((x) => `<li><span class="trname"><em class="bktag">${esc(x.kind)}</em>${esc(x.name)}${x.kind === "合集" ? `<span class="muted"> · ${x.count} 个 Mod</span>` : ""}</span>
      <span class="muted" title="删除时间 ${day(x.time)}">${left(x.time)} 天后清除</span>
      <button type="button" class="mini" data-trrestore="${esc(x.tid)}">恢复</button><button type="button" class="mini danger" data-trdel="${esc(x.tid)}">彻底删除</button></li>`).join("")}</ul>`
    : `<div class="bkh muted small"><span>回收站是空的。</span></div>`;
}
$("#trashList").addEventListener("click", async (e) => {
  const rb = e.target.closest("[data-trrestore]"), db = e.target.closest("[data-trdel]");
  if (rb) {
    rb.disabled = true;
    try { const r = await api("/api/trash/restore", { tid: rb.dataset.trrestore }); toast(r.warn || `已恢复「${r.name}」`, r.warn ? 8000 : 4000); await load(); } catch (err) { toast(err.message, 7000); }
    return renderTrash();
  }
  if (db) {
    if (!(await askConfirm("彻底删除？", "删了就找不回来了。"))) return;
    try { await api("/api/trash/delete", { tid: db.dataset.trdel }); } catch (err) { toast(err.message, 6000); }
    renderTrash();
  }
});
$("#trashEmpty").onclick = async () => {
  if (!(await askConfirm("清空回收站？", "里面的东西都会彻底删除，找不回来。", "清空"))) return;
  try { await api("/api/trash/delete", {}); toast("回收站已清空"); } catch (err) { toast(err.message, 6000); }
  renderTrash();
};
async function renderBkList() {
  const box = $("#bkList");
  let r;
  try { r = await api("/api/backup-list", {}); } catch (e) { box.innerHTML = ""; return; }
  const it = r.items || [];
  const sig = JSON.stringify(it);
  if (sig === renderBkList.sig && box.innerHTML) return;  // 没变化就不重画（定时检查用）
  renderBkList.sig = sig;
  const day = (t) => { const d = new Date(t * 1000), z = (n) => String(n).padStart(2, "0"); return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())} ${z(d.getHours())}:${z(d.getMinutes())}`; };
  box.innerHTML = it.length ? `<div class="bkh muted small"><span>已有 ${it.length} 个备份，共 ${bkSize(it.reduce((n, x) => n + x.size, 0))}</span>${it.some((x) => !x.auto) ? `<button type="button" class="mini" data-bkdir="manual" title="文档\\星露管理器备份">打开手动备份</button>` : ""}${it.some((x) => x.auto) ? `<button type="button" class="mini" data-bkdir="auto" title="管理器文件夹\\更新备份">打开自动备份</button>` : ""}</div>
    <ul>${it.map((x) => `<li><span>${day(x.time)}<em class="bktag">${x.auto ? "自动 · " + esc(x.auto) : "手动"}</em></span><span class="muted">${bkSize(x.size)}</span><button type="button" class="mini" data-bkrestore="${esc(x.name)}" data-bktime="${day(x.time)}">恢复</button><button type="button" class="mini" data-bkdel="${esc(x.name)}">删除</button></li>`).join("")}</ul>`
    : `<div class="bkh muted small"><span>还没有备份。</span></div>`;
}
// 设置的「数据」页开着时，每 3 秒看一下备份文件夹：在电脑上删了备份，这里马上跟着变
setInterval(() => { if ($("#settings")?.open && $('#setForm section[data-tab="bk"]')?.classList.contains("on") && !document.hidden) renderBkList(); }, 3000);
window.addEventListener("focus", () => { if ($("#settings")?.open) renderBkList(); });
$("#bkList").addEventListener("click", async (e) => {
  const od = e.target.closest("[data-bkdir]");
  if (od) { api("/api/backup-dir", { which: od.dataset.bkdir }).catch((err) => toast(err.message, 6000)); return; }
  const rb = e.target.closest("[data-bkrestore]");
  if (rb) {
    if (!(await askConfirm("从备份恢复", `先自动备份现在的数据，再换成 ${rb.dataset.bktime} 的备份。游戏 Mods 文件夹不动。`, "恢复", "primary"))) return;
    try { await api("/api/restore", { name: rb.dataset.bkrestore }); } catch (err) { toast(err.message, 7000); return; }
    restorePoll(); return;
  }
  const b = e.target.closest("[data-bkdel]"); if (!b) return;
  if (!(await askConfirm("删除这个备份包？", "备份包不会进回收站，删了就找不回来了。"))) return;
  b.disabled = true;
  try { await api("/api/backup-delete", { name: b.dataset.bkdel }); toast("已删除"); } catch (err) { toast(err.message, 6000); }
  renderBkList();
});
$("#btnBackup").onclick = async () => {
  $("#bkStatus").textContent = "";
  try { await api("/api/backup", { game: $("#bkGame").checked, keys: $("#bkKeys").checked }); } catch (err) { toast(err.message, 7000); return; }
  bkPoll();
};
$("#bkStatus").addEventListener("click", (e) => { if (e.target.id === "bkOpen") { e.preventDefault(); api("/api/backup-open", {}).catch((err) => toast(err.message, 6000)); } });

// 公告仅通过左上角入口主动打开，不再启动时自动弹出。
const NOTICE_VER = 1;
function openNotice(then) {
  const d = $("#notice");
  d.onclose = () => {
    if ((state.cfg?.notice_seen || 0) < NOTICE_VER) { state.cfg.notice_seen = NOTICE_VER; api("/api/config", { notice_seen: NOTICE_VER }).catch(() => {}); }
    d.onclose = null; if (then) then();
  };
  if (!d.open) d.showModal();
}
$("#noticeOk").onclick = () => $("#notice").close();
$("#btnShortcut").onclick = async () => {
  try { const r = await api("/api/shortcut", {}); toast(r.ok ? "桌面上已经放好「星露管理器」图标了" : "没建成，可以在启动.bat 上右键「发送到 → 桌面快捷方式」", 6000); } catch (err) { toast(err.message, 6000); }
};
// 全屏：浏览器窗口的标题栏去不掉，全屏时就看不到了
$("#noteNotice").onclick = (e) => { e.preventDefault(); openNotice(); };
// 换了文件夹装新版：发现旧版的数据，问一句要不要搬过来
function askOldInstall(manual = false) {
  const o = state.cfg.old_install || {};
  return new Promise((done) => {
    const d = $("#files");
    d.innerHTML = `<div class="mhead"><h2>${manual ? "迁移旧版数据" : "发现旧版的星露管理器"}</h2></div>
      <label>旧版管理器文件夹<input id="oiPath" value="${esc(o.path || "")}" placeholder="粘贴旧版管理器文件夹的完整路径"></label>
      ${o.mods ? `<p class="muted small">自动找到的旧版有 ${o.mods} 个 Mod。</p>` : ""}
      <p class="muted small">请先关闭旧版，再复制设置、Mod 清单、原分类、备注、合集、图片、本地库和备份。复制后会逐文件核对，不会移动旧文件或游戏 Mod。</p>
      <div class="row end"><button id="oiSkip">${manual ? "取消" : "不用了，从头开始"}</button><button class="primary" id="oiGo">复制旧版数据</button></div>`;
    d.showModal();
    d.oncancel = (e) => e.preventDefault();
    $("#oiSkip", d).onclick = async () => { if (!manual && o.path) await api("/api/config", { old_install_skip: o.path }).catch(() => {}); d.oncancel = null; d.close(); done(false); };
    $("#oiGo", d).onclick = async () => {
      $("#oiGo", d).disabled = true; $("#oiSkip", d).disabled = true; $("#oiGo", d).innerHTML = `<span class="spin"></span>正在搬…`;
      try {
        const r = await api("/api/migrate-old", { path: $("#oiPath", d).value.trim() });
        $("#oiGo", d).innerHTML = `<span class="spin"></span>已核验 ${r.verified_files} 个文件，正在重启…`;
        const t0 = Date.now();
        const wait = async () => { try { const c = await api("/api/config"); if (!c.old_install && Date.now() - t0 > 2500) return location.reload(); } catch (e) {} setTimeout(wait, 1000); };
        setTimeout(wait, 2000);
      } catch (err) { toast(err.message, 8000); $("#oiGo", d).disabled = false; $("#oiSkip", d).disabled = false; $("#oiGo", d).textContent = "复制旧版数据"; }
    };
  });
}
$("#btnMigrateOld").onclick = () => { $("#settings").close(); askOldInstall(true); };
// 从备份恢复：完成后管理器自动重启，页面等它回来再刷新
async function restorePoll() {
  const st = $("#bkStatus");
  st.innerHTML = `<span class="spin"></span>正在恢复…`;
  document.querySelectorAll("[data-bkrestore]").forEach((b) => (b.disabled = true));
  let r = null;
  try { r = await api("/api/restore-status", {}); } catch (e) { r = null; }
  if (r && r.error) { st.textContent = r.error; renderBkList.sig = null; renderBkList(); return; }
  if (r && r.running) { setTimeout(restorePoll, 1000); return; }
  // 服务正在重启：等它回来
  const wait = async () => { try { await api("/api/rev"); location.reload(); } catch (e) { setTimeout(wait, 1000); } };
  setTimeout(wait, 1500);
}

// 新功能需要补的资料：新版第一次打开弹一次小卡片，「以后再说」就不再弹
const FILL_HINTS = [
  { id: "orig-link-v1", text: (n) => `改制 Mod 可以关联原 Mod 了，你有 ${n} 个还没关联。`,
    count: () => state.mods.filter((m) => !m.nexus_id && m.source === "custom" && m.custom_type === "modified" && !m.original_mod_id).length,
    go: () => setFState("src-modified") },
];
function setFState(v) {
  const fs = $("#fState");
  state.cat = "全部"; state.sub = ""; state.multi = []; state.fState = v;
  fs.value = v; fs._fsLabel?.();
  try { localStorage.setItem("smm-fstate", v); } catch (e) {}
  render();
}
async function showFillHint() {
  await prefsReady;
  const seen = state.prefs?.fillSeen || [];
  const h = FILL_HINTS.find((x) => !seen.includes(x.id) && x.count() > 0);
  if (!h) return;
  if (document.querySelector("dialog[open]")) { setTimeout(() => showFillHint().catch(() => {}), 5000); return; }  // 别的窗口开着，等它关了再弹
  const done = () => { prefSet("fillSeen", [...seen, h.id]); d.close(); };
  let d = $("#fillDlg");
  if (!d) { d = document.createElement("dialog"); d.id = "fillDlg"; d.className = "modal confirm"; document.body.appendChild(d); }
  d.innerHTML = `<h2>新功能</h2><p class="muted">${esc(h.text(h.count()))}</p><div class="row end"><button id="fillLater">以后再说</button><button class="primary" id="fillGo">去补充</button></div>`;
  $("#fillLater", d).onclick = done;
  $("#fillGo", d).onclick = () => { done(); h.go(); };
  d.oncancel = (e) => { e.preventDefault(); done(); };
  d.showModal();
}
setTimeout(() => showFillHint().catch(() => {}), 2500);

// 存储：清理缓存、打开日志
async function renderStorage() {
  const box = $("#stList");
  let r;
  try { r = await api("/api/storage", {}); } catch (e) { box.innerHTML = ""; return; }
  box.innerHTML = `<ul>${r.items.map((x) => `<li><label class="chk-line"><input type="checkbox" data-stk="${x.k}" ${x.size ? "checked" : "disabled"}> ${esc(x.label)}</label><span class="muted">${x.size ? bkSize(x.size) : "0"}</span></li>`).join("")}</ul>`;
  $("#btnClean").disabled = !r.total;
}
$("#btnClean").onclick = async () => {
  const keys = [...document.querySelectorAll("#stList [data-stk]:checked")].map((c) => c.dataset.stk);
  if (!keys.length) return;
  $("#btnClean").disabled = true;
  try { const r = await api("/api/storage-clean", { keys }); $("#stStatus").textContent = `已清理 ${bkSize(r.freed)}`; } catch (err) { toast(err.message, 6000); }
  renderStorage();
};
$("#btnLog").onclick = () => { location.href = "/api/log-download"; toast("日志已下载到「下载」文件夹，出问题时发给作者"); };

// 按新规则整理：分类、前置等规则更新后，由用户点一下才套到已有数据上（先自动备份）
function rulesMark() {
  // 点过「以后再说」的这批规则就不再亮红点，按钮还在「设置 → 数据」里
  const on = !!state.cfg?.rules_pending && !!state.rulesSig && prefGet("rulesQuiet", "") !== state.rulesSig;
  $("#btnRules")?.classList.toggle("dot", on);
  $("#btnSettings")?.classList.toggle("dot", on || !!appUpd?.has);
  $('#setForm .settabs [data-tab="bk"]')?.classList.toggle("dot", on);
  $('#setForm .settabs [data-tab="gen"]')?.classList.toggle("dot", !!appUpd?.has);
}
async function rulesPoll() {
  const b = $("#btnRules"), st = $("#bkStatus");
  let r;
  try { r = await api("/api/apply-rules-status", {}); } catch (err) { b.disabled = false; st.textContent = "失败：" + err.message; return; }
  if (r.running) { b.disabled = true; b.innerHTML = `<span class="spin"></span>${esc(r.step || "整理中…")}`; setTimeout(rulesPoll, 800); return; }
  b.disabled = false; b.textContent = "按新规则整理";
  if (state.cfg) state.cfg.rules_pending = r.pending;
  rulesMark();
  st.textContent = r.error ? "失败：" + r.error : r.done ? `已整理，${r.done} 个 Mod 正在重新归类` : "已整理";
  loadCfg().then(load).catch(() => {});
}
// 升级后第一次打开：有新规则就弹一次（同一批规则只弹一次）；关掉后在 设置 → 数据 → 按新规则整理 还能找到
async function rulesAuto() {
  let r;
  try { r = await api("/api/apply-rules-status", {}); } catch { return; }
  if (!r.rules?.length) return;
  const sig = r.rules.join("|");
  state.rulesSig = sig; rulesMark();
  if (prefGet("rulesAsked", "") === sig) return;
  prefSet("rulesAsked", sig);
  if (!(await askConfirm("新版有新的整理规则", "要现在整理吗？会先自动备份。以后也能在「设置 → 数据 → 按新规则整理」里做。", "开始整理", "primary", r.rules, "以后再说"))) { prefSet("rulesQuiet", sig); rulesMark(); return; }
  try { await api("/api/apply-rules", {}); } catch (err) { toast(err.message, 7000); return; }
  rulesPoll();
}
// 有新版：每次打开管理器都弹，「以后再说」要等 5 秒才能点（11-27 Hazel）
var appUpd = null;  // var：rulesMark 可能在这行之前就被调用
async function showAppUpdate(wait = 0) {
  const u = appUpd; if (!u?.has) return;
  const old = u.mine ? `你现在用的是 ${verNum(u.mine)}，` : "";
  if (u.pkg) {  // 能自动更新：点一下就装（11-24 Hazel）
    if (await askConfirm("有新版本", `${old}新版本 ${verNum(u.version)}。旧版的问题新版可能已经修好，请先更新。Mod 和设置都会保留。`, "立即更新", "primary", u.changes?.length ? u.changes : null, "以后再说", wait)) runAppUpdate();
    return;
  }
  const text = `${old}新版本 ${verNum(u.version)}。旧版的问题新版可能已经修好，请先更新。` + (u.note || (u.url ? "" : "去作者社群下载，覆盖解压到现在的文件夹就行。"));
  if (await askConfirm("有新版本", text, u.url ? "去下载" : "知道了", "primary", u.changes?.length ? u.changes : null, "以后再说", wait) && u.url) openExt(u.url);
}
// 立即更新：下载 → 安装 → 管理器自己重启 → 页面自动刷新
async function runAppUpdate() {
  let d = $("#appUpdDlg");
  if (!d) { d = document.createElement("dialog"); d.id = "appUpdDlg"; d.className = "modal dlprog"; document.body.appendChild(d); }
  d.oncancel = (e) => e.preventDefault();  // 装的时候不让关
  const draw = (t, pct) => { d.innerHTML = `<div class="mhead"><h2>更新管理器</h2></div><p class="dpmsg">${esc(t)}</p><div class="dpbar${pct == null ? " busy" : ""}"><i style="width:${pct || 0}%"></i></div>`; };
  draw("正在下载新版…", 0); d.showModal();
  const fail = (msg) => { d.close(); toast(msg, 9000); if (appUpd?.url) openExt(appUpd.url); };
  let before;
  try { before = (await (await fetch("/api/ping")).json()).boot; await api("/api/app-update/install", {}); }
  catch (err) { return fail(err.message || "更新失败"); }
  for (;;) {
    await new Promise((r) => setTimeout(r, 700));
    let p;
    try { p = await (await fetch("/api/app-update/progress")).json(); } catch { p = { state: "重启" }; }
    if (p.state === "出错") return fail(p.error);
    if (p.state === "重启") break;
    draw(p.text || "正在下载新版…", p.state === "下载" ? p.pct : 100);
  }
  draw("装好了，正在重启…", null);
  for (let i = 0; i < 120; i++) {  // 等新版起来（最多 1 分钟）；换了端口就跳过去
    await new Promise((r) => setTimeout(r, 500));
    try {
      const j = await (await fetch("/api/ping")).json();
      if (j.boot && j.boot !== before) { location.reload(); return; }
      const p = await (await fetch("/api/app-update/progress")).json();
      if (p.state === "出错") return fail(p.error);
      if (p.state === "下载" || p.state === "安装") draw(p.text || "正在更新…", p.pct);
    }
    catch { if (i % 6 === 5) { const p = await findMovedServer(); if (p) { location.href = `http://127.0.0.1:${p}/`; return; } } }
  }
  d.close(); toast("尚未确认更新完成，请稍后查看版本状态；不要强行结束后台任务。", 10000);
}
let appUpdLoad = null;
function appUpdFetch(force = false) {
  if (appUpdLoad) return appUpdLoad;
  if (appUpd && !force) return Promise.resolve(appUpd);
  appUpdLoad = fetch("/api/app-update" + (force ? "?force=1" : ""), { signal: AbortSignal.timeout(12000) })
    .then(r => { if (!r.ok) throw new Error("检查失败"); return r.json(); })
    .then(u => { appUpd = u; return u; })
    .catch(() => { appUpd = { mine: appUpd?.mine, has: false, error: "暂时无法检查更新，请稍后重试。" }; return appUpd; })
    .finally(() => { appUpdLoad = null; verMark(); });
  verMark();
  return appUpdLoad;
}
async function appUpdateAuto() {
  if (!(await appUpdFetch())) return;
  if (!appUpd?.has) return;
  verMark();
  try { if (sessionStorage.getItem("updShown") === appUpd.version) return; sessionStorage.setItem("updShown", appUpd.version); } catch {}  // 同一个窗口自动刷新时不重复弹
  await showAppUpdate(5);
}
// 设置 → 常规 → 版本：有新版时按钮可点，设置上带小红点
function verMark() {
  const u = appUpd || {}, info = $("#verInfo"), b = $("#btnNewVer");
  const d8 = verNum;
  if (info) { info.textContent = (u.mine ? `当前版本 ${d8(u.mine)}` : appUpdLoad ? "" : "本地版") + (appUpdLoad ? " 正在检查更新…" : u.error ? ` · ${u.error}` : u.has ? ` · 新版本 ${d8(u.version)}` : u.mine ? " · 已是最新" : ""); info.classList.toggle("newver", !!u.has); }
  if (b) { b.disabled = !!appUpdLoad || (!u.mine && !u.error && !!appUpd); b.textContent = appUpdLoad ? "正在检查…" : u.error ? "重试" : u.has ? (u.pkg ? "立即更新" : "有新版本，查看") : "检查更新"; b.classList.toggle("primary", !!u.has && !appUpdLoad); }
  rulesMark();
}
$("#btnNewVer").onclick = async () => {
  if (appUpd?.has) return showAppUpdate();
  const u = await appUpdFetch(true);
  if (u?.has) await showAppUpdate();
  else if (u?.error) toast(u.error, 6000);
};
$("#btnRules").onclick = async () => {
  let r;
  try { r = await api("/api/apply-rules-status", {}); } catch (err) { toast(err.message, 6000); return; }
  if (!r.rules.length) { $("#bkStatus").textContent = "已经是最新规则，不用整理"; return; }
  if (!(await askConfirm("按新规则整理", "会先自动备份，再改这些：", "开始整理", "primary", r.rules))) return;
  $("#bkStatus").textContent = "";
  try { await api("/api/apply-rules", {}); } catch (err) { toast(err.message, 7000); return; }
  rulesPoll();
};
(async () => {
  await loadCfg();
  appUpdFetch();
  if (state.cfg.old_install) { await askOldInstall(); await loadCfg(); }
  const back = state.restore;
  if (back && back.shown) state.shown = back.shown;
  if (back) state.listKey = [view, state.cat, state.sub, state.fState, state.fSort, state.q, JSON.stringify(state.multi), state.mAll, state.pack, state.selMode, state.cat === UPD && state.updReview].join("|");
  if (state.q && $("#search")) $("#search").value = state.q;
  await load();
  if (back) {
    state.restore = null;
    requestAnimationFrame(() => listScroll().scrollTo(0, back.y || 0));
    if (back.openId && state.mods.some((m) => m.id === back.openId)) openDetail(back.openId).catch(() => {});
    if (back.openId || back.y) { await showReleaseHistory(true); return; }  // 刷新仍只显示尚未看过的本版更新说明
  }
  const needSetup = () => {
    if (!state.cfg.guide_done && !state.mods.length && !(state.ignored || []).length) return openGuide();  // 新用户：三步引导
    if (!state.cfg.guide_done && !state.cfg.nexus_api_key_set) openSettings("nexus");
  };
  const next = async () => { await showReleaseHistory(true); await rulesAuto(); await appUpdateAuto(); if (state.mods.length) await openComponentCandidates(true); needSetup(); };
  next();
})();
// 往下滚时，顶部栏加一条细阴影
const updateListScroll = () => {
  $(".bar").classList.toggle("stuck", listScrollY() > 8);
  $("#toTop").classList.toggle("show", listScrollY() > 500);
};
window.addEventListener("scroll", updateListScroll, { passive: true });
$("#listScroll").addEventListener("scroll", updateListScroll, { passive: true });
$("#toTop").onclick = () => listScroll().scrollTo({ top: 0, behavior: "smooth" });

// ---------------------------------------------------------- 下拉框（替换系统自带的样式）
const CHEV = `<svg class="chev" viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>`;
const CHECK = `<svg class="ck" viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 5 5 9-10"/></svg>`;
function fancySelect(sel) {
  if (sel.dataset.fancy) return;
  sel.dataset.fancy = "1";
  const wrap = document.createElement("div"), btn = document.createElement("button"), pop = document.createElement("div");
  wrap.className = "fsel"; btn.type = "button"; btn.className = "fsel-btn"; pop.className = "fsel-pop";
  if (sel.title) btn.title = sel.title;
  sel.before(wrap); wrap.append(sel, btn, pop);
  const label = () => { const o = sel.selectedOptions[0]; btn.innerHTML = `<span>${esc(o ? o.textContent : "")}</span>${CHEV}`; };
  sel._fsLabel = label; label();
  const opt = (o) => `<button type="button" data-i="${o.index}" class="${o.selected ? "on" : ""}"><span>${esc(o.dataset.short || o.textContent)}</span>${o.selected ? CHECK : ""}</button>`;
  const render = () => {  // <optgroup> 显示成可展开的二级菜单
    pop.innerHTML = [...sel.children].map((el) => el.tagName === "OPTGROUP"
      ? `<div class="fg"><button type="button" class="fg-h" data-g><span>${esc(el.label)}</span>${CHEV}</button><div class="fg-items">${[...el.children].map(opt).join("")}</div></div>`
      : el.hasAttribute("data-ph") ? "" : opt(el)).join("");  // 占位的「＋ 添加分类」只当按钮文字，不进列表
    const on = pop.querySelector(".on"); if (on && !on.closest(".fg")) on.scrollIntoView({ block: "nearest" });
    pop.querySelectorAll(".fg").forEach((g) => {  // 鼠标移到大分类上，右边弹出它的子分类
      g.onmouseenter = () => { clearTimeout(pop._t); flyOpen(g); };
      g.onmouseleave = () => { pop._t = setTimeout(() => g.classList.remove("open"), 180); };
    });
  };
  const flyOpen = (g) => {
    pop.querySelectorAll(".fg.open").forEach((x) => x !== g && x.classList.remove("open"));
    g.classList.add("open");
    const r = g.firstElementChild.getBoundingClientRect(), it = g.lastElementChild;
    const w = it.offsetWidth || 180, hgt = it.offsetHeight;
    const left = r.right + w + 8 > innerWidth ? r.left - w - 2 : r.right + 2;
    it.style.left = left + "px";
    it.style.top = Math.max(8, Math.min(r.top - 6, innerHeight - hgt - 8)) + "px";
  };
  btn.onclick = (e) => {
    e.stopPropagation();
    document.querySelectorAll(".fsel.open").forEach((w) => w !== wrap && w.classList.remove("open"));
    if (wrap.classList.toggle("open")) {
      render();
      const r = btn.getBoundingClientRect();  // 下面放不下就往上展开
      const below = window.innerHeight - r.bottom;
      wrap.classList.toggle("up", sel.id !== "packSelect" && below < 260 && r.top > below);
      if (sel.id === "packSelect") pop.style.maxHeight = Math.min(300, Math.max(0, below - 14)) + "px";
    }
  };
  pop.onclick = (e) => {
    const g = e.target.closest("[data-g]");
    if (g) {
      e.stopPropagation();
      const box = g.parentElement;
      if (box.classList.contains("open")) box.classList.remove("open"); else flyOpen(box);  // 触屏点一下也能打开
      return;
    }
    const b = e.target.closest("[data-i]"); if (!b) return;
    e.stopPropagation();
    wrap.classList.remove("open");
    if (sel.selectedIndex === +b.dataset.i) return;
    sel.selectedIndex = +b.dataset.i; label();
    sel.dispatchEvent(new Event("change", { bubbles: true }));
  };
}
const syncFsel = (root = document) => root.querySelectorAll("select").forEach((s) => s._fsLabel && s._fsLabel());
document.addEventListener("click", () => document.querySelectorAll(".fsel.open").forEach((w) => w.classList.remove("open")));
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  const scope = topDialog() || document;
  const dropdowns = [...scope.querySelectorAll(".fsel.open")];
  const flyouts = dropdowns.flatMap(w => [...w.querySelectorAll(".fg.open")]);
  const menus = [...scope.querySelectorAll("details.menu[open], details.minimenu[open]")];
  if (!dropdowns.length && !menus.length) return;
  e.preventDefault(); e.stopPropagation();  // 下拉/子菜单优先消费 ESC，不再触发父 dialog 的默认关闭
  if (flyouts.length) { flyouts.forEach(g => g.classList.remove("open")); flyouts.at(-1).querySelector(".fg-h")?.focus(); }
  else if (dropdowns.length) { dropdowns.forEach(w => w.classList.remove("open")); dropdowns.at(-1).querySelector(".fsel-btn")?.focus(); }
  else { menus.forEach(d => d.removeAttribute("open")); menus.at(-1).querySelector("summary")?.focus(); }
}, true);
document.querySelectorAll("#settings select").forEach(fancySelect);
// 工具栏：状态筛选 + 排序（记住上次的选择）
for (const [id, key, prop] of [["#fState", "smm-fstate", "fState"], ["#fSort", "smm-fsort", "fSort"]]) {
  const el = $(id);
  el.value = state[prop]; if (el.selectedIndex < 0) { el.value = ""; state[prop] = ""; }  // 记住的选项已经不在了（比如挪到了左边）
  el.onchange = () => { state[prop] = el.value; try { localStorage.setItem(key, el.value); } catch (e) {} render(); };
  fancySelect(el);
}
// 弹窗打开时浏览器会自动聚焦第一个链接/按钮，显示一个黑框；打开后取消这个自动聚焦
{
  const sm = HTMLDialogElement.prototype.showModal;
  HTMLDialogElement.prototype.showModal = function () {
    sm.call(this);
    const a = document.activeElement;
    if (a && this.contains(a) && a.tagName !== "TEXTAREA" && a.tagName !== "INPUT") a.blur();
  };
}

// ---------------------------------------------------------- 总结报告（全部本地计算，不用 AI）
function reportHotkey(m) {  // 说明里提到的快捷键：只留写出了具体按键的句子，按键单独拿出来
  const out = [];
  for (const line of (m.guide_zh || "").split(/\n/)) {
    const t = line.replace(/^[#\-*\s·]+/, "").replace(/\*\*/g, "").replace(/\s+/g, " ").trim();
    if (!t || /未说明|未提供|未提及|无需|不需要|没有按键|无按键|具体按键见|可在.{0,6}(设置|配置)/.test(t)) continue;
    const k = t.match(/(?:按(?:下|住)?|快捷键(?:是|为)?|默认(?:键|按键)?(?:是|为)?)\s*[`'「“『【(（]?\s*((?:(?:Ctrl|Shift|Alt)\s*\+\s*)*(?:F\d{1,2}|[A-Za-z0-9`~\\/\[\];',.=-]|Tab|Space|空格|Esc|Home|End|Insert|Delete|PageUp|PageDown))\s*[`'」”』】)）]?\s*(?:键|$|[，。,；;\s])/i);
    if (!k) continue;
    out.push({ key: k[1].replace(/\s+/g, "").replace(/^空格$/, "Space"), text: t.length > 48 ? t.slice(0, 46) + "…" : t });
    if (out.length >= 3) break;
  }
  return out;
}
// SMAPI 日志里的英文原因 → 中文
function smapiReason(r) {
  const t = String(r || "");
  if (/no longer compatible/i.test(t)) return "和当前游戏/SMAPI 版本不兼容，要换新版";
  if (/obsolete/i.test(t)) return "已过时：功能已经并进游戏或 SMAPI，可以删掉";
  if (/newer version of SMAPI/i.test(t)) return "要先更新 SMAPI";
  if (/newer version of (the game|Stardew)/i.test(t)) return "要更新游戏";
  if (/needs mods which aren't installed|requires? .*not installed/i.test(t)) return "缺前置：" + (t.match(/\(([^)]*)\)/) || [, ""])[1];
  if (/disabled|is a duplicate|more than once/i.test(t)) return "装了重复的两份";
  if (/manifest/i.test(t)) return "文件不完整（manifest 有问题）";
  return t;
}
const BROKEN_KIND = { broken: "代码坏了（游戏更新后不兼容）", unsafe: "绕过了安全检查", serializer: "会改存档格式，删掉前先备份存档", obsolete: "用了过时的写法，SMAPI 自动修过" };
const V16 = 1710806400; // 2024-03-19，星露谷 1.6 发布，大量旧 Mod 从这时起失效
// 按键显示成好认的样子
const KEY_ZH = { LeftShift: "左Shift", RightShift: "右Shift", LeftControl: "左Ctrl", RightControl: "右Ctrl", LeftAlt: "左Alt", RightAlt: "右Alt",
  LeftWindows: "Win", RightWindows: "Win", MouseLeft: "鼠标左键", MouseRight: "鼠标右键", MouseMiddle: "鼠标中键", MouseX1: "鼠标侧键1", MouseX2: "鼠标侧键2",
  OemTilde: "~", OemPlus: "=", OemMinus: "-", OemComma: ",", OemPeriod: ".", OemQuestion: "/", OemSemicolon: ";", OemQuotes: "'", OemOpenBrackets: "[",
  OemCloseBrackets: "]", OemPipe: "\\", OemBackslash: "\\", Back: "Backspace", Escape: "Esc", Up: "↑", Down: "↓", Left: "←", Right: "→",
  ControllerBack: "手柄 Back", ControllerStart: "手柄 Start", LeftShoulder: "手柄 LB", RightShoulder: "手柄 RB", LeftTrigger: "手柄 LT", RightTrigger: "手柄 RT",
  LeftStick: "手柄左摇杆按下", RightStick: "手柄右摇杆按下", DPadUp: "手柄十字↑", DPadDown: "手柄十字↓", DPadLeft: "手柄十字←", DPadRight: "手柄十字→" };
const keyZh = (k) => KEY_ZH[k] || (/^D\d$/.test(k) ? k.slice(1) : /^NumPad\d$/.test(k) ? "小键盘" + k.slice(6) : /^Controller[ABXY]$/.test(k) ? "手柄 " + k.slice(10) : k);
const isPad = (c) => c.some((k) => /^(Controller|LeftShoulder|RightShoulder|LeftTrigger|RightTrigger|LeftStick|RightStick|DPad|LeftThumb|RightThumb|BigButton)/.test(k));
const comboKey = (c) => c.map((k) => k.replace(/^(Left|Right)(Shift|Control|Alt)$/, "$2")).sort().join("+");
// 设置项名字 → 好翻译的英文（去掉结尾的 Key/Hotkey/Button，否则会被翻成「钥匙」「热键」）
const fieldName = (f) => {
  const raw = f.split(".").pop().replace(/([a-z])([A-Z])/g, "$1 $2").replace(/_/g, " ").trim();
  const t = raw.replace(/\b(key ?binds?|key ?bindings?|hot ?keys?|keys?|buttons?|binds?|bindings?|shortcuts?)$/i, "").trim();
  return t || "打开 / 切换";
};

function buildReport(log, scan, ov, scope) {
  const ms = allMods(), now = Date.now() / 1000;
  const inst = ms.filter((m) => m.installed), on = inst.filter((m) => !m.disabled);
  const all = scope === "all", base = all ? ms : inst, notInst = ms.filter((m) => !m.installed);
  const esc_ = esc, link = (m) => `<a href="${esc_(m.url || "#")}" data-mid="${esc_(m.id)}">${esc_(title(m))}</a>`;  // 点开管理器里的详情页
  const byUid = new Map(); for (const m of inst) for (const u of m.unique_ids || []) byUid.set(u.toLowerCase(), m);
  const byName = (n) => ms.find((m) => norm(m.name) === norm(n) || norm(title(m)) === norm(n));
  const nm = (n) => { const m = byName(n); return m ? link(m) : esc_(n); };
  const uniq = (rows) => { const s = new Set(); return rows.filter((r) => !s.has(r) && s.add(r)); };
  const isDupReason = (r) => /duplicate|more than once/i.test(r || "");

  // 装了好几份（算冲突）
  const dup = [];
  for (const d of scan?.dups || []) {
    const m = byUid.get(d.uid.toLowerCase());
    dup.push(`<li>${m ? link(m) : esc_(d.uid)}：装了 ${d.folders.length} 份（${d.folders.map((f) => esc_(f.folder) + (f.version ? " v" + esc_(f.version) : "") + (f.disabled ? "，已停用" : "")).join("；")}）</li>`);
  }
  if (log && log.found) for (const x of log.skipped) if (isDupReason(x.reason)) dup.push(`<li>${nm(x.name)}：装了两份，只加载了一份</li>`);
  const seenNx = new Map(), seenNm = new Map();
  for (const m of inst) {
    if (m.nexus_id) { const o = seenNx.get(m.nexus_id); if (o) dup.push(`<li>${link(o)} 和 ${link(m)}：管理器里记了两条</li>`); else seenNx.set(m.nexus_id, m); }
    const k = norm(m.name); if (k.length >= 4) { const o = seenNm.get(k); if (o && o.nexus_id !== m.nexus_id) dup.push(`<li>${link(o)} 和 ${link(m)}：同名，可能是两个版本</li>`); else if (!o) seenNm.set(k, m); }
  }

  // 快捷键（冲突要用）
  const hk = (scan?.hotkeys || []).map((h) => ({ ...h, mod: byUid.get((h.uid || "").toLowerCase()) || inst.find((m) => norm(m.name) === norm(h.name) || (m.local_folders || []).some((f) => norm(f) === norm(h.folder))) }));
  const keyUse = new Map();
  for (const h of hk) for (const b of h.binds) for (const c of b.keys) if (!isPad(c)) {
    const k = comboKey(c); const arr = keyUse.get(k) || []; if (!arr.some((x) => x.h === h)) arr.push({ h, b }); keyUse.set(k, arr);
  }
  const clash = [...keyUse.entries()].filter(([, v]) => v.length > 1);
  const clashOf = (h, c) => (keyUse.get(comboKey(c)) || []).filter((x) => x.h !== h);

  // 2 装了多份（文件冲突 2026-11-22 Hazel 删了；快捷键撞了在「快捷键合集」里标红）
  const conf = [...dup];

  // 同一个原因的合成一条：「原因（3）：A、B、C」
  // 每组：标题一行，下面竖着排
  const grp = (label, items, extra = "") => items.length ? `<li class="rg"><div class="rgh"><b>${label}（${items.length}）</b>${extra}</div><ul class="rgl">${items.map((x) => `<li>${x}</li>`).join("")}</ul></li>` : "";
  const cnt = {};
  // 3 不兼容（只看已安装的）
  const inc = [], incIds = new Set();
  if (log && log.found) {
    const sk = log.skipped.filter((x) => !isDupReason(x.reason));
    const byR = new Map(); for (const x of sk) { const r = smapiReason(x.reason); byR.set(r, [...(byR.get(r) || []), nm(x.name)]); }
    for (const [r, l] of byR) inc.push(grp("游戏没加载：" + esc_(r), l));
    const wb = new Map(); for (const x of log.warned) if (x.kind !== "obsolete") { const r = BROKEN_KIND[x.kind] || x.kind; wb.set(r, [...(wb.get(r) || []), nm(x.name)]); }
    for (const [r, l] of wb) inc.push(grp(esc_(r), l));
    inc.push(grp("上次游戏报错", log.errors.slice(0, 15).map((x) => `${nm(x.name)}<span class="muted">（${x.count} 次）</span>`)));
    cnt.inc = sk.length + log.warned.filter((x) => x.kind !== "obsolete").length + Math.min(15, log.errors.length);
  }
  const OLD_FW = { JA: "Json Assets", DGA: "DGA", CF: "Custom Furniture" };
  const fwOld = inst.filter((m) => (m.content?.frameworks || []).some((f) => OLD_FW[f]));
  inc.push(grp("旧框架，1.6 不支持", fwOld.map((m) => `${link(m)}<span class="muted">（${(m.content.frameworks || []).filter((f) => OLD_FW[f]).map((f) => OLD_FW[f]).join("、")}）</span>`)));
  const preV16 = inst.filter((m) => (m.content?.frameworks || []).includes("SMAPI") && m.nexus_updated && m.nexus_updated < V16);
  inc.push(grp("1.6 前就停更的代码 Mod", preV16.map((m) => `${link(m)}<span class="muted">（${new Date(m.nexus_updated * 1000).getFullYear()}）</span>`)));
  const miss = inst.filter((m) => missingRequired(m).length);
  inc.push(grp("缺必需前置", miss.map((m) => `${link(m)}<span class="muted">（缺 ${missingRequired(m).map((d) => esc_(d.name)).join("、")}）</span>`), `<button class="small-btn rgbtn" data-gofix>去处理</button>`));
  cnt.inc = (cnt.inc || 0) + fwOld.length + preV16.length + miss.length;

  // 4 过时（只看已安装的）
  const old = [];
  const upd = inst.filter(hasUpdate);
  old.push(grp("有新版本", upd.map((m) => `${link(m)}<span class="muted">（${esc_(updateTip(m))}）</span>`)));
  const review = inst.filter(needsUpdateReview), smu = [];
  for (const u of log?.found ? log.updates || [] : []) {
    // 用 Nexus 编号定位记录，再核对同名组件；不把另一分支或旧日志当作更新结论。
    let nid = 0;
    try { const url = new URL(u.url); if (/^(www\.)?nexusmods\.com$/i.test(url.hostname)) nid = +(url.pathname.match(/^\/stardewvalley\/mods\/(\d+)(?:\/|$)/i)?.[1] || 0); } catch (e) {}
    const matches = nid ? inst.filter(m => +m.nexus_id === nid && !m.ignored) : [];
    const m = matches.length === 1 ? matches[0] : null, a = m?.update_assessment;
    const components = (a?.components || []).filter(c => norm(u.name) && (norm(c.name) === norm(u.name) || norm(c.uid) === norm(u.name)));
    const c = components.length === 1 ? components[0] : null;
    if (m && hasUpdate(m) && c?.state === "update" && c.target_version === u.version && u.have && c.version === u.have) continue;
    const why = !m ? "未能唯一对应已安装的 Mod" : !c ? "尚未对应到具体组件" : u.have && c.version !== u.have ? "本地版本与上次日志不同，旧提示仅供参考" : a?.stale ? "上次核查已失效" : c.state === "current" ? "当前组件未发现新版本，请勿据此跨分支更新" : c.state === "update" ? "与已确认更新的版本不一致，请核查" : "尚未确认更新";
    smu.push(`${m ? link(m) + " · " + esc_(u.name) : esc_(u.name)}<span class="muted">（SMAPI v${esc_(u.have || "?")} → v${esc_(u.version)}；${esc_(why)}）</span>${/^https?:\/\//i.test(u.url || "") ? ` <a href="${esc_(u.url)}" target="_blank">查看来源</a>` : ""}`);
  }
  const reviewRows = [grp("待核查的 Mod", review.map(m => `${link(m)}<span class="muted">（${esc_(updateTip(m))}）</span>`)), grp("SMAPI 提示有新版本（仅线索）", uniq(smu))].filter(Boolean);
  const kwOld = base.filter((m) => /outdated|obsolete|deprecated|abandoned|no longer (updated|maintained)|not compatible|已过时|不再更新|停更/i.test([m.name, m.summary, m.summary_zh].join(" ")));
  old.push(grp("作者说已停更", kwOld.map(link)));
  const gone = base.filter((m) => HIDDEN_NX.has(m.nexus_status));
  old.push(grp("Nexus已下架", gone.map((m) => esc_(title(m)))));
  // 全部模式：还没下载的里，1.6 发布前就停更的（下载前最好看看评论区）
  const nlPre = all ? notInst.filter((m) => m.nexus_updated && m.nexus_updated < V16 && !kwOld.includes(m) && !gone.includes(m)) : [];
  old.push(grp("未下载的里 1.6 前就停更的", nlPre.map((m) => `${link(m)}<span class="muted">（${new Date(m.nexus_updated * 1000).getFullYear()}）</span>`)));
  cnt.old = upd.length + kwOld.length + gone.length + nlPre.length;

  // 1 功能重叠：每个 Mod 由 AI 标一次「目的」并记住，目的相同的归一组（同一批 Mod 每次结果一样）
  const byId = new Map(ms.map((m) => [m.id, m]));
  const ovs = ov?.[all ? "all" : "inst"];
  // 默认只看「功能」分类的 Mod（11-23 Hazel：美化类换风格不算重叠）；取消勾选看全部
  const funcOnly = prefGet("ovFuncOnly", true) !== false;
  const isFunc = (m) => tagsOf(m).some((t) => t.category === "功能");
  const ovRows = (ovs?.groups || []).map((g) => { const l = g.ids.map((i) => byId.get(i)).filter((m) => m && (!funcOnly || isFunc(m))); return l.length > 1 ? grp(esc_(g.what), l.map(link)) : ""; }).filter(Boolean);
  const ovNote = !ovs ? "" : !ovs.done ? "找出目的相同的 Mod（做法不同也算）。用 AI 检查一次，之后结果固定。" : `目的相同的放一组，仅供参考。${ovs.left ? `上次检查后新装了 ${ovs.left} 个，还没看过。` : ""}`;
  const ovFunc = ovs?.done ? `<label class="chk-line ovfunc"><input type="checkbox" id="ovFunc" ${funcOnly ? "checked" : ""}> 只看功能类 Mod</label>` : "";
  const ovAct = !ovs ? "" : !ovs.done ? `<button class="small-btn" id="ovRun">用 AI 检查</button>`
    : `${ovs.left ? `<button class="small-btn" id="ovRun" title="只让 AI 看这些还没检查过的 Mod，已有结果不动">检查新装的 ${ovs.left} 个</button>` : ""}<button class="small-btn" id="ovReset">全部重查</button>`;
  const secs = [["功能重叠", ovRows, ovNote + ovFunc, !ovs?.done, ovAct],
    ["装了多份", uniq(conf), "同一个 Mod 装了几份，游戏只会加载一份。"],
    ["不兼容", inc.filter(Boolean), log && log.found ? `依据上次游戏日志（${new Date(log.mtime * 1000).toLocaleString("zh-CN")}）。` : "没有游戏日志，按框架和更新时间推测。"],
    ["过时", old.filter(Boolean), "有新版、停更或下架的。"],
    ["更新待核查", reviewRows, "无法确认的文件及 SMAPI 上次游戏的线索，不计入有更新。"]];
  const n = { 不兼容: cnt.inc, 过时: cnt.old, 更新待核查: review.length + uniq(smu).length };
  let h = `<p class="rptscope">${all ? `全部 ${ms.length} 个 Mod（已安装 ${inst.length}）` : `已安装 ${inst.length} 个 Mod（启用 ${on.length}）`}<span class="muted"> · ${new Date().toLocaleString("zh-CN")}</span></p>`;  // 画完挪到标题旁
  const shut = prefGet("rptShut", []);  // 上次收起的大节
  const sec = (id, head, act, body) => `<details class="rsec" id="rpt-${id}" ${shut.includes(id) ? "" : "open"}><summary class="rpth"><svg class="ico chev" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg><span>${head}</span>${act ? `<span class="rpta">${act}</span>` : ""}</summary>${body}</details>`;
  for (const [t, r, note, unk, act] of secs) h += sec(t, `${t}${unk ? "" : `（${n[t] ?? r.length}）`}`, act, `<p class="muted small">${note}</p>` + (unk ? "" : r.length ? `<ul class="rgs">${r.join("")}</ul>` : `<p class="muted">无</p>`));

  // 5 快捷键合集
  const nClash = new Set(clash.flatMap(([, v]) => v.map((x) => x.h))).size;
  let hb = `<p class="muted small">${nClash ? `<b class="er">${clash.length} 个按键撞了（标红）。</b>` : ""}黑字读自 Mod 的设置文件，灰字摘自 Mod 说明。</p>`;
  if (!scan?.ok) hb += `<p class="muted">没设置 Mods 文件夹。</p>`;
  const groups = [];  // 每个 Mod 一组行：设置文件读到的 + 说明里写的，放在同一张表里
  const hasClash = (x) => x.binds.some((b) => b.keys.some((c) => !isPad(c) && clashOf(x, c).length));
  for (const x of hk) {
    const rows = [], clashy = hasClash(x), nm0 = x.mod ? title(x.mod) : x.name;
    const binds = x.binds.filter((b) => b.keys.some((c) => !isPad(c)) || x.binds.length === 1);  // 只有手柄键的设置项不占行
    binds.forEach((b, i) => {
      const keys = b.keys.filter((c) => !isPad(c)).length ? b.keys.filter((c) => !isPad(c)) : b.keys;
      const txt = [nm0, b.field, keys.map((c) => c.map(keyZh).join("+")).join(" ")].join(" ").toLowerCase();
      rows.push(`<tr data-hk="${esc_(txt)}" class="${i ? "" : "first"}${clashy ? " has-clash" : ""}"><td>${i ? "" : (x.mod ? link(x.mod) : esc_(x.name))}</td><td><span ${/[a-z]/i.test(fieldName(b.field)) ? `data-hkf="${esc_(fieldName(b.field))}"` : ""} title="${esc_(b.field)}">${esc_(fieldName(b.field))}</span></td><td>${keys.map((c) => { const cl = isPad(c) ? [] : clashOf(x, c); return `<kbd class="${cl.length ? "clash" : ""}" ${cl.length ? `title="和 ${esc_(cl.map((o) => o.h.mod ? title(o.h.mod) : o.h.name).join("、"))} 撞了"` : ""}>${esc_(c.map(keyZh).join(" + "))}</kbd>`; }).join(" ")}</td></tr>`);
    });
    groups.push({ name: nm0, clashy, rows });
  }
  for (const m of on.filter((m) => !hk.some((x) => x.mod === m))) {
    const l = reportHotkey(m); if (!l.length) continue;
    groups.push({ name: title(m), clashy: false, rows: l.map((x, i) => `<tr data-hk="${esc_((title(m) + " " + x.text + " " + x.key).toLowerCase())}" class="${i ? "" : "first"}"><td>${i ? "" : link(m)}</td><td class="muted" title="Mod 说明里写的，设置文件里没读到">${esc_(x.text)}</td><td><kbd>${esc_(x.key)}</kbd></td></tr>`) });
  }
  groups.sort((a, b) => (b.clashy - a.clashy) || a.name.localeCompare(b.name, "zh"));
  const rows = groups.flatMap((g) => g.rows);
  if (rows.length) hb += `<div class="hkbar"><input id="hkFind" placeholder="搜 Mod、功能或按键"><label class="check small"><input type="checkbox" id="hkClash"> 只看撞键</label></div>
    <table class="rpt hk"><tr><th>Mod</th><th>功能</th><th>按键</th></tr>${rows.join("")}</table>`;
  else if (scan?.ok) hb += `<p class="muted">无</p>`;
  h += sec("快捷键", "快捷键合集", "", hb);
  return h;
}
async function translateHotkeyNames(d) {
  const els = [...d.querySelectorAll("[data-hkf]")];
  if (!els.length || ((state.cfg?.translator || "microsoft") === "ai" && !state.cfg?.ai_api_key_set && !state.cfg?.translate_fallback)) return;
  const names = [...new Set(els.map((e) => e.dataset.hkf))];
  try {
    const j = await api("/api/translate-list", { items: names.map((t) => ({ id: "hk", text: t })) });
    const zh = new Map(names.map((t, i) => [t, (j.zh || [])[i]]));
    els.forEach((e) => { const z = zh.get(e.dataset.hkf); if (z && e.isConnected) { e.textContent = z; e.title = e.dataset.hkf; } });
  } catch (e) {}
}
async function openReport() {
  const d = $("#report");
  d.innerHTML = `<div class="mhead"><h2>总结报告</h2></div><p class="muted"><span class="spin"></span>正在检查…</p>`;
  if (!d.open) d.showModal();
  const [log, scan, ov] = await Promise.all([api("/api/smapi-log").catch(() => null), api("/api/report-scan?t=" + Date.now()).catch(() => null), api("/api/overlap").catch(() => null)]);
  let scope = prefGet("rptScope", "inst");
  d.innerHTML = `<div class="mhead"><div class="rpttitle"><h2>总结报告</h2><span id="rptScopeTxt"></span></div><div class="row"><div class="segsw" id="rptScope"><button data-sc="inst">已安装</button><button data-sc="all">全部</button></div><button id="rptSave" class="secondary">导出 HTML</button><button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div></div><div class="rptmain"><nav class="rptnav"></nav><div class="rptbody"></div></div>`;
  const draw = () => {
    d.querySelectorAll("#rptScope button").forEach((b) => b.classList.toggle("on", b.dataset.sc === scope));
    const body = $(".rptbody", d); body.innerHTML = buildReport(log, scan, ov, scope);
    const sc = $(".rptscope", body); if (sc) { $("#rptScopeTxt", d).innerHTML = sc.innerHTML; sc.remove(); }
    buildReportNav(d);
    bindReport(d);
  };
  d.querySelectorAll("#rptScope button").forEach((b) => (b.onclick = () => { scope = b.dataset.sc; prefSet("rptScope", scope); draw(); }));
  draw();
  bindReportSave(d);
}
// 左边目录：每个大节一行（数字 + 名字），点小箭头展开它下面的小组，点名字跳过去（11-23 Hazel：做成侧边目录，可展开收起）
function buildReportNav(d) {
  const nav = $(".rptnav", d), body = $(".rptbody", d);
  const openNav = new Set(prefGet("rptNavOpen", []));
  let k = 0;
  nav.innerHTML = [...body.querySelectorAll("details.rsec")].map((sec) => {
    const id = sec.id.slice(4), head = sec.querySelector("summary.rpth > span").textContent;
    const m = head.match(/^(.*?)（(\d+)）$/), name = m ? m[1] : head, num = m ? m[2] : "";
    const subs = [...sec.querySelectorAll("li.rg")].map((g) => { g.id = "rg-" + (++k); const t = g.querySelector(".rgh b").textContent; const mm = t.match(/^(.*)（(\d+)）$/); return `<a href="#${g.id}" class="rnsub"><span>${esc(mm ? mm[1] : t)}</span><em>${mm ? mm[2] : ""}</em></a>`; });
    const bad = num && num !== "0" && id !== "快捷键";
    return `<div class="rnsec${openNav.has(id) ? " open" : ""}" data-sec="${esc(id)}"><div class="rnrow">${subs.length ? `<button type="button" class="rntog" aria-label="展开"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg></button>` : `<span class="rntog"></span>`}<a href="#${esc(sec.id)}" class="rnmain"><span>${esc(name)}</span><b class="${bad ? "bad" : ""}">${esc(num)}</b></a></div>${subs.length ? `<div class="rnsubs">${subs.join("")}</div>` : ""}</div>`;
  }).join("");
  const jump = (el) => { const s = el.closest("details.rsec"); if (s) s.open = true; el.scrollIntoView({ behavior: "smooth", block: "start" }); };
  nav.onclick = (e) => {
    const tg = e.target.closest(".rntog");
    if (tg && tg.tagName === "BUTTON") {
      const box = tg.closest(".rnsec"); box.classList.toggle("open");
      prefSet("rptNavOpen", [...nav.querySelectorAll(".rnsec.open")].map((x) => x.dataset.sec));
      return;
    }
    const a = e.target.closest("a"); if (!a) return;
    e.preventDefault();
    const t = document.getElementById(decodeURIComponent(a.getAttribute("href").slice(1)));
    if (t) jump(t);
  };
}
function bindReport(d) {
  const run = $("#ovRun", d), reset = $("#ovReset", d);
  const scope = prefGet("rptScope", "inst");
  const go = async (b, isReset) => {
    b.disabled = true; b.innerHTML = `<span class="spin"></span>AI 正在看…（Mod 多的话要一两分钟）`;
    try { await api("/api/overlap", { scope, reset: isReset }); openReport(); }
    catch (err) { b.disabled = false; b.textContent = "再试一次"; toast(err.message, 7000); }
  };
  if (run) run.onclick = () => go(run, false);
  if (reset) reset.onclick = () => { if (run) run.remove(); go(reset, true); };
  d.querySelectorAll("[data-gofix]").forEach((b) => (b.onclick = (e) => {
    e.preventDefault(); e.stopPropagation();
    d.close(); state.cat = ISSUE; state.sub = ""; state.issue = "miss"; saveWhere?.(); render();
  }));
  d.querySelectorAll("details.rsec").forEach((x) => x.addEventListener("toggle", () => {
    const ids = [...d.querySelectorAll("details.rsec")].filter((y) => !y.open).map((y) => y.id.slice(4));
    prefSet("rptShut", ids);
  }));
  d.querySelectorAll("summary button").forEach((b) => b.addEventListener("click", (e) => e.preventDefault()));  // 点按钮不收起这一节
  d.querySelectorAll(".rptbody a[data-mid]").forEach((a) => (a.onclick = (e) => { e.preventDefault(); openDetail(a.dataset.mid); }));
  const ovf = $("#ovFunc", d);
  if (ovf) { ovf.onchange = () => { prefSet("ovFuncOnly", ovf.checked); const y = $(".rptbody", d).scrollTop; $("#rptScope .on", d)?.click(); $(".rptbody", d).scrollTop = y; }; }
  const hf = $("#hkFind", d), hc = $("#hkClash", d);
  const hkFilter = () => {
    const q = (hf?.value || "").trim().toLowerCase(), only = hc?.checked;
    d.querySelectorAll("table.hk tr[data-hk]").forEach((tr) => {
      const zh = tr.textContent.toLowerCase();
      tr.hidden = (q && !tr.dataset.hk.includes(q) && !zh.includes(q)) || (only && !tr.classList.contains("has-clash"));
    });
  };
  if (hf) hf.oninput = hkFilter;
  if (hc) hc.onchange = hkFilter;
  translateHotkeyNames(d);
}
function bindReportSave(d) {
  $("#rptSave", d).onclick = () => {
    const css = "body{font:14px/1.6 system-ui;max-width:900px;margin:24px auto;padding:0 16px;color:#222}table{border-collapse:collapse;width:100%;font-size:13px}th,td{border:1px solid #ddd;padding:4px 8px;text-align:left;vertical-align:top}th{background:#f5f5f5}a{color:#1a56db;text-decoration:none}.muted{color:#888}.small{font-size:12px}kbd{font:12px system-ui;border:1px solid #ccc;border-bottom-width:2px;border-radius:4px;padding:0 5px;margin:1px 2px;display:inline-block}kbd.clash{border-color:#d33;color:#d33}.rptsum{display:flex;gap:8px;margin:8px 0}.rptsum a{border:1px solid #ddd;border-radius:6px;padding:4px 10px;color:#555}.rptsum b{margin-right:4px}.rptsum a.bad b{color:#d33}";
    const blob = new Blob([`<!doctype html><html lang="zh"><head><meta charset="utf-8"><title>星露谷 Mod 总结报告</title><style>${css}</style></head><body><h1>星露谷 Mod 总结报告</h1><p>${$("#rptScopeTxt", d).innerHTML}</p>${$(".rptbody", d).innerHTML}</body></html>`], { type: "text/html" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = `Mod总结报告-${new Date().toISOString().slice(0, 10)}.html`; document.body.appendChild(a); a.click(); setTimeout(() => { a.remove(); URL.revokeObjectURL(a.href); }, 1000);
  };
}
$("#btnLib").onclick = () => { document.querySelectorAll("details.menu").forEach((x) => x.removeAttribute("open")); api("/api/lib-open", {}).catch((e) => toast(e.message)); };
// 管理 → 游戏里显示中文名：所有 Mod 在 GMCM 里显示中文名；你改过的用你改的（11-24 Hazel）
function gameNamesMark() {
  const b = $("#btnGameNames"); if (!b) return;
  const on = !!state.cfg?.game_names_zh;
  b.innerHTML = on ? "<b>游戏里换回英文名</b><span>你改过中文名的 Mod 保持不变</span>" : "<b>游戏里显示中文名</b><span>GMCM 里的 Mod 名改成中文</span>";
}
$("#btnGameNames").onclick = async () => {
  document.querySelectorAll("details.menu").forEach((x) => x.removeAttribute("open"));
  const on = !state.cfg?.game_names_zh;
  if (!(await askConfirm(on ? "游戏里显示中文名？" : "游戏里换回英文名？",
    on ? "GMCM（Mod 配置菜单）里的 Mod 名都改成中文。你改过中文名的用你改的。以后装的、更新的也会自动改。" : "GMCM 里的 Mod 名换回英文原名。你自己改过中文名的保持不变。",
    on ? "改成中文" : "换回英文", "primary"))) return;
  try {
    const r = await api("/api/game-names", { on });
    if (state.cfg) state.cfg.game_names_zh = on;
    gameNamesMark();
    toast(on ? `正在把 ${r.count} 个 Mod 改成中文名，下次进游戏生效` : "正在换回英文名，下次进游戏生效", 6000);
  } catch (err) { toast(err.message, 7000); }
};
$("#btnSmapiLog").onclick = () => { document.querySelectorAll("details.menu").forEach((x) => x.removeAttribute("open")); openSmapiLog(); };
$("#btnReport").onclick = () => { document.querySelectorAll("details.menu").forEach((x) => x.removeAttribute("open")); openReport(); };
try { if (sessionStorage.getItem("smm-ui-reload")) { sessionStorage.removeItem("smm-ui-reload"); setTimeout(() => toast("管理器界面已自动更新到最新版"), 800); } } catch (e) {}

// 批量栏贴在顶栏下面（顶栏本身是吸顶的，批量栏不能被它盖住）
(() => {
  const bar = document.querySelector("header.bar"); if (!bar || !window.ResizeObserver) return;
  const set = () => document.documentElement.style.setProperty("--barh", bar.offsetHeight + "px");
  new ResizeObserver(set).observe(bar); set();
})();

// 删除合集：先弹窗确认（只删合集，Mod 不动）
// 同一个容器的确认、选择、输入请求按到达顺序执行；不覆盖仍等待用户的回调。
const questionQueues = new Map();
function queueQuestion(id, show) {
  const previous = questionQueues.get(id) || Promise.resolve();
  const next = previous.then(show, show);
  questionQueues.set(id, next);
  const clear = () => { if (questionQueues.get(id) === next) questionQueues.delete(id); };
  next.then(clear, clear);
  return next;
}
// wait：取消按钮要等几秒才能点（新版提醒用，11-27 Hazel：有人拿旧版来问问题）
function askConfirm(title, text, okText = "删除", okCls = "danger", items = null, cancelText = "取消", wait = 0) {
  return queueQuestion("confirmDlg", () => {
  let d = $("#confirmDlg");
  if (!d) { d = document.createElement("dialog"); d.id = "confirmDlg"; d.className = "modal confirm"; d.setAttribute("closedby", "closerequest"); document.body.appendChild(d); }
  d.innerHTML = `<h2>${esc(title)}</h2><p class="muted">${esc(text)}</p>${items ? `<ul class="cflist">${items.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : ""}<div class="row end"><button data-close>${esc(cancelText)}</button><button class="${okCls}" id="cfOk">${esc(okText)}</button></div>`;
  return new Promise((res) => {
    let ok = false;
    $("#cfOk", d).onclick = () => { ok = true; d.close(); };
    const cancel = d.querySelector("[data-close]");
    cancel.onclick = () => d.close();
    let left = wait, timer = null;
    d.oncancel = (e) => { if (left > 0) e.preventDefault(); };
    if (left > 0) {
      const tick = () => { cancel.disabled = left > 0; cancel.textContent = left > 0 ? `${cancelText}（${left}）` : cancelText; };
      tick(); timer = setInterval(() => { left--; tick(); if (left <= 0) clearInterval(timer); }, 1000);
    }
    d.onclose = () => { d.onclose = null; d.oncancel = null; clearInterval(timer); res(ok); };
    d.showModal();
  });
  });
}
// 几个按钮选一个（关掉弹窗 = null）。buttons：[{key, text, cls}]
function askChoice(title, text, items, buttons) {
  return queueQuestion("confirmDlg", () => {
  let d = $("#confirmDlg");
  if (!d) { d = document.createElement("dialog"); d.id = "confirmDlg"; d.className = "modal confirm"; d.setAttribute("closedby", "closerequest"); document.body.appendChild(d); }
  d.innerHTML = `<h2>${esc(title)}</h2><p class="muted">${esc(text)}</p>${items && items.length ? `<ul class="cflist">${items.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : ""}<div class="chrow">${buttons.map((b, i) => `<button data-ch="${i}" class="${b.cls || ""}">${esc(b.text)}</button>`).join("")}</div>`;
  return new Promise((res) => {
    let pick = null;
    d.querySelectorAll("[data-ch]").forEach((b) => { b.onclick = () => { pick = buttons[+b.dataset.ch].key; d.close(); }; });
    d.onclose = () => { d.onclose = null; res(pick); };
    d.showModal();
  });
  });
}
// 玩完游戏：SMAPI 日志里有出问题的 Mod，弹一次（每份日志只弹一次）
async function openSmapiLog() {
  try { await api("/api/smapi-log-open", {}); } catch (e) {}
  openExt("https://smapi.io/log");
  toast("把选中的 SMAPI-latest.txt 拖进打开的网页，就能看到详细分析", 8000);
}
document.addEventListener("click", (e) => {
  if (e.target.closest("[data-smapilog]")) openSmapiLog();
  const ce = e.target.closest("[data-copyerr]");
  if (ce) { const m = allMods().find((x) => x.id === +ce.dataset.copyerr); if (m) copyErr(m.error, m); }
});
async function smapiPopup() {
  const L = state.smapiLast || {};
  if (!L.mtime || smapiPopup.busy) return;
  await prefsReady;
  const seen = prefGet("smapiSeen");
  if (seen === undefined || seen === null) { prefSet("smapiSeen", L.mtime); return; }  // 第一次用：旧日志不弹
  if (seen >= L.mtime) return;
  const byId = new Map(allMods().map((m) => [String(m.id), m]));
  const items = [...Object.entries(L.mods || {}).filter(([id]) => byId.has(id) && gameIssues(byId.get(id))).map(([id, w]) => `${title(byId.get(id))}：${w.join("；")}`),
    ...(L.other || []).map((x) => `${x.name}：${x.why.join("；")}`)];
  if (items.length && document.querySelector("dialog[open]")) return;  // 别的弹窗开着：下次再弹
  prefSet("smapiSeen", L.mtime);
  if (!items.length) return;
  smapiPopup.busy = true;
  const pick = await askChoice(`上次进游戏，有 ${items.length} 个 Mod 出了问题`, "卡片上标着「上次出错」。缺前置的点「管理 → 前置」。", items.slice(0, 30),
    [{ key: null, text: "知道了" }, { key: "log", text: "日志分析", cls: "primary" }]);
  smapiPopup.busy = false;
  if (pick === "log") openSmapiLog();
}
// 第一次打开：三步引导（找到游戏 → 连上 Nexus → 读取已装的 Mod）（11-23）
async function guideDetect() {
  const msg = $("#gFolderMsg");
  msg.className = "small"; msg.textContent = "正在找…";
  try {
    const r = await api("/api/detect-folders");
    if (r.length) { $("#gFolder").value = r[0]; msg.className = "small ok"; msg.textContent = "找到了 ✓"; }
    else { msg.className = "small bad"; msg.textContent = "没找到，请把 Mods 文件夹的位置粘贴到上面"; }
  } catch (e) { msg.className = "small bad"; msg.textContent = "没找到，请把 Mods 文件夹的位置粘贴到上面"; }
}
function openGuide() {
  const d = $("#guide");
  $("#gFolder").value = state.cfg.mods_folder || "";
  $("#gKey").value = "";
  $("#gKey").placeholder = state.cfg.nexus_api_key_set ? "已填好，留空不改" : "粘贴 Nexus API Key";
  d.showModal();
  if (!$("#gFolder").value) guideDetect(); else { $("#gFolderMsg").className = "small ok"; $("#gFolderMsg").textContent = "已设置 ✓"; }
}
$("#gDetect").onclick = guideDetect;
$("#gGo").onclick = async () => {
  const folder = $("#gFolder").value.trim(), key = $("#gKey").value.trim();
  if (!folder) { $("#gFolderMsg").className = "small bad"; $("#gFolderMsg").textContent = "先填好 Mods 文件夹"; return; }
  const b = $("#gGo"); b.disabled = true;
  try {
    await api("/api/config", { mods_folder: folder, guide_done: true, ...(key ? { nexus_api_key: key } : {}) });
    await loadCfg();
    $("#guide").close();
    $("#btnScan").click();
  } catch (err) { toast(err.message, 7000); }
  finally { b.disabled = false; }
};
$("#guide").addEventListener("close", () => { if (!state.cfg.guide_done) api("/api/config", { guide_done: true }).then(loadCfg).catch(() => {}); });
// 改 Mod 设置：把 config.json 变成开关、数字框、文字框（11-23）
const CFG_KEYISH = /key|button|hotkey|bind|keybind/i;
function cfgRows(obj, path, labels, depth) {
  return Object.entries(obj).map(([k, v]) => {
    const p = JSON.stringify([...path, k]);
    const lab = `<span class="cfk">${esc(labels[k] || k)}${labels[k] ? `<em>${esc(k)}</em>` : ""}</span>`;
    if (typeof v === "boolean") return `<label class="cfrow">${lab}<input type="checkbox" data-p='${esc(p)}' ${v ? "checked" : ""}></label>`;
    if (typeof v === "number") return `<label class="cfrow">${lab}<input type="number" step="any" data-p='${esc(p)}' value="${v}"></label>`;
    if (typeof v === "string") return `<label class="cfrow">${lab}<input type="text" data-p='${esc(p)}' value="${esc(v)}" ${CFG_KEYISH.test(k) ? 'placeholder="按键，比如 F5"' : ""}></label>`;
    if (v && typeof v === "object" && !Array.isArray(v) && depth < 3 && Object.keys(v).length) return `<fieldset class="cfgrp"><legend>${esc(labels[k] || k)}</legend>${cfgRows(v, [...path, k], labels, depth + 1)}</fieldset>`;
    return `<div class="cfrow">${lab}<span class="muted small">这项比较复杂，要改请点「打开文件夹」</span></div>`;
  }).join("");
}
function cfgCollect(box, data) {
  const out = JSON.parse(JSON.stringify(data));
  box.querySelectorAll("[data-p]").forEach((el) => {
    const path = JSON.parse(el.dataset.p);
    let o = out; for (const k of path.slice(0, -1)) o = o[k];
    const k = path[path.length - 1], old = o[k];
    if (el.type === "checkbox") o[k] = el.checked;
    else if (el.type === "number") { const n = Number(el.value); if (el.value.trim() !== "" && Number.isFinite(n)) o[k] = Number.isInteger(old) ? Math.round(n) : n; }
    else o[k] = el.value;
  });
  return out;
}
async function openModConfig(m) {
  let d = $("#cfgDlg");
  if (!d) { d = document.createElement("dialog"); d.id = "cfgDlg"; d.className = "modal cfg-d"; document.body.appendChild(d); }
  d.innerHTML = `<div class="mhead"><h2>改设置 · ${esc(title(m))}</h2><button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div><p class="muted"><span class="spin"></span>读取中…</p>`;
  d.querySelector("[data-close]").onclick = () => d.close();
  d.showModal();
  let r;
  try { r = await api(`/api/mods/${m.id}/config`); } catch (err) { d.querySelector("p").textContent = err.message; return; }
  if (!r.files.length) { d.querySelector("p").textContent = "这个 Mod 还没有设置文件。进一次游戏后会自动生成，再来这里改。"; return; }
  d.innerHTML = `<div class="mhead"><h2>改设置 · ${esc(title(m))}</h2><button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
    <p class="muted small">改完点「保存」，重新进游戏生效。</p>
    ${r.files.map((f, i) => `<div class="cffile" data-i="${i}">${r.files.length > 1 ? `<h3>${esc(f.name)}</h3>` : ""}<div class="cfbox">${cfgRows(f.data, [], r.labels || {}, 0)}</div>
      <div class="row end">${f.has_bak ? `<button type="button" data-cfundo="${i}">撤销上次修改</button>` : ""}<button type="button" class="primary" data-cfsave="${i}">保存</button></div></div>`).join("")}`;
  d.querySelector("[data-close]").onclick = () => d.close();
  d.querySelectorAll("[data-cfsave]").forEach((b) => b.onclick = async () => {
    const f = r.files[+b.dataset.cfsave], box = b.closest(".cffile").querySelector(".cfbox");
    try { await api(`/api/mods/${m.id}/config-save`, { folder: f.folder, data: cfgCollect(box, f.data) }); toast("已保存，重新进游戏生效"); if (r.files.length === 1) d.close(); }  // 有好几个设置文件时不关，免得别的没存的改动丢了（GPT 查出，11-24）
    catch (err) { toast(err.message, 7000); }
  });
  d.querySelectorAll("[data-cfundo]").forEach((b) => b.onclick = async () => {
    if (!(await askConfirm("撤销上次修改？", "换回上次保存之前的设置。", "撤销", "primary"))) return;
    try { await api(`/api/mods/${m.id}/config-undo`, { folder: r.files[+b.dataset.cfundo].folder }); toast("已撤销"); openModConfig(m); }
    catch (err) { toast(err.message, 7000); }
  });
}
// ---------- 分享 Mod 清单（11-24）：选一批 Mod，按喜欢的样式做成网页 / 图片 / PDF / 合集文件 ----------
// 每种样式只写一份 HTML（SHEET_STYLES），网页、图片、PDF 都用它：图片 = 把同一份 HTML 画到 canvas 上（SVG foreignObject）。
const SHEET_THEMES = {
  // acc 主色、acc2 撞色（胶带、贴纸、小装饰用）、on 主色上的字色。配色来自 Hazel 挑的色卡（11-24）
  mono: { on: "#ffffff", plane: "#111111", name: "极简黑白", bg: "#f7f7f7", card: "#ffffff", ink: "#111111", sub: "#555555", acc: "#111111", acc2: "#8c8c8c", line: "#e0e0e0", dot: "#e9e9e9" },
  mintchoc: { on: "#F4F1D9", name: "薄荷巧克", bg: "#BAD9D2", card: "#F4F1D9", ink: "#4e3c34", sub: "#6D584E", acc: "#6D584E", acc2: "#E9CAC6", line: "#9ec8bf", dot: "#abd0c8" },
  berrybreeze: { on: "#F8F4E8", name: "莓语轻风", bg: "#FFD3D4", card: "#F8F4E8", ink: "#5a443f", sub: "#775C56", acc: "#775C56", acc2: "#a8d8ca", line: "#f4b9bb", dot: "#f8c5c7" },
  sunset: { on: "#ffffff", name: "落日晚霞", bg: "#F7D6D4", card: "#FDF1EC", ink: "#5d4a6e", sub: "#8b7aa6", acc: "#a993cf", acc2: "#F9B1B8", line: "#efc0bd", dot: "#f2cac7" },
  pinkink: { on: "#242126", name: "粉墨夜色", bg: "#242126", card: "#302a31", ink: "#F0E8E7", sub: "#DDA1B9", acc: "#DDA1B9", acc2: "#D5E0EA", line: "#4b3e47", dot: "#2e292f" },
  haze: { on: "#ffffff", name: "弥散光晕", bg: "#F7FFFD", card: "#ffffff", ink: "#5a2b2a", sub: "#b0605c", acc: "#EA6962", acc2: "#AADDD1", line: "#f2c9c6", dot: "#dcf1ec" },
  mocha: { on: "#ffffff", name: "心跳摩卡", bg: "#DFE3E2", card: "#FEFDF8", ink: "#3a3b3f", sub: "#7e8186", acc: "#e597b2", acc2: "#9FA2A6", line: "#c9cecd", dot: "#d4d8d7" },
  hawthorn: { on: "#ffffff", name: "雪顶山楂", bg: "#FDF5DC", card: "#FFFCF3", ink: "#4a1a22", sub: "#9a4a55", acc: "#D40D3E", acc2: "#C9EAF8", line: "#efdfb8", dot: "#f3e7c6" },
  peach: { on: "#ffffff", name: "法式蜜桃", bg: "#FFE6D6", card: "#FFF9F0", ink: "#6b3a3f", sub: "#b0646e", acc: "#f28695", acc2: "#fce7ae", line: "#ffc5bb", dot: "#ffd6c8" },
  berrycheese: { on: "#6a4048", name: "莓酱芝士", bg: "#FFE4E2", card: "#FFFBF2", ink: "#6a4048", sub: "#b07a82", acc: "#ffb6bd", acc2: "#afdcf1", line: "#ffc9cc", dot: "#ffd3d3" },
  lychee: { on: "#ffffff", name: "树莓荔枝", bg: "#EDE4F9", card: "#FFFDF6", ink: "#4d3d66", sub: "#8b79a8", acc: "#f9879a", acc2: "#ffe48f", line: "#d9c7ef", dot: "#e1d5f3" },
  bluechoc: { on: "#FCF7DF", name: "蓝藻奶巧", bg: "#C7D3DB", card: "#FCF7DF", ink: "#3E3630", sub: "#6f655a", acc: "#3E3630", acc2: "#A79A8A", line: "#afbec8", dot: "#bac8d1" },
};
const SHEET_SRC = { nexus: "Nexus", naver: "Naver", gift: "私享", custom: "自制", other: "其他" };
const SHEET_AUTHOR = "星露管理器 · 作者 @_hazelintheRain";
const SHEET_FONT = '-apple-system,"PingFang SC","Microsoft YaHei",sans-serif';
const SHEET_SCRIPT = '"Segoe Script","Brush Script MT","Snell Roundhand","Apple Chancery",cursive';
const SHEET_MONO = '"Consolas","SFMono-Regular","Courier New",monospace';
const sheetEsc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
// Made by 后面用拼音（花体字写不了汉字）；日文、韩文等原样保留。字表：常用 6763 字，多音字取常用读音
const SHEET_PY = "a啊阿嗄锕|ai埃挨哎唉哀皑癌蔼矮艾碍爱隘捱嗳嗌嫒瑷暧砹锿霭|an鞍氨安俺按暗岸胺案谙埯揞犴庵桉铵鹌黯|ang肮昂盎|ao凹敖熬翱袄傲奥懊澳坳拗嗷岙廒遨媪骜獒聱螯鏊鳌鏖|ba芭捌扒叭吧笆八疤巴拔跋靶把耙坝霸罢爸茇菝岜灞钯粑鲅魃|bai白柏百摆佰败拜稗捭掰擘|ban斑班搬扳般颁板版扮拌伴瓣半办绊阪坂钣瘢癍舨|bang邦帮梆榜膀绑棒磅蚌镑傍谤蒡浜|bao苞胞包褒薄雹保堡饱宝抱报暴豹鲍爆勹葆孢煲鸨褓趵龅|bei杯碑悲卑北辈背贝钡倍狈备惫焙被孛陂邶蓓呗悖碚鹎褙鐾鞴|ben奔苯本笨畚坌贲锛|beng崩绷甭泵蹦迸嘣甏|bi逼鼻比鄙笔彼碧蓖蔽毕毙毖币庇痹闭敝弊必壁臂避陛匕俾荜荸萆薜吡哔狴庳愎滗濞弼妣婢嬖璧畀铋秕裨筚箅篦舭襞跸髀|bian鞭边编贬扁便变卞辨辩辫遍匾弁苄忭汴缏煸砭碥窆褊蝙笾鳊|biao标彪膘表婊骠杓飑飙飚灬镖镳瘭裱鳔髟|bie鳖憋别瘪蹩|bin彬斌濒滨宾摈傧豳缤玢槟殡膑镔髌鬓|bing兵冰柄丙秉饼炳病并禀冫邴摒|bo剥玻菠播拨钵波博勃搏铂箔伯帛舶脖膊渤驳卜亳啵饽檗礴钹鹁簸跛踣|bu捕哺补埠不布步簿部怖卟逋瓿晡钚钸醭|ca擦嚓礤|cai猜裁材才财睬踩采彩菜蔡|can餐参蚕残惭惨灿掺孱骖璨粲黪|cang苍舱仓沧藏伧|cao操糙槽曹草艹嘈漕螬艚|ce厕策侧册测恻|cen岑涔|ceng层蹭曾噌|cha插叉茬茶查碴搽察岔差诧猹馇汊姹杈槎檫锸镲衩|chai拆柴豺侪钗瘥虿|chan搀蝉馋谗缠铲产阐颤冁谄蒇廛忏潺澶羼婵骣觇禅镡蟾躔|chang昌猖场尝常偿肠厂敞畅唱倡伥鬯苌菖徜怅惝阊娼嫦昶氅鲳|chao超抄钞朝嘲潮巢吵炒怊晁焯耖|che车扯撤掣彻澈坼屮砗|chen郴臣辰尘晨忱沉陈趁衬谌谶抻嗔宸琛榇碜龀|cheng撑称城橙成呈乘程惩澄诚承逞骋秤丞埕枨柽晟塍瞠铖裎蛏酲|chi吃痴持池迟弛驰耻齿侈尺赤翅斥炽傺坻墀茌叱哧啻嗤彳饬媸敕眵鸱瘛褫蚩螭笞篪踟魑|chong充冲虫崇宠茺忡憧铳舂艟|chou抽酬畴踌稠愁筹仇绸瞅丑臭俦帱惆瘳雠|chu初出橱厨躇锄雏滁除楚础储矗搐触处畜亍刍怵憷绌杵楮樗褚蜍蹰黜|chuai揣搋啜嘬膪踹|chuan川穿椽传船喘串舛遄巛氚钏舡|chuang疮窗幢床闯创怆|chui吹炊捶锤垂椎陲棰槌|chun春椿醇唇淳纯蠢莼鹑蝽|chuo戳绰辶辍踔龊|ci疵茨磁雌辞慈瓷词此刺赐次伺茈呲祠鹚糍|cong聪葱囱匆从丛苁淙骢琮璁枞|cou凑辏腠|cu粗醋簇促蔟徂猝殂酢蹙蹴|cuan蹿篡窜汆撺爨镩|cui摧崔催脆瘁粹淬翠萃啐悴璀榱毳|cun村存寸忖皴|cuo磋撮搓措挫错厝嵯脞锉矬痤鹾蹉|da搭达答瘩打大耷哒嗒怛妲沓褡笪靼鞑|dai呆歹傣戴带殆代贷袋待逮怠埭甙呔岱迨骀绐玳黛|dan耽担丹单郸掸胆旦氮但惮淡诞弹蛋儋萏啖澹殚赕眈疸瘅聃箪|dang当挡党荡档谠凼菪宕砀铛裆|dao刀捣蹈倒岛祷导到稻悼道盗刂叨忉氘焘纛|de德得的锝|deng蹬灯登等瞪凳邓噔嶝戥磴镫簦|di堤低滴迪敌笛狄涤翟嫡抵底地蒂第帝弟递缔氐籴诋谛邸荻嘀娣柢棣觌砥碲睇镝羝骶|dian颠掂滇碘点典靛垫电佃甸店惦奠淀殿阽坫巅玷钿癜癫簟踮|diao碉叼雕凋刁掉吊钓调铞铫貂鲷|die跌爹碟蝶迭谍叠垤堞揲喋嗲牒瓞耋蹀鲽|ding丁盯叮钉顶鼎锭定订仃啶玎腚碇铤疔耵酊|diu丢铥|dong东冬董懂动栋侗恫冻洞垌咚岽峒氡胨胴硐鸫|dou兜抖斗陡豆逗痘都蔸窦蚪篼|du督毒犊独读堵睹赌杜镀肚度渡妒芏嘟渎椟牍碡蠹笃髑黩|duan端短锻段断缎椴煅簖|dui堆兑队对怼憝碓镦|dun墩吨蹲敦顿囤钝盾遁沌炖砘礅盹趸|duo掇哆多夺垛躲朵跺舵剁惰堕咄哚缍柁铎裰踱|e蛾峨鹅俄额讹娥恶厄扼遏鄂饿噩谔垩苊莪萼呃愕阏屙婀轭腭锇锷鹗颚鳄|ei诶|en恩蒽摁|er而儿耳尔饵洱二贰佴迩珥铒鸸鲕|fa发罚筏伐乏阀法珐垡砝|fan藩帆番翻樊矾钒繁凡烦反返范贩犯饭泛蕃蘩幡梵燔畈蹯|fang坊芳方肪房防妨仿访纺放匚邡枋钫舫鲂|fei菲非啡飞肥匪诽吠肺废沸费芾狒悱淝妃绯榧腓斐扉镄痱蜚篚翡霏鲱|fen芬酚吩氛分纷坟焚汾粉奋份忿愤粪偾瀵棼鲼鼢|feng丰封枫蜂峰锋风疯烽逢冯缝讽奉凤俸酆葑唪沣砜|fou否缶|fu佛夫敷肤孵扶拂辐幅氟符伏俘服浮涪福袱弗甫抚辅俯釜斧腑府腐赴副覆赋复傅付阜父腹负富讣附妇缚咐匐凫阝郛芙苻茯莩菔拊呋幞怫滏艴孚驸绂绋桴赙祓砩黻黼罘稃馥蚨蜉蝠蝮麸趺跗鲋鳆|ga噶嘎伽尬呷尕尜旮钆|gai该改概钙盖溉丐陔垓戤赅|gan干甘杆柑竿肝赶感秆敢赣坩苷尴擀泔淦澉绀橄旰矸疳酐|gang冈刚钢缸肛纲岗港杠戆罡筻|gao篙皋高膏羔糕搞镐稿告睾诰郜藁缟槔槁杲锆|ge哥歌搁戈鸽胳疙割革葛格阁隔铬个各咯鬲仡哿圪塥嗝纥搿膈硌镉袼虼舸骼|gei给|gen根跟亘茛哏艮|geng耕更庚羹埂耿梗哽赓绠鲠|gong工攻功恭龚供躬公宫弓巩汞拱贡共廾珙肱蚣觥|gou钩勾沟苟狗垢构购够佝诟岣遘媾缑枸觏彀笱篝鞲|gu辜菇咕箍估沽孤姑鼓古蛊骨谷股故顾固雇嘏诂菰呱崮汩梏轱牯牿臌毂瞽罟钴锢鸪鹄痼蛄酤觚鲴鹘|gua刮瓜剐寡挂褂卦诖栝胍鸹聒|guai乖拐怪掴|guan棺关官冠观管馆罐惯灌贯倌莞掼涫盥鹳鳏|guang光广逛咣犷桄胱|gui瑰规圭硅归龟闺轨鬼诡癸桂柜跪贵刽傀炔匦刿庋宄妫桧晷皈簋鲑鳜|gun辊滚棍丨衮绲磙鲧|guo锅郭国果裹过馘埚呙帼崞猓椁虢蜾蝈|ha蛤哈铪|hai骸孩海氦亥害骇还嗨胲醢|han酣憨邯韩含涵寒函喊罕翰撼捍旱憾悍焊汗汉邗菡撖阚瀚晗焓顸颔蚶鼾|hang夯杭航沆绗珩颃|hao壕嚎豪毫郝好耗号浩貉蒿薅嗥嚆濠灏昊皓颢蚝|he呵喝荷菏核禾和何合盒阂河涸赫褐鹤贺诃劾壑嗬阖曷盍颌蚵翮|hei嘿黑|hen痕很狠恨|heng哼亨横衡恒蘅桁|hong轰哄烘虹鸿洪宏弘红黉訇讧荭蕻薨闳泓|hou喉侯猴吼厚候后堠後逅瘊篌糇鲎骺|hu呼乎忽瑚壶葫胡蝴狐糊湖弧虎唬护互沪户冱唿囫岵猢怙惚浒滹琥槲轷觳烀煳戽扈祜瓠鹕鹱虍笏醐斛|hua花哗华猾滑画划化话骅桦铧|huai槐徊怀淮坏踝|huan欢环桓缓换患唤痪豢焕涣宦幻郇奂萑擐圜獾洹浣漶寰逭缳锾鲩鬟|huang荒慌黄磺蝗簧皇凰惶煌晃幌恍谎隍徨湟潢遑璜肓癀蟥篁鳇|hui灰挥辉徽恢蛔回毁悔慧卉惠晦贿秽会烩汇讳诲绘诙茴荟蕙咴哕喙隳洄浍彗缋珲晖恚虺蟪麾|hun荤昏婚魂浑混诨馄阍溷|huo豁活伙火获或惑霍货祸劐藿攉嚯夥砉钬锪镬耠蠖|ji击圾基机畸稽积箕肌饥迹激讥鸡姬绩缉吉极棘辑籍集及急疾汲即嫉级挤几脊己蓟技冀季伎祭剂悸济寄寂计记既忌际妓继纪藉丌亟乩剞佶偈诘墼芨芰荠蒺蕺掎叽咭哜唧岌嵴洎彐屐骥畿玑楫殛戟戢赍觊犄齑矶羁嵇稷瘠虮笈笄暨跻跽霁鲚鲫髻麂|jia嘉枷夹佳家加荚颊贾甲钾假稼价架驾嫁茄郏葭岬浃迦珈戛胛恝铗镓痂瘕袷蛱笳袈跏|jian歼监坚尖笺间煎兼肩艰奸缄茧检柬碱硷拣捡简俭剪减荐鉴践贱见键箭件健舰剑饯渐溅涧建僭谏谫菅蒹搛囝湔蹇謇缣枧楗戋戬牮犍毽腱睑锏鹣裥笕翦趼踺鲣鞯|jiang僵姜将浆江疆蒋桨奖讲匠酱降茳洚绛缰犟礓耩糨豇|jiao蕉椒礁焦胶交郊浇骄娇搅铰矫侥脚狡角饺缴绞剿教酵轿较叫窖佼僬艽茭挢噍峤徼湫姣敫皎鹪蛟醮跤鲛|jie揭接皆秸街阶截劫节杰捷睫竭洁结解姐戒芥界借介疥诫届讦卩拮喈嗟婕孑桀碣疖颉蚧羯鲒骱|jin巾筋斤金今津襟紧锦仅谨进靳晋禁近烬浸尽劲卺荩堇噤馑廑妗缙瑾槿赆觐钅衿矜|jing荆兢茎睛晶鲸京惊精粳经井警景颈静境敬镜径痉靖竟竞净刭儆阱菁獍憬泾迳弪婧肼胫腈旌靓|jiong炯窘冂迥炅扃|jiu揪究纠玖韭久灸九酒厩救旧臼舅咎就疚僦啾阄柩桕鸠鹫赳鬏|ju桔鞠拘狙疽居驹菊局咀矩举沮聚拒据巨具距踞锯俱句惧炬剧倨讵苣苴莒菹掬遽屦琚椐榘榉橘犋飓钜锔窭裾趄醵踽龃雎鞫|juan捐鹃娟倦眷卷绢鄄狷涓桊蠲锩镌隽|jue嚼撅攫抉掘倔爵觉决诀绝厥劂谲矍蕨噘噱崛獗孓珏桷橛爝镢蹶觖|jun均菌钧军君峻俊竣浚郡骏捃皲麇|ka喀咖卡佧咔胩|kai开揩楷凯慨剀垲蒈忾恺铠锎锴|kan槛刊堪勘坎砍看侃莰戡龛瞰|kang康慷糠扛抗亢炕伉闶钪|kao考拷烤靠尻栲犒铐|ke坷苛柯棵磕颗科壳咳可渴克刻客课嗑岢恪溘骒缂珂轲氪瞌钶锞稞疴窠颏蝌髁|ken肯啃垦恳裉龈|keng坑吭铿|kong空恐孔控倥崆箜|kou抠口扣寇芤蔻叩眍筘|ku枯哭窟苦酷库裤刳堀喾绔骷|kua夸垮挎跨胯侉|kuai块筷侩快蒯郐哙狯脍|kuan宽款髋|kuang匡筐狂框矿眶旷况诓诳邝圹夼哐纩贶|kui亏盔岿窥葵奎魁馈愧溃馗匮夔隗蒉揆喹喟悝愦逵暌睽聩蝰篑跬|kun坤昆捆困悃阃琨锟醌鲲髡|kuo括扩廓阔蛞|la垃拉喇蜡腊辣啦剌邋旯砬瘌|lai莱来赖崃徕涞濑赉睐铼癞籁|lan蓝婪栏拦篮阑兰澜谰揽览懒缆烂滥岚漤榄斓罱镧褴|lang琅榔狼廊郎朗浪莨蒗啷阆锒稂螂|lao捞劳牢老佬姥酪烙涝潦唠崂栳铑铹痨耢醪|le乐肋了仂叻泐鳓|lei勒雷镭蕾磊累儡垒擂类泪羸诔嘞嫘缧檑耒酹|leng棱楞冷塄愣|li厘梨犁黎篱狸离漓理李里鲤礼莉荔吏栗丽厉励砾历利傈例俐痢立粒沥隶力璃哩俪俚郦坜苈莅蓠藜呖唳喱猁溧澧逦娌嫠骊缡枥栎轹戾砺詈罹锂鹂疠疬蛎蜊蠡笠篥粝醴跞雳鲡鳢黧|lia俩|lian联莲连镰廉怜涟帘敛脸链恋炼练蔹奁潋濂琏楝殓臁裢裣蠊鲢|liang粮凉梁粱良两辆量晾亮谅墚椋踉魉|liao撩聊僚疗燎寥辽撂镣廖料蓼尥嘹獠寮缭钌鹩|lie列裂烈劣猎冽埒捩咧洌趔躐鬣|lin琳林磷霖临邻鳞淋凛赁吝拎蔺啉嶙廪懔遴檩辚膦瞵粼躏麟|ling玲菱零龄铃伶羚凌灵陵岭领另令酃苓呤囹泠绫柃棂瓴聆蛉翎鲮|liu溜琉榴硫馏留刘瘤流柳六浏遛骝绺旒熘锍镏鹨鎏|long龙聋咙笼窿隆垄拢陇垅茏泷珑栊胧砻癃|lou楼娄搂篓漏陋偻蒌喽嵝镂瘘耧蝼髅|lu芦卢颅庐炉掳卤虏鲁麓碌露路赂鹿潞禄录陆戮垆撸噜泸渌漉逯璐栌橹轳辂辘氇胪镥鸬鹭簏舻鲈|luan峦挛孪滦卵乱脔娈栾鸾銮|lun抡轮伦仑沦纶论囵|luo萝螺罗逻锣箩骡裸落洛骆络倮蠃荦摞猡泺漯珞椤脶镙瘰雒|lv驴吕铝侣旅履屡缕虑氯律率滤绿捋闾榈膂稆褛|lve掠略锊|ma妈麻玛码蚂马骂嘛吗唛犸嬷杩蟆|mai埋买麦卖迈脉劢荬霾|man瞒馒蛮满蔓曼慢漫谩墁幔缦熳镘颟螨鳗鞔|mang芒茫盲氓忙莽邙漭硭蟒|mao猫茅锚毛矛铆卯茂冒帽貌贸袤茆峁泖瑁昴牦耄旄懋瞀蝥蟊髦|me么|mei玫枚梅酶霉煤没眉媒镁每美昧寐妹媚莓嵋猸浼湄楣镅鹛袂魅|men门闷们扪焖懑钔|meng萌蒙檬盟锰猛梦孟勐甍瞢懵朦礞虻蜢蠓艋艨|mi眯醚靡糜迷谜弥米秘觅泌蜜密幂芈冖谧蘼咪嘧猕汨宓弭脒祢敉糸縻麋|mian棉眠绵冕免勉娩缅面沔渑湎宀腼眄|miao苗描瞄藐秒渺庙妙喵邈缈杪淼眇鹋|mie蔑灭乜咩蠛篾|min民抿皿敏悯闽苠岷闵泯缗珉愍黾鳘|ming明螟鸣铭名命冥茗溟暝瞑酩|miu谬|mo摸摹蘑模膜磨摩魔抹末莫墨默沫漠寞陌谟茉蓦馍嫫殁镆秣瘼耱貊貘麽|mou谋牟某侔哞缪眸蛑鍪|mu拇牡亩姆母墓暮幕募慕木目睦牧穆仫坶苜沐毪钼|n嗯|na拿哪呐钠那娜纳捺肭镎衲|nai氖乃奶耐奈鼐艿萘柰|nan南男难喃囡楠腩蝻赧|nang囊攮囔馕曩|nao挠脑恼闹淖孬垴呶猱瑙硇铙蛲|ne呢讷疒|nei馁内|nen嫩恁|neng能|ni妮霓倪泥尼拟你匿腻逆溺伲坭猊怩昵旎睨铌鲵|nian蔫拈年碾撵捻念辗廿埝辇黏鲇鲶|niang娘酿|niao鸟尿茑嬲脲袅|nie捏聂孽啮镊镍涅陧蘖嗫颞臬蹑|nin您|ning柠狞凝宁拧泞佞咛甯聍|niu牛扭钮纽狃忸妞|nong脓浓农弄侬哝|nou耨|nu奴努怒弩胬孥驽|nuan暖|nuo挪懦糯诺傩搦喏锘|nv女恧钕衄|nve虐疟|o哦喔噢|ou欧鸥殴藕呕偶沤讴怄瓯耦|pa啪趴爬帕怕琶葩杷筢|pai拍排牌徘湃派俳蒎哌|pan攀潘盘磐盼畔判叛拚爿泮袢襻蟠蹒|pang乓庞旁耪胖彷滂逄螃|pao抛咆刨炮袍跑泡匏狍庖脬疱|pei呸胚培裴赔陪配佩沛辔帔旆锫醅霈|pen喷盆湓|peng砰抨烹澎彭蓬棚硼篷膨朋鹏捧碰堋嘭怦蟛|pi辟坯砒霹批披劈琵毗啤脾疲皮匹痞僻屁譬丕仳陴邳郫圮埤鼙芘擗噼庀淠媲纰枇甓睥罴铍癖疋蚍蜱貔|pian篇偏片骗谝骈犏胼翩蹁|piao飘漂瓢票剽嘌嫖缥殍瞟螵|pie撇瞥丿苤氕|pin拼频贫品聘姘嫔榀牝颦|ping乒坪苹萍平凭瓶评屏俜娉枰鲆|po泊坡泼颇婆破魄迫粕叵鄱珀钋钷皤笸|pou剖裒掊|pu脯扑铺仆莆葡菩蒲埔朴圃普浦谱曝瀑匍噗溥濮璞攴氆攵镤镨蹼|qi期欺栖戚妻七凄漆柒沏其棋奇歧畦崎脐齐旗祈祁骑起岂乞企启契砌器气迄弃汽泣讫亓俟圻芑芪萁萋葺蕲嘁屺岐汔淇骐绮琪琦杞桤槭耆祺憩碛颀蛴蜞綦綮蹊鳍麒|qia掐恰洽葜髂|qian牵扦钎铅千迁签仟谦乾黔钱钳前潜遣浅谴堑嵌欠歉倩佥阡凵芊芡茜掮岍悭慊骞搴褰缱椠肷愆钤虔箝|qiang枪呛腔羌墙蔷强抢丬戕嫱樯戗炝锖锵镪襁蜣羟跄|qiao橇锹敲悄桥瞧乔侨巧鞘撬翘峭俏窍劁诮谯荞愀憔缲樵硗跷鞒|qie切且怯窃郄惬妾挈锲箧|qin钦侵亲秦琴勤芹擒禽寝沁芩揿吣嗪噙溱檎锓螓衾|qing青轻氢倾卿清擎晴氰情顷请庆苘圊檠磬蜻罄箐謦鲭黥|qiong琼穷邛芎茕穹蛩筇跫銎|qiu秋丘邱球求囚酋泅俅巯犰逑遒楸赇虬蚯蝤裘糗鳅鼽|qu趋区蛆曲躯屈驱渠取娶龋趣去诎劬蕖蘧岖衢阒璩觑氍朐祛磲鸲癯蛐蠼麴瞿黢|quan圈颧权醛泉全痊拳犬券劝诠荃犭悛绻辁畎铨蜷筌鬈|que缺瘸却鹊榷确雀阕阙悫|qun裙群逡|ran然燃冉染苒蚺髯|rang瓤壤攘嚷让禳穰|rao饶扰绕荛娆桡|re惹热|ren壬仁人忍韧任认刃妊纫亻仞荏葚饪轫稔衽|reng扔仍|ri日|rong戎茸蓉荣融熔溶容绒冗嵘狨榕肜蝾|rou揉柔肉糅蹂鞣|ru茹蠕儒孺如辱乳汝入褥蓐薷嚅洳溽濡缛铷襦颥|ruan软阮朊|rui蕊瑞锐芮蕤枘睿蚋|run闰润|ruo若弱偌箬|sa撒洒萨卅仨挲脎飒|sai腮鳃塞赛噻|san三叁伞散馓毵糁|sang桑嗓丧搡磉颡|sao搔骚扫嫂埽缫臊瘙鳋|se瑟色涩啬铯穑|sen森|seng僧|sha莎砂杀刹沙纱傻啥煞厦唼歃铩痧裟霎鲨|shai筛晒酾|shan珊苫杉山删煽衫闪陕擅赡膳善汕扇缮剡讪鄯埏芟彡潸姗嬗骟膻钐疝蟮舢跚鳝|shang墒伤商赏晌上尚裳垧绱殇熵觞|shao梢捎稍烧芍勺韶少哨邵绍劭苕潲蛸筲艄|she奢赊蛇舌舍赦摄射慑涉社设厍佘猞滠歙畲麝|shen砷申呻伸身深娠绅神沈审婶甚肾慎渗什诜谂莘哂渖椹胂矧蜃|sheng声生甥牲升绳省盛剩胜圣嵊眚笙|shi匙师失狮施湿诗尸虱十石拾时食蚀实识史矢使屎驶始式示士世柿事拭誓逝势是嗜噬适仕侍释饰氏市恃室视试似谥埘莳蓍弑饣轼贳炻礻铈螫舐筮豉豕鲥鲺|shou收手首守寿授售受瘦兽扌狩绶艏|shu蔬枢梳殊抒输叔舒淑疏书赎孰熟薯暑曙署蜀黍鼠属术述树束戍竖墅庶数漱恕倏塾菽摅沭澍姝纾毹腧殳秫|shua刷耍唰|shuai摔衰甩帅蟀|shuan栓拴闩涮|shuang霜双爽孀|shui谁水睡税氵|shun吮瞬顺舜|shuo说硕朔烁蒴搠妁槊铄|si斯撕嘶思私司丝死肆寺嗣四饲巳厮兕厶咝汜泗澌姒驷纟缌祀锶鸶耜蛳笥|song松耸怂颂送宋讼诵凇菘崧嵩忪悚淞竦|sou搜艘擞嗽叟薮嗖嗾馊溲飕瞍锼螋|su苏酥俗素速粟僳塑溯宿诉肃夙谡蔌嗉愫涑簌觫稣|suan酸蒜算狻|sui虽隋随绥髓碎岁穗遂隧祟谇荽濉邃燧眭睢|sun孙损笋荪狲飧榫隼|suo蓑梭唆缩琐索锁所唢嗦嗍娑桫睃羧|ta塌他它她塔獭挞蹋踏闼溻遢榻铊趿鳎|tai胎苔抬台泰酞太态汰邰薹肽炱钛跆鲐|tan坍摊贪瘫滩坛檀痰潭谭谈坦毯袒碳探叹炭郯昙忐钽锬覃|tang汤塘搪堂棠膛唐糖倘躺淌趟烫傥帑饧溏瑭樘铴镗耥螗螳羰醣|tao掏涛滔绦萄桃逃淘陶讨套鼗啕洮韬饕|te特忒忑慝铽|teng藤腾疼誊滕|ti梯剔踢锑提题蹄啼体替嚏惕涕剃屉倜荑悌逖绨缇鹈裼醍|tian天添填田甜恬舔腆掭忝阗殄畋|tiao挑条迢眺跳佻祧窕蜩笤粜龆鲦髫|tie贴铁帖萜餮|ting厅听烃汀廷停亭庭挺艇莛葶婷梃町蜓霆|tong通桐酮瞳同铜彤童桶捅筒统痛佟僮仝茼嗵恸潼砼|tou偷投头透亠钭骰|tu凸秃突图徒途涂屠土吐兔堍荼菟钍酴|tuan湍团抟彖疃|tui推颓腿蜕褪退煺|tun吞屯臀氽饨暾豚|tuo拖托脱鸵陀驮驼椭妥拓唾乇佗坨庹沲沱柝橐砣箨酡跎鼍|wa挖哇蛙洼娃瓦袜佤娲腽|wai歪外崴|wan豌弯湾玩顽丸烷完碗挽晚皖惋宛婉万腕剜芄菀纨绾琬脘畹蜿|wang汪王亡枉网往旺望忘妄罔惘辋魍|wei威巍微危韦违桅围唯惟为潍维苇萎委伟伪尾纬未蔚味畏胃喂魏位渭谓尉慰卫偎诿隈圩葳薇囗帏帷嵬猥猬闱沩洧涠逶娓玮韪軎炜煨痿艉鲔|wen瘟温蚊文闻纹吻稳紊问刎阌汶玟璺雯|weng嗡翁瓮蓊蕹|wo挝蜗涡窝我斡卧握沃倭莴幄渥肟硪龌|wu巫呜钨乌污诬屋无芜梧吾吴毋武五捂午舞伍侮坞戊雾晤物勿务悟误兀仵阢邬圬芴呒唔庑怃忤浯寤迕妩婺骛杌牾焐鹉鹜痦蜈鋈鼯|xi昔熙析西硒矽晰嘻吸锡牺稀息希悉膝夕惜熄烯溪汐犀檄袭席习媳喜铣洗系隙戏细僖兮隰郗菥葸蓰奚唏徙饩阋浠淅屣嬉玺樨曦觋欷熹禊禧皙穸蜥螅蟋舄舾羲粞翕醯鼷|xia瞎虾匣霞辖暇峡侠狭下夏吓狎遐瑕柙硖罅黠|xian掀锨先仙鲜纤咸贤衔舷闲涎弦嫌显险现献县腺馅羡宪陷限线冼苋莶藓岘猃暹娴氙燹祆鹇痫蚬筅籼酰跣跹霰|xiang相厢镶香箱襄湘乡翔祥详想响享项巷橡像向象芗葙饷庠骧缃蟓鲞飨|xiao萧硝霄哮嚣销消宵淆晓小孝校肖啸笑效哓崤潇逍骁绡枭枵筱箫魈|xie楔些歇蝎鞋协挟携邪斜胁谐写械卸蟹懈泄泻谢屑偕亵勰燮薤撷獬廨渫瀣邂绁缬榭榍躞|xin薪芯锌欣辛新忻心信衅囟馨忄昕歆鑫|xing星腥猩惺兴刑型形邢行醒幸杏性姓陉荇荥擤悻硎|xiong兄凶胸匈汹雄熊|xiu休修羞朽嗅锈秀袖绣咻岫馐庥溴鸺貅髹|xu墟戌需虚嘘须徐许蓄酗叙旭序恤絮婿绪续吁诩勖蓿洫溆顼栩煦盱胥糈醑|xuan轩喧宣悬旋玄选癣眩绚儇谖萱揎泫渲漩璇楦暄炫煊碹铉镟痃|xue削靴薛学穴雪血谑泶踅鳕|xun勋熏循旬询寻驯巡殉汛训讯逊迅巽埙荀荨蕈薰峋徇獯恂洵浔曛窨醺鲟|ya压押鸦鸭呀丫芽牙蚜崖衙涯雅哑亚讶轧伢垭揠吖岈迓娅琊桠氩砑睚痖|yan焉咽阉烟淹盐严研蜒岩延言颜阎炎沿奄掩眼衍演艳堰燕厌砚雁唁彦焰宴谚验厣赝俨偃兖讠谳郾鄢芫菸崦恹闫湮滟妍嫣琰檐晏胭腌焱罨筵酽魇餍鼹|yang殃央鸯秧杨扬佯疡羊洋阳氧仰痒养样漾徉怏泱炀烊恙蛘鞅|yao邀腰妖瑶摇尧遥窑谣姚咬舀药要耀钥夭爻吆崾徭幺珧杳轺曜肴鹞窈繇鳐|ye椰噎耶爷野冶也页掖业叶曳腋夜液靥谒邺揶晔烨铘|yi一壹医揖铱依伊衣颐夷遗移仪胰疑沂宜姨彝椅蚁倚已乙矣以艺抑易邑屹亿役臆逸肄疫亦裔意毅忆义益溢诣议谊译异翼翌绎刈劓佚佾诒圯埸懿苡薏弈奕挹弋呓咦咿噫峄嶷猗饴怿怡悒漪迤驿缢殪轶贻欹旖熠眙钇镒镱痍瘗癔翊衤蜴舣羿翳酏黟|yin茵荫因殷音阴姻吟银淫寅饮尹引隐印胤鄞廴垠堙茚吲喑狺夤洇氤铟瘾蚓霪|ying英樱婴鹰应缨莹萤营荧蝇迎赢盈影颖硬映嬴郢茔莺萦蓥撄嘤膺滢潆瀛瑛璎楹媵鹦瘿颍罂|yo哟唷|yong拥佣臃痈庸雍踊蛹咏泳涌永恿勇用俑壅墉喁慵邕镛甬鳙饔|you幽优悠忧尤由邮铀犹油游酉有友右佑釉诱又幼卣攸侑莠莜莸尢呦囿宥柚猷牖铕疣蚰蚴蝣鱿黝鼬|yu迂淤于盂榆虞愚舆余俞逾鱼愉渝渔隅予娱雨与屿禹宇语羽玉域芋郁遇喻峪御愈欲狱育誉浴寓裕预豫驭禺毓伛俣谀谕萸蓣揄圄圉嵛狳饫馀庾阈鬻妪妤纡瑜昱觎腴欤於煜燠肀聿钰鹆鹬瘐瘀窬窳蜮蝓竽臾舁雩龉|yuan鸳渊冤元垣袁原援辕园员圆猿源缘远苑愿怨院垸塬掾沅媛瑗橼爰眢鸢螈箢鼋|yue曰约越跃岳粤月悦阅龠瀹樾刖钺|yun耘云郧匀陨允运蕴酝晕韵孕郓芸狁恽愠纭韫殒昀氲熨筠|za匝砸杂咋拶咂|zai栽哉灾宰载再在仔崽甾|zan咱攒暂赞瓒昝簪糌趱錾|zang赃脏葬奘驵臧|zao遭糟凿藻枣早澡蚤躁噪造皂灶燥唣|ze责择则泽仄赜啧帻迮昃笮箦舴|zei贼|zen怎谮|zeng增憎赠缯甑罾锃|zha扎喳渣札铡闸眨栅榨乍炸诈柞揸吒咤哳楂砟痄蚱齄|zhai摘斋宅窄债寨砦瘵|zhan瞻毡詹粘沾盏斩崭展蘸栈占战站湛绽谵搌旃|zhang长樟章彰漳张掌涨杖丈帐账仗胀瘴障仉鄣幛嶂獐嫜璋蟑|zhao招昭找沼赵照罩兆肇召爪诏啁棹钊笊|zhe遮折哲蛰辙者锗蔗这浙着谪摺柘辄磔鹧褶蜇赭|zhen珍斟真甄砧臻贞针侦枕疹诊震振镇阵帧圳蓁浈缜桢榛轸赈胗朕祯畛稹鸩箴|zheng蒸挣睁征狰争怔整拯正政症郑证诤峥徵钲铮筝|zhi芝枝支吱蜘知肢脂汁之织职直植殖执值侄址指止趾只旨纸志挚掷至致置帜峙制智秩稚质炙痔滞治窒卮陟郅埴芷摭帙夂忮彘咫骘栉枳栀桎轵轾贽胝膣祉祗黹雉鸷痣蛭絷酯跖踬踯豸觯|zhong中盅忠钟衷终种肿重仲众冢锺螽舯踵|zhou舟周州洲诌粥轴肘帚咒皱宙昼骤荮妯纣绉胄籀酎|zhu珠株蛛朱猪诸诛逐竹烛煮拄瞩嘱主著柱助蛀贮铸筑住注祝驻丶伫侏邾苎茱洙渚潴杼槠橥炷铢疰瘃竺箸舳翥躅麈|zhua抓|zhuai拽|zhuan专砖转撰赚篆啭馔颛|zhuang桩庄装妆撞壮状|zhui锥追赘坠缀惴骓缒隹|zhun谆准肫窀|zhuo捉拙卓桌茁酌啄灼浊倬诼擢浞涿濯禚斫镯|zi兹咨资姿滋淄孜紫籽滓子自渍字谘嵫姊孳缁梓辎赀恣眦锱秭耔笫粢趑觜訾龇鲻髭|zong鬃棕踪宗综总纵偬腙粽|zou邹走奏揍诹陬鄹驺楱鲰|zu租足卒族祖诅阻组俎镞|zuan钻纂攥缵躜|zui嘴醉最罪蕞|zun尊遵撙樽鳟|zuo琢昨左佐做作坐座阼唑怍胙祚";
let sheetPyMap = null;
function sheetPinyin(str) {
  if (!sheetPyMap) { sheetPyMap = new Map(); SHEET_PY.split("|").forEach((g) => { const m = g.match(/^[a-z]+/)[0]; for (const c of g.slice(m.length)) sheetPyMap.set(c, m); }); }
  const toks = []; // {t, py}：连着的汉字变成一段拼音，其余字符原样
  for (const c of String(str)) {
    const py = sheetPyMap.get(c), last = toks[toks.length - 1];
    if (py) { if (last && last.py) last.t += py; else toks.push({ t: py[0].toUpperCase() + py.slice(1), py: true }); }
    else if (last && !last.py) last.t += c; else toks.push({ t: c, py: false });
  }
  // 拼音和前后的字母之间补一个空格：小雨Rain → Xiaoyu Rain
  return toks.reduce((a, k, i) => a + (i && (k.py || toks[i - 1].py) && /[A-Za-z]$/.test(a) && /^[A-Za-z]/.test(k.t) ? " " : "") + k.t, "").replace(/\s+/g, " ").trim();
}
const sheetMadeBy = (o) => o.author ? `Made by ${sheetPinyin(o.author)}` : "Made with 星露管理器";
const sheetNum = (x) => x.nid ? `尾号 <b>${x.nid}</b>` : sheetEsc(SHEET_SRC[x.src] || "其他");
// 每个 Mod 的外层都要有这些：网页里搜索、按分类筛、点尾号复制都靠它们
const sheetIt = (x, cls = "it") => `class="${cls}" data-q="${sheetEsc(((x.zh || "") + " " + x.en + " " + x.nid).toLowerCase())}"`;
const sheetLink = (x) => x.url ? `href="${sheetEsc(x.url)}" target="_blank" rel="noopener"` : "";
const sheetIdBtn = (x, extra = "") => x.nid ? `<button class="id ${extra}" data-id="${x.nid}">${sheetNum(x)}</button>` : `<span class="id nn ${extra}">${sheetNum(x)}</span>`;
const sheetImg = (x, th, cls = "") => th.get(x) ? `<img class="${cls}" src="${th.get(x)}" alt=""/>` : `<span class="ph ${cls}">${sheetEsc((x.zh || x.en || "?").slice(0, 1))}</span>`;
const sheetSec = (g, inner) => `<section data-sec="${sheetEsc(g.cat)}">${inner}</section>`;
const sheetCommon = (t) => `*{box-sizing:border-box}body{margin:0;background:${t.bg};color:${t.ink};font:15px/1.55 ${SHEET_FONT}}a{color:inherit;text-decoration:none}button{font:inherit;color:inherit;cursor:pointer;border:0;background:none;padding:0}
.ph{display:flex;align-items:center;justify-content:center;background:${t.line};color:${t.sub};font-weight:700}
.id{border-radius:99px;padding:2px 10px;font-size:12px;background:${t.bg};color:${t.sub};white-space:nowrap}.id b{color:${t.ink};font-size:14px}
.id.ok{background:${t.acc};color:${t.on}}.id.ok b{color:${t.on}}.nn{font-size:12px}
.sum{color:${t.sub};font-size:13px;margin-top:4px;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.made{font-family:${SHEET_SCRIPT};font-size:22px;color:${t.acc}}
.foot{text-align:center;color:${t.sub};font-size:12px;padding:28px 0 22px}`;

// 分成几张图时，右上角小小标一个「2 / 3」，不塞进标题
const sheetPgCss = (t) => `body{position:relative}.pgno{position:absolute;right:22px;top:14px;font:600 13px ${SHEET_MONO};letter-spacing:1px;color:${t.sub};background:${t.card};border:1px solid ${t.line};border-radius:99px;padding:2px 10px;z-index:9}`;
const sheetPgTag = (o) => o.pg ? `<div class="pgno">${o.pg}</div>` : "";
// 胶片：底色永远是深色。浅色配色用它的文字色当底，深色配色直接用底色；强调色挑最亮、最显眼的那个
const sheetLum = (h) => { const n = parseInt(String(h).slice(1, 7), 16); const c = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => { v /= 255; return v <= .03928 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4; }); return .2126 * c[0] + .7152 * c[1] + .0722 * c[2]; };
const SHEET_STYLES = {
  // 卡片：平面简约，和管理器预览页的卡片一个样子
  card: { name: "卡片", per: 30, css: (t) => `
.wrap{max-width:1120px;margin:0 auto;padding:28px 22px 10px}
/* 平面简约：和管理器预览页一样的卡片，细边框、无装饰 */
.cv{padding:40px 4px 20px}
.cv .band{height:180px;border-radius:10px;background:center/cover;margin:-12px 0 28px}
.cv .row1{display:flex;align-items:center;gap:16px}
.cv .av{width:64px;height:64px;border-radius:50%;object-fit:cover;flex:none}
.cv .kk{font:600 12px ${SHEET_MONO};letter-spacing:4px;color:${t.sub}}
.cv h1{margin:6px 0 0;font:800 44px/1.2 ${SHEET_FONT};color:${t.ink};overflow-wrap:anywhere}
.cv .row2{display:flex;align-items:baseline;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-top:16px;padding-top:12px;border-top:1px solid ${t.line}}
.cv .meta{color:${t.sub};font-size:14px}
.cv .made{color:${t.sub};font:14px ${SHEET_FONT}}
h2{margin:30px 2px 12px;display:flex;align-items:baseline;gap:10px;font-weight:800;font-size:20px}
h2 .ct{font-size:13px;color:${t.sub};font-weight:400}
.g{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px}
.c{background:${t.card};border:1px solid ${t.line};border-radius:10px;overflow:hidden;display:flex;flex-direction:column}
.pic{display:block;aspect-ratio:16/9;background:${t.line};overflow:hidden}
.pic img,.pic .ph{width:100%;height:100%;object-fit:cover;display:flex;font-size:40px}
.tx{padding:12px 14px 0;flex:1;display:flex;flex-direction:column;gap:3px;min-width:0}
.n{font-weight:700;font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.e{color:${t.sub};font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tx .sum{font-size:12px;-webkit-line-clamp:2}
.ft{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 14px 12px}
.go{font-size:13px;color:${t.sub}}
@media (max-width:640px){.cv{padding:24px 2px 14px}.cv h1{font-size:28px}.cv .band{height:110px}.cv .av{width:48px;height:48px}
.g{grid-template-columns:1fr 1fr;gap:10px}.tx{padding:8px 10px 0}.ft{padding:8px 10px 10px;flex-wrap:wrap}.e{display:none}.n{font-size:14px}}`,
    body: (gs, o, th) => {
      const yr = new Date().getFullYear();
      return `<div class="wrap"><header class="cv">${o.bg ? `<div class="band" style="background-image:url(${o.bg})"></div>` : ""}<div class="row1">${o.avatar ? `<img class="av" src="${o.avatar}" alt=""/>` : ""}<div><div class="kk">MOD LIST · ${yr}</div><h1>${sheetEsc(o.title)}</h1></div></div><div class="row2"><div class="meta">${sheetEsc(o.metaLine)}</div><div class="made">${sheetEsc(sheetMadeBy(o))}</div></div></header>
${gs.map((g) => sheetSec(g, `<h2><span>${sheetEsc(g.cat)}</span><span class="ct">${g.total} 个</span></h2><div class="g">${g.items.map((x) => `<div ${sheetIt(x, "it c")}><a class="pic" ${sheetLink(x)}>${sheetImg(x, th)}</a><div class="tx"><a class="n" ${sheetLink(x)}>${sheetEsc(x.zh || x.en)}</a>${x.zh && x.en && x.zh !== x.en ? `<div class="e">${sheetEsc(x.en)}</div>` : ""}${o.sum && x.sum ? `<div class="sum">${sheetEsc(x.sum)}</div>` : ""}</div><div class="ft">${sheetIdBtn(x)}${x.url ? `<a class="go" ${sheetLink(x)}>打开 ›</a>` : ""}</div></div>`).join("")}</div>`)).join("")}
<div class="foot">${sheetEsc(SHEET_AUTHOR)}</div></div>`;
    } },

  // 动态：封面 + 一条条动态（仿熟人动态流）
  feed: { name: "动态", per: 12, css: (t) => `
.wrap{max-width:1080px;margin:0 auto;background:${t.card};min-height:100vh}
.cover{height:360px;background:${t.line} center/cover;position:relative;margin-bottom:70px}
.me{position:absolute;right:40px;bottom:-50px;display:flex;align-items:flex-end;gap:18px}
.me .nm{color:#fff;font-size:26px;font-weight:700;text-shadow:0 1px 6px rgba(0,0,0,.5);margin-bottom:60px}
.av{width:120px;height:120px;border-radius:14px;object-fit:cover;border:4px solid ${t.card};font-size:44px}
.made{text-align:right;padding:0 44px 10px;font:13px ${SHEET_FONT};color:${t.sub}}
.p{display:flex;gap:18px;padding:22px 44px}
.pav{width:64px;height:64px;border-radius:10px;object-fit:cover;flex:none;font-size:24px}
.pn{color:${t.acc};font-weight:700;font-size:17px}.pt{font-size:16px;margin-top:2px}.pt b{font-weight:600}
.pimg{display:block;margin-top:10px;width:420px;max-width:100%;aspect-ratio:16/9;border-radius:8px;overflow:hidden}.pimg img,.pimg .ph{width:100%;height:100%;object-fit:cover;display:flex;font-size:40px}
.pm{display:flex;align-items:center;gap:12px;margin-top:10px;color:${t.sub};font-size:13px}
.tag{background:${t.bg};border-radius:4px;padding:1px 8px}
@media (max-width:640px){.cover{height:220px}.av{width:76px;height:76px}.me .nm{font-size:18px;margin-bottom:34px}.p{padding:16px;gap:12px}.pav{width:44px;height:44px}}`,
    body: (gs, o, th, all) => {
      const av = o.avatar ? `<img class="av" src="${o.avatar}" alt=""/>` : sheetImg(all[0] || {}, th, "av");
      const pav = o.avatar ? `<img class="pav" src="${o.avatar}" alt=""/>` : `<span class="ph pav">${sheetEsc((o.author || "我").slice(0, 1))}</span>`;
      return `<div class="wrap"><div class="cover" ${o.bg || th.get(all[0]) ? `style="background-image:url(${o.bg || th.get(all[0])})"` : ""}><div class="me"><div class="nm">${sheetEsc(o.author || o.title)}</div>${av}</div></div>
<div class="made">${sheetEsc(sheetMadeBy(o))}</div>
${gs.map((g) => sheetSec(g, g.items.map((x) => `<div ${sheetIt(x, "it p")}>${pav}<div style="flex:1;min-width:0"><div class="pn">${sheetEsc(o.author || "我")}</div><div class="pt">安利一个：<b>${sheetEsc(x.zh || x.en)}</b>${x.zh && x.en !== x.zh ? ` <span style="color:${"#999"};font-size:13px">${sheetEsc(x.en)}</span>` : ""}</div>${o.sum && x.sum ? `<div class="sum">${sheetEsc(x.sum)}</div>` : ""}<a class="pimg" ${sheetLink(x)}>${sheetImg(x, th)}</a><div class="pm"><span class="tag">${sheetEsc(g.cat)}</span>${sheetIdBtn(x)}</div></div></div>`).join(""))).join("")}
<div class="foot">${sheetEsc(SHEET_AUTHOR)}</div></div>`;
    } },

  // 歌单：黑胶唱片从封面里滑出来，播放条、A 面 / B 面分区，尾号当时长
  playlist: { name: "歌单", per: 40, css: (t) => { const a2 = t.acc2 || t.acc; return `
.wrap{max-width:1080px;margin:0 auto;min-height:100vh;background:linear-gradient(170deg,${t.acc}40,${t.bg} 460px);padding-bottom:6px}
.top{position:relative;display:flex;gap:150px;align-items:center;padding:56px 52px 26px}
.disc{position:relative;width:280px;height:280px;flex:none}
.vin{position:absolute;left:120px;top:10px;width:260px;height:260px;border-radius:50%;background:radial-gradient(circle,${t.acc} 0 46px,#111 47px 50px,transparent 51px),repeating-radial-gradient(circle,#1b1b1b 0 2px,#2a2a2a 2px 4px);box-shadow:0 10px 26px rgba(0,0,0,.3)}
.vin:after{content:"";position:absolute;inset:0;border-radius:50%;background:conic-gradient(from 20deg,transparent 0 8%,rgba(255,255,255,.16) 12%,transparent 18% 50%,rgba(255,255,255,.12) 56%,transparent 62%)}
.vin .lab{position:absolute;left:50%;top:50%;width:84px;height:84px;margin:-42px 0 0 -42px;border-radius:50%;overflow:hidden;z-index:1;object-fit:cover}
.vin .hole{position:absolute;left:50%;top:50%;width:10px;height:10px;margin:-5px 0 0 -5px;border-radius:50%;background:${t.bg};z-index:2}
.cv{position:relative;z-index:1;width:280px;height:280px;border-radius:10px;overflow:hidden;box-shadow:0 14px 30px rgba(0,0,0,.22);display:grid;grid-template-columns:1fr 1fr;background:${t.line}}
.cv img,.cv .ph{width:100%;height:100%;object-fit:cover;display:flex;font-size:30px}.cv.one{display:block}
.cv .tag{position:absolute;left:12px;bottom:12px;background:${t.card};color:${t.ink};font:700 11px ${SHEET_MONO};letter-spacing:2px;padding:3px 8px;border-radius:4px}
.info{flex:1;min-width:0}
.kind{font:700 12px ${SHEET_MONO};letter-spacing:4px;color:${t.acc}}
h1{font:800 44px/1.15 ${SHEET_FONT};margin:8px 0 6px;overflow-wrap:anywhere}
.made{font-size:28px}.meta{color:${t.sub};font-size:14px;margin-top:4px}
.ctl{display:flex;align-items:center;gap:14px;margin-top:18px}
.play{display:inline-flex;align-items:center;gap:8px;background:${t.acc};color:${t.on};border-radius:99px;padding:10px 24px;font-weight:700;box-shadow:0 6px 14px ${t.acc}55}
.ic{width:38px;height:38px;border-radius:50%;border:1.5px solid ${t.sub};display:flex;align-items:center;justify-content:center;color:${t.sub};font-size:16px}
.bar{display:flex;align-items:center;gap:10px;margin-top:16px;font:12px ${SHEET_MONO};color:${t.sub}}.bar i{flex:1;height:4px;border-radius:9px;background:linear-gradient(90deg,${t.acc} 0 38%,${t.line} 38%);position:relative}.bar i:after{content:"";position:absolute;left:38%;top:50%;width:12px;height:12px;margin:-6px 0 0 -6px;border-radius:50%;background:${t.acc};box-shadow:0 0 0 3px ${t.card}}
.side{display:flex;align-items:center;gap:12px;margin:26px 52px 8px}
.side .sd{font:900 13px ${SHEET_MONO};letter-spacing:2px;background:${t.ink};color:${t.card};border-radius:4px;padding:3px 8px}
.side h2{margin:0;font-size:19px;font-weight:800}
.side .ct{font-size:13px;color:${t.sub};letter-spacing:1px}
.side .eq{display:flex;align-items:flex-end;gap:3px;height:18px}.side .eq b{width:4px;background:${a2};border-radius:2px}
.side i{flex:1;height:1px;background:${t.line}}
.r{display:flex;align-items:center;gap:16px;padding:9px 52px;position:relative}
.r:nth-child(odd){background:${t.card}99}
.no{width:30px;text-align:right;color:${t.sub};font:600 15px ${SHEET_MONO};flex:none}
.r .th{width:54px;height:54px;border-radius:8px;overflow:hidden;flex:none;position:relative}.r .th img,.r .th .ph{width:100%;height:100%;object-fit:cover;display:flex;font-size:18px}
.ti{flex:1;min-width:0}.ti a{font-weight:700;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ti .ar{color:${t.sub};font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ti .sum{white-space:normal;-webkit-line-clamp:2}
.hot{font:700 10px ${SHEET_MONO};color:${t.on};background:${t.acc};border-radius:3px;padding:1px 5px;margin-left:6px;vertical-align:2px}
.hrt{color:${t.acc};font-size:16px;flex:none}
.r .id{background:transparent;font-family:${SHEET_MONO};width:110px;flex:none;text-align:right;padding-right:0}
@media (max-width:640px){.top{flex-direction:column;align-items:flex-start;gap:20px;padding:26px 16px 14px}.disc{width:200px;height:200px}.cv{width:200px;height:200px}.vin{width:190px;height:190px;left:70px;top:5px}h1{font-size:28px}.side{margin:20px 16px 6px}.r{padding:8px 16px;gap:10px}.hrt{display:none}}`; },
    body: (gs, o, th, all) => {
      const pics = all.filter((x) => th.get(x)).slice(0, 4);
      const cvImg = o.avatar || o.bg;
      const cv = cvImg ? `<div class="cv one"><img src="${cvImg}" alt=""/><span class="tag">VOL.${String(o.count).padStart(2, "0")}</span></div>` : pics.length >= 4 ? `<div class="cv">${pics.map((x) => sheetImg(x, th)).join("")}<span class="tag">VOL.${String(o.count).padStart(2, "0")}</span></div>` : `<div class="cv one">${sheetImg(all[0] || {}, th)}</div>`;
      const lab = o.avatar && o.bg ? `<img class="lab" src="${o.bg}" alt=""/>` : ""; // 头像当封面，背景（有的话）放唱片中间
      const sides = "ABCDEFGHIJKLMNOP", eq = [10, 16, 7, 13, 18].map((h) => `<b style="height:${h}px"></b>`).join("");
      let n = o.start || 0;
      return `<div class="wrap"><div class="top"><div class="disc"><div class="vin">${lab}<span class="hole"></span></div>${cv}</div><div class="info"><div class="kind">MOD PLAYLIST</div><h1>${sheetEsc(o.title)}</h1><div class="made">${sheetEsc(sheetMadeBy(o))}</div><div class="meta">${o.count} 首 · ${sheetEsc(o.date)}</div><div class="ctl"><span class="play">▶ 播放全部</span><span class="ic">♡</span><span class="ic">⤮</span><span class="ic">⋯</span></div><div class="bar"><span>0:38</span><i></i><span>${o.count}:00</span></div></div></div>
${gs.map((g, gi) => sheetSec(g, `<div class="side"><span class="sd">SIDE ${sides[gi % sides.length]}</span><h2>${sheetEsc(g.cat)}</h2><span class="eq">${eq}</span><i></i><span class="ct">${g.total} 首</span></div>` + g.items.map((x, k) => `<div ${sheetIt(x, "it r")}><span class="no">${String(++n).padStart(2, "0")}</span><a class="th" ${sheetLink(x)}>${sheetImg(x, th)}</a><div class="ti"><a ${sheetLink(x)}>${sheetEsc(x.zh || x.en)}${k === 0 ? `<span class="hot">HOT</span>` : ""}</a><div class="ar">${sheetEsc((x.zh && x.en !== x.zh ? x.en + " · " : "") + (SHEET_SRC[x.src] || ""))}</div>${o.sum && x.sum ? `<div class="sum">${sheetEsc(x.sum)}</div>` : ""}</div><span class="hrt">♥</span>${sheetIdBtn(x)}</div>`).join(""))).join("")}
<div class="foot">${sheetEsc(SHEET_AUTHOR)}</div></div>`;
    } },

  // 胶片：双列连续画格，黑色片基和穿孔形成统一的视觉标记
  film: { name: "胶片", per: 12, css: (t) => `
body{background:${t.bg};color:${t.ink}}
.wrap{max-width:1080px;margin:auto;padding:42px 50px 24px}
.hd{display:flex;align-items:flex-end;gap:20px;justify-content:space-between;border-bottom:1px solid ${t.ink};padding:12px 0 22px;background-size:cover;background-position:center}
.hd>div:first-child{min-width:0}.kind{font:15px ${SHEET_MONO};letter-spacing:3px;color:${t.sub}}
h1{font:800 50px/1.16 ${SHEET_FONT};margin:9px 0;overflow-wrap:anywhere;color:${t.ink}}
.meta{font-size:14px;color:${t.sub}}.made{font-size:15px;color:${t.sub};margin-top:2px}
.hd .av{width:62px;height:62px;object-fit:cover;border:1px solid ${t.ink};display:block;margin-bottom:8px}
.count{font:58px/1 ${SHEET_MONO};text-align:right;padding-left:20px;border-left:1px solid ${t.ink};color:${t.acc};flex:none}.count small{display:block;font-size:12px;letter-spacing:2px;margin-top:8px;color:${t.sub}}
h2{font:700 17px ${SHEET_FONT};margin:25px 0 12px;color:${t.ink}}h2 small{font-weight:400;font-size:13px;color:${t.sub};margin-left:6px}
.films{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));column-gap:15px;row-gap:0}
/* 胶片边固定黑色，齿孔白色 */
.frame{position:relative;background:#141414;padding:13px 27px 17px;min-width:0;display:flex;flex-direction:column;border-bottom:1px solid #2a2a2a}
.frame:before,.frame:after{content:"";position:absolute;top:8px;bottom:8px;width:10px;background:repeating-linear-gradient(to bottom,rgba(255,255,255,.88) 0 8px,transparent 8px 20px);border-radius:2px}.frame:before{left:8px}.frame:after{right:8px}
.frame:last-child:nth-child(odd){grid-column:1/-1}.screen{display:block;aspect-ratio:16/9;background:#2a2a2a;overflow:hidden}.screen img,.screen .ph{display:flex;width:100%;height:100%;object-fit:cover}.screen .ph{background:#2a2a2a;color:#ddd;font-size:40px}
.frame:last-child:nth-child(odd) .screen{aspect-ratio:2.8}
.caption{display:flex;align-items:start;justify-content:space-between;gap:7px;margin-top:9px}.caption .name{color:#f2f2f2;flex:1;min-width:0;font-size:15px;overflow-wrap:anywhere}
.frame .id{background:none;color:#cfcfcf;padding:0;flex:none}.frame .id b{color:#fff}.frame .id.ok{background:#fff;color:#141414}
.frame .sum{color:#a8a8a8}.code{font:11px ${SHEET_MONO};letter-spacing:2px;color:#8a8a8a;margin-top:5px}
.foot{border-top:1px solid ${t.ink};color:${t.sub};margin-top:24px;padding:16px 0}
@media(max-width:640px){.wrap{padding:18px 12px}h1{font-size:30px}.count{font-size:32px;padding-left:7px}.films{grid-template-columns:1fr}.frame{padding:11px 25px}.frame:last-child:nth-child(odd) .screen{aspect-ratio:16/9}}
`,
    body: (gs, o, th) => { const t = o.theme; let n=o.start||0; return `<div class="wrap"><header class="hd"${o.bg ? ` style="background-image:linear-gradient(${t.bg}d9,${t.bg}d9),url(${o.bg})"` : ""}><div>${o.avatar ? `<img class="av" src="${o.avatar}" alt=""/>` : ""}<div class="kind">STARDEW VALLEY / MOD FILM</div><h1>${sheetEsc(o.title)}</h1><div class="meta">${sheetEsc(o.metaLine)}</div><div class="made">${sheetEsc(sheetMadeBy(o))}</div></div><div class="count">${String(o.count).padStart(2,"0")}<small>FRAMES</small></div></header>
${gs.map(g=>sheetSec(g,`<h2>${sheetEsc(g.cat)}<small>${g.total} 张</small></h2><div class="films">`+g.items.map(x=>`<article ${sheetIt(x,"it frame")}><a class="screen" ${sheetLink(x)}>${sheetImg(x,th)}</a><div class="caption"><a class="name" ${sheetLink(x)}>${sheetEsc(x.zh||x.en)}</a>${sheetIdBtn(x)}</div>${o.sum&&x.sum?`<div class="sum">${sheetEsc(x.sum)}</div>`:""}<div class="code">FRAME ${String(++n).padStart(3,"0")}</div></article>`).join("")+"</div>")).join("")}<div class="foot">${sheetEsc(SHEET_AUTHOR)}</div></div>`; } },

  // 图鉴：塔罗牌。长牌、双线花边框、拱形画框、顶部太阳/底部月亮、罗马数字、名牌缎带
  magic: { name: "图鉴", per: 16, css: (t) => { const a2 = t.acc2 || t.acc; return `
body{background-color:${t.bg};background-image:radial-gradient(${t.dot} 1.5px,transparent 2px);background-size:20px 20px}
.wrap{max-width:1080px;margin:auto;padding:30px 30px 14px}
.hd{position:relative;text-align:center;padding:30px 20px 26px;overflow:hidden}
.hd .rule{display:flex;align-items:center;gap:14px;justify-content:center;font:700 12px ${SHEET_MONO};letter-spacing:5px;color:${t.sub}}.hd .rule i{width:110px;height:1px;background:${t.sub}}
.hd .orn{color:${t.acc};font-size:18px;letter-spacing:10px;margin-top:8px}
.hd h1{position:relative;font:900 50px/1.18 ${SHEET_FONT};margin:8px 0 6px;overflow-wrap:anywhere}
.hd .meta{position:relative;font-size:14px;color:${t.sub}}
.hd .made{position:relative;font-size:28px;margin-top:6px}
.hd .av{width:84px;height:84px;object-fit:cover;border-radius:50%;border:4px solid ${t.card};box-shadow:0 0 0 2px ${t.acc};margin:0 auto 10px;display:block;position:relative}
.hd.bgi{border-radius:14px}.hd.bgi:before{content:"";position:absolute;inset:0;background:var(--bg) center/cover;filter:saturate(.9)}.hd.bgi:after{content:"";position:absolute;inset:0;background:linear-gradient(${t.card}e6,${t.card}cc)}.hd.bgi>*{position:relative;z-index:1}
h2{display:flex;align-items:center;gap:12px;font-size:19px;font-weight:800;margin:26px 2px 16px}h2:before{content:"✦";color:${t.acc}}h2 i{flex:1;height:1px;background:${t.acc}}h2 small{font-size:13px;color:${t.sub};font-weight:400;letter-spacing:1px}
.deck{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:22px}
.tc{position:relative;min-width:0;display:flex;padding:6px;border-radius:14px;background:${t.acc};box-shadow:0 10px 20px rgba(0,0,0,.16)}
.tc .in{position:relative;flex:1;min-width:0;display:flex;flex-direction:column;align-items:center;border-radius:9px;padding:10px 11px 9px;background-color:${t.card};background-image:radial-gradient(${t.acc}22 1px,transparent 1.5px);background-size:14px 14px;box-shadow:inset 0 0 0 1.5px ${t.acc},inset 0 0 0 4px ${t.card},inset 0 0 0 5px ${a2}}
.tc .cn{position:absolute;font-size:11px;line-height:1;color:${t.acc}}.tc .c1{left:8px;top:8px}.tc .c2{right:8px;top:8px}.tc .c3{left:8px;bottom:8px}.tc .c4{right:8px;bottom:8px}
.tc .num{font:700 13px Georgia,"Times New Roman",serif;letter-spacing:3px;color:${t.ink};margin-top:2px}
.tc .sun,.tc .moon{color:${t.acc}}
.tc .sun{width:46px;height:24px;display:block;margin:2px 0 -6px;position:relative;z-index:2}
.tc .art{position:relative;display:block;width:100%;aspect-ratio:1/1;border-radius:999px 999px 8px 8px;overflow:hidden;border:2px solid ${t.acc};box-shadow:0 0 0 3px ${t.card},0 0 0 4px ${a2};background:${t.line}}
.tc .art img,.tc .art .ph{width:100%;height:100%;object-fit:cover;display:flex;font-size:40px;align-items:center;justify-content:center}
.tc .art:after{content:"";position:absolute;inset:0;pointer-events:none;mix-blend-mode:screen;opacity:.7;background:linear-gradient(125deg,transparent 22%,rgba(255,130,200,.26) 34%,rgba(255,220,130,.26) 42%,rgba(140,255,210,.26) 50%,rgba(130,200,255,.26) 58%,rgba(200,160,255,.26) 66%,transparent 78%)}
.tc .rib{position:relative;margin:10px -4px 0;align-self:stretch;padding:5px 18px;text-align:center;background:${t.acc};color:${t.on};clip-path:polygon(0 0,100% 0,94% 50%,100% 100%,0 100%,6% 50%)}
.tc .rib .nm{display:block;font-weight:800;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:inherit}
.tc .fl{align-self:stretch;font:italic 12px/1.35 Georgia,"Times New Roman",serif;color:${t.sub};margin-top:5px;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;letter-spacing:.5px}
.tc .sum{margin-top:4px;font-size:11px;line-height:1.45;color:${t.sub};text-align:center;-webkit-line-clamp:2}
.tc .moon{position:absolute;left:50%;top:50%;width:18px;height:18px;margin:-9px 0 0 -9px}
.tc .bot{position:relative;align-self:stretch;display:flex;align-items:center;justify-content:space-between;gap:4px;margin-top:auto;padding:12px 8px 0;font:10px ${SHEET_MONO};color:${t.sub}}
.tc .bot .id{padding:1px 6px;background:${t.bg}}.tc .bot .id b{font-size:12px}
@media(max-width:640px){.wrap{padding:16px 10px}.hd h1{font-size:28px}.deck{grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.tc .rib{padding:4px 14px}}`; },
    body: (gs, o, th) => {
      let n = o.start || 0;
      const roman = (k) => { let r = ""; for (const [v, s] of [[1000, "M"], [900, "CM"], [500, "D"], [400, "CD"], [100, "C"], [90, "XC"], [50, "L"], [40, "XL"], [10, "X"], [9, "IX"], [5, "V"], [4, "IV"], [1, "I"]]) while (k >= v) { r += s; k -= v; } return r; };
      const sun = `<svg class="sun" viewBox="0 0 46 24"><g stroke="currentColor" stroke-width="1.4" stroke-linecap="round">${[-80, -55, -30, 0, 30, 55, 80].map((d) => { const a = (d - 90) * Math.PI / 180; return `<line x1="${(23 + Math.cos(a) * 10).toFixed(1)}" y1="${(22 + Math.sin(a) * 10).toFixed(1)}" x2="${(23 + Math.cos(a) * 17).toFixed(1)}" y2="${(22 + Math.sin(a) * 17).toFixed(1)}"/>`; }).join("")}</g><path d="M15 22a8 8 0 0 1 16 0z" fill="currentColor"/></svg>`;
      const moon = `<svg class="moon" viewBox="0 0 20 20"><path d="M13 2.5a8 8 0 1 0 4.5 13A6.5 6.5 0 0 1 13 2.5z" fill="currentColor"/><circle cx="16" cy="5" r="1" fill="currentColor"/></svg>`;
      return `<div class="wrap"><header class="hd${o.bg ? " bgi" : ""}"${o.bg ? ` style="--bg:url(${o.bg})"` : ""}>${o.avatar ? `<img class="av" src="${o.avatar}" alt=""/>` : ""}<div class="rule"><i></i>STARDEW · MOD CARDS<i></i></div><div class="orn">✧ ☾ ✦ ☽ ✧</div><h1>${sheetEsc(o.title)}</h1><div class="meta">${sheetEsc(o.metaLine)}</div><div class="made">${sheetEsc(sheetMadeBy(o))}</div></header>
${gs.map((g) => sheetSec(g, `<h2>${sheetEsc(g.cat)}<i></i><small>${g.total} 张</small></h2><div class="deck">` + g.items.map((x) => { n++;
  return `<article ${sheetIt(x, "it tc")}><div class="in"><span class="cn c1">✦</span><span class="cn c2">✦</span><span class="cn c3">✦</span><span class="cn c4">✦</span><div class="num">${roman(n)}</div>${sun}<a class="art" ${sheetLink(x)}>${sheetImg(x, th)}</a><div class="rib"><a class="nm" ${sheetLink(x)}>${sheetEsc(x.zh || x.en)}</a></div>${x.zh && x.en && x.zh !== x.en ? `<div class="fl">${sheetEsc(x.en)}</div>` : ""}${o.sum && x.sum ? `<div class="sum">${sheetEsc(x.sum)}</div>` : ""}<div class="bot"><span>${sheetEsc(SHEET_SRC[x.src] || "MOD")}</span>${moon}${sheetIdBtn(x)}</div></div></article>`; }).join("") + "</div>")).join("")}
<div class="foot">${sheetEsc(SHEET_AUTHOR)}</div></div>`;
    } },

  // 手账：拼贴本。格子纸底，照片轮流用 拍立得 / 圆贴纸 / 便利贴 / 撕边照片 / 票根 五种贴法，胶带、贴纸、印章点缀
  journal: { name: "手账", per: 10, css: (t) => { const a2 = t.acc2 || t.acc, hand = SHEET_FONT;
    const tape = (c1, c2) => `repeating-linear-gradient(-45deg,${c1}cc 0 7px,${c2}cc 7px 14px)`;
    return `
body{background-color:${t.bg};background-image:linear-gradient(${t.line}88 1px,transparent 1px),linear-gradient(90deg,${t.line}88 1px,transparent 1px);background-size:27px 27px;color:${t.ink}}
.wrap{max-width:1080px;margin:auto;padding:34px 40px 10px;overflow:hidden}
.jh{position:relative;display:flex;align-items:center;gap:34px;padding:16px 6px 34px}
.jt{position:relative;flex:1;min-width:0;background:${t.card};padding:24px 30px 20px;transform:rotate(-1.2deg);box-shadow:0 8px 18px rgba(0,0,0,.13);clip-path:polygon(0 3%,3% 0,9% 2%,16% 0,24% 2%,33% 0,41% 2%,50% 0,58% 2%,67% 0,75% 2%,84% 0,92% 2%,100% 0,99% 50%,100% 100%,92% 98%,84% 100%,75% 98%,67% 100%,58% 98%,50% 100%,41% 98%,33% 100%,24% 98%,16% 100%,9% 98%,3% 100%,0 97%,1% 50%)}
.jt .kind{font:13px ${SHEET_MONO};letter-spacing:3px;color:${t.sub}}
.jt h1{font:50px/1.2 ${hand};margin:6px 0 4px;overflow-wrap:anywhere}
.jt .meta{font:16px ${hand};color:${t.sub}}
.jt .made{font-size:22px;margin-top:2px}
.jt svg{display:block;width:240px;height:14px;margin:4px 0 2px}
.tp{position:absolute;width:110px;height:28px;background:${tape(t.acc, a2)};opacity:.85;z-index:3}
.jh .tp1{left:-18px;top:-6px;transform:rotate(-28deg)}.jh .tp2{right:-14px;bottom:-4px;transform:rotate(-24deg);background:${tape(a2, t.card)}}
.jside{position:relative;flex:none;width:250px;display:flex;justify-content:center}
.jside .bgp{width:250px;aspect-ratio:4/3;object-fit:cover;background:#fff;padding:9px 9px 26px;transform:rotate(4deg);box-shadow:0 8px 18px rgba(0,0,0,.18)}
.jside .av{position:absolute;left:-26px;bottom:-24px;width:104px;height:104px;border-radius:50%;object-fit:cover;border:6px solid ${t.card};box-shadow:0 0 0 3px ${t.acc},0 6px 14px rgba(0,0,0,.18);z-index:4}
.jside .av.solo{position:static;width:150px;height:150px}
.stamp{width:150px;height:150px;border-radius:50%;border:4px double ${t.acc};color:${t.acc};display:flex;flex-direction:column;align-items:center;justify-content:center;transform:rotate(12deg);font:700 15px ${SHEET_MONO};letter-spacing:2px;opacity:.9;text-align:center;line-height:1.3}
.stamp b{font:30px ${hand};letter-spacing:0}
.jsec{position:relative;margin:22px 0 6px}
.jsec h2{display:inline-block;margin:0 0 0 10px;padding:6px 30px 6px 24px;font:23px ${hand};color:${t.on};background:${tape(t.acc, t.acc)};background:${t.acc};transform:rotate(-2deg);clip-path:polygon(0 0,100% 0,96% 50%,100% 100%,0 100%,4% 50%)}
.jsec h2 small{font:14px ${SHEET_FONT};opacity:.85;margin-left:6px}
.jsec .doodle{position:absolute;left:auto;margin-left:14px;font-size:26px;color:${a2};top:2px}
.jb{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:40px 26px;padding:22px 10px 26px;align-items:start}
.k{position:relative;min-width:0}
.k .nm{display:block;font:19px/1.3 ${hand};overflow-wrap:anywhere}
.k .id{background:${t.bg}}
.k .sum{font-size:12px}
.k .ph{font:40px ${hand}}
/* 1 拍立得 */
.ka{grid-column:span 2;background:#fff;color:#333;padding:12px 12px 14px;box-shadow:0 7px 16px rgba(0,0,0,.16);transform:rotate(-3deg)}
.ka .pic{display:block;aspect-ratio:1;overflow:hidden;background:${t.line}}.ka .pic img,.ka .pic .ph{width:100%;height:100%;object-fit:cover;display:flex}
.ka .cap{text-align:center;padding-top:9px}.ka .nm{color:#333}.ka .id{background:#f1f1f1;color:#777}.ka .id b{color:#333}.ka .sum{color:#888}
.ka:before{content:"";position:absolute;top:-13px;left:50%;margin-left:-46px;width:92px;height:26px;background:${tape(t.acc, a2)};opacity:.85;transform:rotate(-5deg)}
.ka:after{content:"★";position:absolute;right:-14px;bottom:-16px;font-size:40px;color:${a2};transform:rotate(14deg);text-shadow:0 2px 0 rgba(0,0,0,.12)}
/* 2 圆贴纸 */
.kb{grid-column:span 2;text-align:center;transform:rotate(2deg);margin-top:20px}
.kb .pic{display:block;width:84%;margin:0 auto;aspect-ratio:1;border-radius:50%;overflow:hidden;border:8px solid ${t.card};box-shadow:0 0 0 3px ${t.acc},0 8px 16px rgba(0,0,0,.15)}.kb .pic img,.kb .pic .ph{width:100%;height:100%;object-fit:cover;display:flex}
.kb .rib{display:inline-block;margin-top:-18px;position:relative;background:${t.acc};color:${t.on};padding:5px 22px;clip-path:polygon(0 0,100% 0,94% 50%,100% 100%,0 100%,6% 50%);max-width:100%}
.kb .rib .nm{color:${t.on};font-size:18px}
.kb .meta2{margin-top:7px}.kb .sum{margin-top:4px}
.kb:before{content:"♥";position:absolute;left:2px;top:-8px;font-size:34px;color:${a2};transform:rotate(-16deg)}
/* 3 便利贴 */
.kc{grid-column:span 2;background:linear-gradient(${a2}38,${a2}38),${t.card};padding:22px 14px 16px;transform:rotate(-1.5deg);box-shadow:2px 7px 12px rgba(0,0,0,.13);margin-top:-6px}
.kc:before{content:"";position:absolute;top:-9px;left:50%;margin-left:-11px;width:22px;height:22px;border-radius:50%;background:radial-gradient(circle at 35% 35%,#fff8 0 3px,${t.acc} 4px);box-shadow:0 3px 4px rgba(0,0,0,.25)}
.kc:after{content:"";position:absolute;right:0;bottom:0;width:30px;height:30px;background:linear-gradient(135deg,${t.line} 50%,${t.bg} 50%)}
.kc .pic{display:block;aspect-ratio:4/3;overflow:hidden;border:5px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,.12)}.kc .pic img,.kc .pic .ph{width:100%;height:100%;object-fit:cover;display:flex}
.kc .nm{margin-top:9px;text-decoration:underline wavy ${t.acc}88;text-underline-offset:5px}.kc .meta2{margin-top:7px}
/* 4 撕边照片 + 回形针 + 标签 */
.kd{grid-column:span 3;transform:rotate(1.6deg)}
.kd .pic{display:block;aspect-ratio:16/10;overflow:hidden;background:${t.line};clip-path:polygon(0 0,100% 0,100% 92%,96% 97%,92% 93%,87% 98%,82% 94%,77% 99%,72% 94%,66% 98%,61% 93%,55% 97%,50% 93%,44% 98%,38% 94%,33% 99%,27% 94%,21% 98%,15% 93%,9% 97%,4% 93%,0 97%);box-shadow:0 6px 14px rgba(0,0,0,.15)}
.kd .pic img,.kd .pic .ph{width:100%;height:100%;object-fit:cover;display:flex}
.kd .clip{position:absolute;left:22px;top:-22px;width:26px;height:64px;z-index:3;transform:rotate(-8deg)}
.kd .tag{position:relative;display:inline-block;max-width:86%;margin:-24px 0 0 26px;background:${t.card};border:2px dashed ${t.acc};border-radius:4px;padding:9px 14px;transform:rotate(-2.5deg);box-shadow:0 4px 10px rgba(0,0,0,.1)}
.kd .tag .meta2{margin-top:5px}
/* 5 票根 */
.ke{grid-column:span 3;display:flex;background:${t.card};border-radius:12px;box-shadow:0 6px 14px rgba(0,0,0,.13);transform:rotate(-1deg);margin-top:16px;min-height:150px}
.ke .pic{display:block;width:44%;flex:none;overflow:hidden;border-radius:12px 0 0 12px;background:${t.line}}.ke .pic img,.ke .pic .ph{width:100%;height:100%;object-fit:cover;display:flex;min-height:150px}
.ke .tx{position:relative;flex:1;min-width:0;padding:14px 16px 14px 20px;border-left:3px dashed ${t.line}}
.ke .tx:before,.ke .tx:after{content:"";position:absolute;left:-12px;width:22px;height:22px;border-radius:50%;background:${t.bg}}.ke .tx:before{top:-11px}.ke .tx:after{bottom:-11px}
.ke .lab{font:12px ${SHEET_MONO};letter-spacing:3px;color:${t.acc}}
.ke .meta2{margin-top:8px}
.ke .tx{padding-right:66px}
.ke .pick{position:absolute;right:10px;top:10px;width:52px;height:52px;border-radius:50%;border:2px solid ${a2};color:${a2};font:700 12px ${SHEET_MONO};display:flex;align-items:center;justify-content:center;transform:rotate(-16deg);opacity:.85}
.foot{margin-top:8px;padding:16px 0 18px;font-family:${hand};font-size:14px}
/* 荧光笔、手写批注、更多胶带花纹 */
.k .nm{background:linear-gradient(transparent 60%,${a2}70 60%);display:inline;box-decoration-break:clone;-webkit-box-decoration-break:clone}
.kb .rib .nm{background:none}
.say{position:absolute;right:-8px;top:-40px;z-index:6;font:22px/1 ${hand};color:${t.acc};transform:rotate(7deg);white-space:nowrap;display:flex;align-items:flex-end;gap:2px}
.say svg{width:34px;height:30px;margin-bottom:-14px}
.ka:nth-of-type(2n):before{background:radial-gradient(${t.card} 2.2px,transparent 2.8px) 0 0/9px 9px,${a2}d0}
.kc:nth-of-type(2n){background:linear-gradient(${t.acc}22,${t.acc}22),repeating-linear-gradient(${t.card} 0 21px,${t.line} 21px 22px)}
.kd:nth-of-type(2n) .tag{border-style:solid;border-width:0 0 0 6px;border-color:${a2}}
.end{display:flex;align-items:center;justify-content:center;gap:14px;margin:8px 0 0;font:26px ${hand};color:${t.acc}}.end i{width:90px;height:2px;background:repeating-linear-gradient(90deg,${t.acc} 0 8px,transparent 8px 13px)}
.jh .spark{position:absolute;left:46%;top:2px;width:54px;height:54px;z-index:4}
.jh .arrow{position:absolute;left:62%;bottom:4px;width:110px;height:46px;z-index:4}
@media(max-width:640px){.wrap{padding:16px 12px}.jh{flex-direction:column;align-items:stretch;gap:30px}.jt h1{font-size:30px}.jside{width:auto}.jb{grid-template-columns:repeat(2,minmax(0,1fr));gap:30px 16px}.ka,.kb,.kc{grid-column:span 1}.kd,.ke{grid-column:1/-1}.k .nm{font-size:16px}}
`; },
    body: (gs, o, th) => {
      const t = o.theme, a2 = t.acc2 || t.acc;
      const d = new Date(), ymd = `${d.getFullYear()}<br><b>${d.getMonth() + 1}.${d.getDate()}</b>`;
      const clip = `<svg class="clip" viewBox="0 0 26 64" fill="none" stroke="${t.sub}" stroke-width="3" stroke-linecap="round"><path d="M8 20V8a5 5 0 0 1 10 0v44a8 8 0 0 1-16 0V16"/><path d="M13 14v34"/></svg>`;
      const wave = `<svg viewBox="0 0 240 14"><path d="M2 7q10-8 20 0t20 0 20 0 20 0 20 0 20 0 20 0 20 0 20 0 20 0 20 0 20 0" fill="none" stroke="${a2}" stroke-width="3" stroke-linecap="round"/></svg>`;
      let side = "";
      if (o.bg) side = `<img class="bgp" src="${o.bg}" alt=""/>${o.avatar ? `<img class="av" src="${o.avatar}" alt=""/>` : ""}`;
      else if (o.avatar) side = `<img class="av solo" src="${o.avatar}" alt=""/>`;
      else side = `<div class="stamp">MOD LOG${"<br>"}${ymd}</div>`;
      const meta = (x) => `<div class="meta2">${sheetIdBtn(x)}</div>${o.sum && x.sum ? `<div class="sum">${sheetEsc(x.sum)}</div>` : ""}`;
      const nm = (x) => `<a class="nm" ${sheetLink(x)}>${sheetEsc(x.zh || x.en)}</a>`;
      const pic = (x) => `<a class="pic" ${sheetLink(x)}>${sheetImg(x, th)}</a>`;
      const sayList = ["必装！", "超好用", "强推 ♥", "爱了爱了", "宝藏", "回坑必备", "无脑冲"];
      const arr = `<svg viewBox="0 0 34 30" fill="none" stroke="${t.acc}" stroke-width="2.4" stroke-linecap="round"><path d="M30 3C22 6 10 10 6 24"/><path d="M2 17l4 8 7-5"/></svg>`;
      let sc = 0;
      const say = () => (sc++ % 3 === 1) ? `<span class="say">${sayList[Math.floor(sc / 3) % sayList.length]}${arr}</span>` : "";
      const kinds = [
        (x) => `<article ${sheetIt(x, "it k ka")}>${say()}${pic(x)}<div class="cap">${nm(x)}${meta(x)}</div></article>`,
        (x) => `<article ${sheetIt(x, "it k kb")}>${say()}${pic(x)}<div class="rib">${nm(x)}</div>${meta(x)}</article>`,
        (x) => `<article ${sheetIt(x, "it k kc")}>${say()}${pic(x)}${nm(x)}${meta(x)}</article>`,
        (x) => `<article ${sheetIt(x, "it k kd")}>${say()}${clip}${pic(x)}<div class="tag">${nm(x)}${meta(x)}</div></article>`,
        (x) => `<article ${sheetIt(x, "it k ke")}>${say()}${pic(x)}<div class="tx"><div class="lab">ADMIT ONE · MOD</div>${nm(x)}${meta(x)}<div class="pick">PICK!</div></div></article>`,
      ];
      const doodles = ["✿", "☁", "✎", "♪", "✦"];
      // 每组按行排：三张小的（拍立得 / 圆贴纸 / 便利贴）一行，两张大的（撕边照片 / 票根）一行，交替；剩一张用票根
      const lay = (list) => { const out = []; let i = 0, row = 0;
        while (i < list.length) { const rem = list.length - i;
          if (rem === 1) { out.push(kinds[4](list[i++])); break; }
          if ((row % 2 === 0 && rem !== 2 && rem !== 4) || rem === 3) { for (let k = 0; k < 3; k++) out.push(kinds[k](list[i++])); }
          else { out.push(kinds[3](list[i++]), kinds[4](list[i++])); }
          row++; }
        return out.join(""); };
      return `<div class="wrap"><header class="jh"><svg class="spark" viewBox="0 0 54 54" fill="${a2}"><path d="M27 2l5 18 18 5-18 5-5 18-5-18-18-5 18-5z"/></svg><svg class="arrow" viewBox="0 0 110 46" fill="none" stroke="${t.acc}" stroke-width="2.5" stroke-linecap="round"><path d="M4 30c20-26 46-26 60-8 8 10 22 10 38-6"/><path d="M92 10l11 5-6 11"/></svg><div class="jt"><span class="tp tp1"></span><span class="tp tp2"></span><div class="kind">MY STARDEW SCRAPBOOK</div><h1>${sheetEsc(o.title)}</h1>${wave}<div class="meta">${sheetEsc(o.metaLine)}</div><div class="made">${sheetEsc(sheetMadeBy(o))}</div></div><div class="jside">${side}</div></header>
${gs.map((g, gi) => sheetSec(g, `<div class="jsec"><h2>${sheetEsc(g.cat)}<small>${g.total}</small></h2><span class="doodle">${doodles[gi % doodles.length]}</span></div><div class="jb">${lay(g.items)}</div>`)).join("")}
<div class="end"><i></i>THE END ♥<i></i></div><div class="foot">${sheetEsc(SHEET_AUTHOR)}</div></div>`;
    } },

  // 小票：收银条，一行一个 Mod，尾号当价格
  receipt: { name: "小票", per: 60, css: (t) => `
body{background:${t.bg};font-family:${SHEET_MONO}}
.wrap{max-width:1080px;margin:0 auto;padding:40px 16px}
.paper{width:620px;max-width:100%;margin:0 auto;background:#fffefa;color:#333;padding:34px 34px 26px;box-shadow:0 8px 24px rgba(0,0,0,.12);position:relative}
.paper:after{content:"";position:absolute;left:0;right:0;bottom:-12px;height:12px;background:linear-gradient(-45deg,transparent 8px,#fffefa 0) 0 0/16px 12px,linear-gradient(45deg,transparent 8px,#fffefa 0) 0 0/16px 12px}
.c{text-align:center}.shop{font-size:24px;font-weight:700;letter-spacing:4px}.small{font-size:13px;color:#777}
.dash{border-top:2px dashed #bbb;margin:14px 0}
h2{font-size:14px;margin:12px 0 4px;font-weight:700}
.r{display:flex;gap:8px;font-size:14px;align-items:baseline;padding:2px 0}.r a{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.r .dots{flex:1;border-bottom:2px dotted #ccc;min-width:20px;transform:translateY(-4px)}.r a{flex:0 1 auto}
.r .id{background:none;padding:0;color:#333;font-size:14px}.r .id b{font-size:14px;color:#333}.r .id.ok{color:${t.acc};background:none}.r .id.ok b{color:${t.acc}}
.r .sum{display:none}
.sub{display:flex;justify-content:space-between;font-size:13px;color:#777}
.tot{display:flex;justify-content:space-between;font-size:20px;font-weight:700}
.bar{height:56px;margin:16px auto 6px;width:80%;background:repeating-linear-gradient(90deg,#333 0 2px,transparent 2px 4px,#333 4px 7px,transparent 7px 9px,#333 9px 10px,transparent 10px 13px)}
.made{font-size:24px;text-align:center;margin-top:8px}
.foot{font-family:${SHEET_FONT}}`,
    body: (gs, o) => `<div class="wrap"><div class="paper"><div class="c"><div class="shop">星露谷 MOD 铺</div><div class="small">${sheetEsc(o.title)}</div><div class="small">${sheetEsc(o.date)}${o.author ? " · 顾客：" + sheetEsc(o.author) : ""}</div></div><div class="dash"></div>
<div class="sub"><span>品名</span><span>尾号</span></div>
${gs.map((g) => sheetSec(g, `<h2>【${sheetEsc(g.cat)}】</h2>` + g.items.map((x) => `<div ${sheetIt(x, "it r")}><a ${sheetLink(x)}>${sheetEsc(x.zh || x.en)}</a><span class="dots"></span>${x.nid ? `<button class="id" data-id="${x.nid}"><b>#${x.nid}</b></button>` : `<span class="id nn">${sheetEsc(SHEET_SRC[x.src] || "其他")}</span>`}</div>`).join("") + `<div class="sub"><span>小计</span><span>${g.total} 件</span></div>`)).join("")}
<div class="dash"></div><div class="tot"><span>合计</span><span>${o.count} 件</span></div><div class="sub"><span>其中 Nexus</span><span>${o.nexus} 件</span></div>
<div class="bar"></div><div class="c small">谢谢惠顾 · 欢迎再来</div><div class="made">${sheetEsc(sheetMadeBy(o))}</div></div>
<div class="foot">${sheetEsc(SHEET_AUTHOR)}</div></div>` },
};
// 自制样式：玩家把「给 AI 的说明」发给任意 AI，拿回一份模板粘贴/打开进来。
// 模板语法：{{变量}} 替换；{{#x}}…{{/x}} 列表就循环、有值才显示；{{^x}}…{{/x}} 没值才显示。脚本、事件、外链图片一律去掉。
const SHEET_CUSTOM_DEMO = `<!-- name: 示例 -->
<!-- per: 30 -->
<style>
.page{max-width:1000px;margin:0 auto;padding:40px 30px 10px}
.head{display:flex;align-items:center;gap:16px;padding-bottom:18px;border-bottom:2px solid var(--ink)}
.head img{width:64px;height:64px;border-radius:50%;object-fit:cover}
.head h1{margin:0;font-size:38px}
.head p{margin:4px 0 0;color:var(--sub);font-size:14px}
.grp h2{font-size:18px;margin:26px 0 10px;color:var(--acc)}
.grp h2 small{color:var(--sub);font-weight:400;margin-left:6px}
.list{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.mod{display:flex;gap:10px;align-items:center;background:var(--card);border:1px solid var(--line);border-radius:12px;padding:8px}
.mod .pic{width:64px;height:64px;border-radius:8px;object-fit:cover;flex:none}
.mod .name{font-weight:700;font-size:14px}
.mod .en{color:var(--sub);font-size:12px}
@media(max-width:640px){.list{grid-template-columns:1fr}}
</style>
<div class="page">
  <div class="head">{{#avatar}}<img src="{{avatar}}">{{/avatar}}<div><h1>{{title}}</h1><p>{{meta}} · {{made}}</p></div></div>
  {{#groups}}<div class="grp"><h2>{{cat}}<small>{{total}} 个</small></h2><div class="list">
    {{#items}}<div class="mod">{{#img}}<img class="pic" src="{{img}}">{{/img}}{{^img}}<div class="pic ph">{{initial}}</div>{{/img}}<div><a class="name" href="{{url}}">{{name}}</a><div class="en">{{en}}</div>{{idbtn}}</div></div>{{/items}}
  </div></div>{{/groups}}
  <div class="foot">{{footer}}</div>
</div>`;
const SHEET_CUSTOM_GUIDE = `请帮我写一份「星露管理器」Mod 清单的分享模板。只回复模板代码本身，不要解释。

【我想要的样子】
（在这里写你想要的风格，比如：复古报纸风、粉色可爱风、像游戏图鉴……）

【格式要求】
1. 只能用 HTML 和 CSS，写在一起：CSS 放在 <style> 里，其余是页面内容。不要写 <html>、<head>、<body>，不要用 JavaScript。
2. 不要引用任何外部文件（外部字体、外部图片、CDN 都不行），字体只用系统自带字体。
3. 页面按 1080 像素宽设计，手机上也要能看（加一个 @media(max-width:640px) 的适配）。
4. 第一行写 <!-- name: 样式名字 -->，第二行写 <!-- per: 30 -->（每张图放多少个 Mod，Mod 卡片大就写少一点）。
5. 颜色请用这些变量，玩家换配色时会自动变：var(--bg) 底色、var(--card) 卡片色、var(--ink) 主文字、var(--sub) 次要文字、var(--acc) 主色、var(--acc2) 撞色、var(--line) 线条、var(--on) 主色上的文字色、var(--font) 字体。

【可以用的内容】（用两个大括号包起来）
整页：{{title}} 标题、{{made}} 作者署名、{{meta}} 一行信息（名字 · 数量 · 日期）、{{count}} Mod 总数、{{date}} 日期、{{author}} 名字、{{avatar}} 头像图片、{{bg}} 背景图片、{{footer}} 底部署名（必须放上）。
分类循环：{{#groups}} … {{/groups}}，里面可用 {{cat}} 分类名、{{total}} 这个分类一共几个、{{index}} 第几个分类。
Mod 循环（必须写在分类循环里面）：{{#items}} … {{/items}}，里面可用 {{name}} 名字、{{en}} 英文名、{{img}} 图片、{{initial}} 名字第一个字、{{url}} Nexus 链接、{{idbtn}} 尾号按钮（点一下能复制，推荐用它）、{{id}} 尾号数字、{{src}} 来源、{{sum}} 简介、{{no}} 序号。
有值才显示：{{#img}} … {{/img}}；没有值时显示：{{^img}} … {{/img}}（头像、背景、简介、图片都可以这样用）。

【示例】
${SHEET_CUSTOM_DEMO}`;
function sheetCustomTpl() { return prefGet("sheetCustom", "") || SHEET_CUSTOM_DEMO; }
function sheetTplSplit(tpl) {
  tpl = String(tpl || ""); let css = "";
  const body = tpl.replace(/<style[^>]*>([\s\S]*?)<\/style>/gi, (m, c) => { css += c + "\n"; return ""; });
  const name = (tpl.match(/<!--\s*name\s*[:：]\s*([^\n]*?)\s*-->/i) || [])[1] || "";
  const per = Math.max(4, Math.min(80, parseInt((tpl.match(/<!--\s*per\s*[:：]\s*(\d+)/i) || [])[1], 10) || 30));
  return { css, body, name: name.slice(0, 30), per };
}
const sheetCssClean = (css) => String(css || "").replace(/<\/?\s*style[^>]*>/gi, "").replace(/@import[^;]*;?/gi, "").replace(/expression\s*\(/gi, "(").replace(/(java|vb)script\s*:/gi, "")
  .replace(/url\(\s*(['"]?)\s*(?!data:image\/)[a-z][a-z0-9+.-]*:[^)]*\)/gi, "none").replace(/url\(\s*(['"]?)\s*\/\/[^)]*\)/gi, "none");
function sheetTplRender(src, ctx) {
  const look = (stack, k) => { for (let i = stack.length - 1; i >= 0; i--) { const s = stack[i]; if (s && typeof s === "object" && k in s) return s[k]; } return undefined; };
  const run = (txt, stack) => txt.replace(/\{\{([#^])\s*(\w+)\s*\}\}([\s\S]*?)\{\{\/\s*\2\s*\}\}|\{\{\{?\s*(\w+)\s*\}?\}\}/g, (m, op, k, inner, v) => {
    if (op) {
      const val = look(stack, k), yes = Array.isArray(val) ? val.length > 0 : !!val;
      if (op === "^") return yes ? "" : run(inner, stack);
      if (!yes) return "";
      if (Array.isArray(val)) return val.map((x) => k === "items" ? `<div ${sheetIt(x.__x, "it cit")}>${run(inner, [...stack, x])}</div>` : k === "groups" ? sheetSec(x, run(inner, [...stack, x])) : run(inner, [...stack, x])).join("");
      return run(inner, typeof val === "object" ? [...stack, val] : stack);
    }
    const val = look(stack, v);
    return val == null ? "" : typeof val === "object" ? (val.__html || "") : sheetEsc(val);
  });
  return run(src, [ctx]);
}
function sheetHtmlClean(html) {
  const doc = new DOMParser().parseFromString(`<!doctype html><body>${html}</body>`, "text/html");
  doc.body.querySelectorAll("script,iframe,object,embed,link,meta,base,form,frame,frameset,style,noscript,template,audio,video").forEach((e) => e.remove());
  doc.body.querySelectorAll("*").forEach((el) => {
    for (const a of [...el.attributes]) {
      const n = a.name.toLowerCase(), v = a.value.replace(/\s/g, "").toLowerCase();
      if (n.startsWith("on") || ["srcdoc", "formaction", "srcset"].includes(n)) el.removeAttribute(a.name);
      else if (["href", "src", "xlink:href", "poster", "background", "action"].includes(n) && (/^(javascript|vbscript|data:text)/.test(v) || (n !== "href" && /^([a-z][a-z0-9+.-]*:|\/\/)/.test(v) && !v.startsWith("data:image/")))) el.removeAttribute(a.name);
      else if (n === "style") el.setAttribute("style", sheetCssClean(a.value));
    }
    if (el.tagName === "A") { const h = el.getAttribute("href") || ""; if (/^https?:/i.test(h)) { el.setAttribute("target", "_blank"); el.setAttribute("rel", "noopener"); } else el.removeAttribute("href"); }
  });
  return doc.body.innerHTML;
}
SHEET_STYLES.custom = { name: "自制",
  get per() { return sheetTplSplit(sheetCustomTpl()).per; },
  css: (t) => `:root{--bg:${t.bg};--card:${t.card};--ink:${t.ink};--sub:${t.sub};--acc:${t.acc};--acc2:${t.acc2 || t.acc};--line:${t.line};--dot:${t.dot};--on:${t.on};--font:${SHEET_FONT}}
.cit,section[data-sec]{display:contents}.made{font-family:inherit;font-size:inherit;color:inherit}
${sheetCssClean(sheetTplSplit(sheetCustomTpl()).css)}`,
  body: (gs, o, th) => {
    let n = o.start || 0;
    const ctx = { title: o.title, made: sheetMadeBy(o), meta: o.metaLine, count: o.count, date: o.date, author: o.author || "", avatar: o.avatar || "", bg: o.bg || "", page: o.pg || "", footer: SHEET_AUTHOR,
      groups: gs.map((g, gi) => ({ cat: g.cat, total: g.total, index: gi + 1, items: g.items.map((x) => ({ __x: x, no: ++n, name: x.zh || x.en, zh: x.zh || "", en: x.zh && x.en !== x.zh ? x.en : "", img: th.get(x) || "", initial: (x.zh || x.en || "?").slice(0, 1),
        url: x.url || "", id: x.nid || "", idbtn: { __html: sheetIdBtn(x) }, src: SHEET_SRC[x.src] || "", sum: o.sum ? x.sum || "" : "", cat: g.cat })) })) };
    try { return sheetHtmlClean(sheetTplRender(sheetTplSplit(sheetCustomTpl()).body, ctx)); }
    catch (e) { return `<p style="padding:60px;text-align:center">模板有问题：${sheetEsc(e.message)}</p>`; }
  } };

function sheetRanges() {
  const inst = allMods().filter((m) => m.installed && !m.ignored);
  const r = [{ key: "inst", label: `已安装的全部（${inst.length}）`, title: "我的星露谷 Mod 清单", ids: inst.map((m) => m.id) },
    { key: "on", label: `正在用的（${inst.filter((m) => !m.disabled).length}）`, title: "我的星露谷 Mod 清单", ids: inst.filter((m) => !m.disabled).map((m) => m.id) }];
  state.packs.forEach((p) => { const ids = packIds(p); r.push({ key: "p:" + p.name, label: `合集：${p.name}（${ids.length}）`, title: p.name, ids }); });
  return r;
}
const sheetSrcOf = (m) => m.nexus_id ? "nexus" : (SHEET_SRC[m.source] && m.source !== "nexus" ? m.source : "other");
// 上传的头像 / 背景：缩小后存成 data URL（只在这台电脑的浏览器里记着）
const sheetUp = { avatar: null, bg: null };
try { sheetUp.avatar = localStorage.getItem("sheetAvatar"); sheetUp.bg = localStorage.getItem("sheetBg"); } catch (e) {}
function sheetShrinkFile(file, max, square) {
  return new Promise((ok, no) => {
    const img = new Image(), url = URL.createObjectURL(file);
    img.onload = () => {
      let sw = img.width, sh = img.height, sx = 0, sy = 0;
      if (square) { const s = Math.min(sw, sh); sx = (sw - s) / 2; sy = (sh - s) / 2; sw = sh = s; }
      const k = Math.min(1, max / Math.max(sw, sh)), c = document.createElement("canvas");
      c.width = Math.round(sw * k); c.height = Math.round(sh * k);
      c.getContext("2d").drawImage(img, sx, sy, sw, sh, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url); ok(c.toDataURL("image/jpeg", 0.85));
    };
    img.onerror = () => no(new Error("图片读不出来"));
    img.src = url;
  });
}
function openModSheet(packName) {
  document.querySelectorAll("details.menu[open]").forEach((x) => x.removeAttribute("open"));
  const ranges = sheetRanges(), d = $("#modSheet");
  let pick = ranges.find((x) => x.key === "p:" + packName) || ranges[0], theme = prefGet("sheetTheme", "mono"), style = prefGet("sheetStyle", "card");
  if (!SHEET_THEMES[theme]) theme = Object.keys(SHEET_THEMES)[0];
  if (style === "polaroid") style = "journal";
  if (!SHEET_STYLES[style]) style = "card";
  const offSrc = new Set(prefGet("sheetOffSrc", []));
  const excluded = new Set();  // 只影响这次分享，不修改合集成员或 Mod 数据
  const expanded = new Set(), searchCollapsed = new Set();
  let page = 0, zoom = null;
  const upRow = (k, label) => `<span class="shup" data-up="${k}"><label class="btn mini shupbtn" tabindex="0">${label}<input type="file" accept="image/*" hidden></label><i class="shthumb"></i><button type="button" class="mini ghost shclr" title="去掉">×</button></span>`;
  d.innerHTML = `<div class="mhead"><h2>分享 Mod 清单</h2><button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
    <div class="shbody"><div class="shselect">
    <h3>分享内容</h3><select id="shRange">${ranges.map((x) => `<option value="${esc(x.key)}" ${x === pick ? "selected" : ""}>${esc(x.label)}</option>`).join("")}</select>
    <input type="search" id="shSearch" placeholder="搜索 Mod 名称 / 尾号 / 备注">
    <div class="shsrc" id="shSrc"></div><label class="chk-line shlibs"><input type="checkbox" id="shLibs" ${prefGet("sheetLibs", true) ? "checked" : ""}> 也列出前置框架</label>
    <div class="shselhead"><label class="chk-line"><input type="checkbox" id="shAll"> 全选当前</label><span class="muted small" id="shCount"></span></div><div id="shMods" class="shmods"></div>
    </div><div class="shprev"><div class="shpvhead"><h3>实时预览</h3><div class="shzoom"><button type="button" class="mini" id="shZoomOut" aria-label="缩小">−</button><button type="button" class="mini" id="shZoomFit" title="适应宽度">适应</button><button type="button" class="mini" id="shZoomIn" aria-label="放大">＋</button></div></div><div class="shpvbox"><div id="shPreviewPage" class="shpvpage"><iframe id="shPrev" title="预览"></iframe></div></div><div class="shpager"><span class="muted small" id="shPage"></span><div class="row"><button type="button" class="mini" id="shPrevPage">上一张</button><button type="button" class="mini" id="shNextPage">下一张</button></div></div></div>
    <div class="shform"><h3>样式</h3>
    <div class="shf"><span>样式</span><div class="segsw shwrap" id="shStyle">${Object.entries(SHEET_STYLES).map(([k, s]) => `<button type="button" data-v="${k}" class="${k === style ? "on" : ""}">${s.name}</button>`).join("")}</div></div>
    <div class="shf" id="shCus"><span>自制样式</span><div class="shcus"><div class="muted small" id="shCusName"></div><div class="row shcusbtns"><button type="button" class="mini" id="shCusGuide">复制说明</button><button type="button" class="mini" id="shCusPaste">粘贴模板</button><button type="button" class="mini" id="shCusOpen">载入文件</button><button type="button" class="mini" id="shCusSave">保存文件</button><button type="button" class="mini ghost" id="shCusReset">用回示例</button><input type="file" id="shCusFile" accept=".html,.htm,.txt" hidden></div><div class="shcusedit hidden" id="shCusEdit"><textarea id="shCusTa" rows="8" spellcheck="false" placeholder="把 AI 给你的模板整段粘贴到这里"></textarea><div class="row"><button type="button" class="mini primary" id="shCusUse">使用</button><button type="button" class="mini ghost" id="shCusCancel">取消</button></div></div></div></div>
    <div class="shf"><span>配色</span><div class="segsw shwrap" id="shTheme">${Object.entries(SHEET_THEMES).map(([k, t]) => `<button type="button" data-v="${k}" class="${k === theme ? "on" : ""}"><i class="shdot" style="background:linear-gradient(90deg,${t.bg} 0 33%,${t.acc} 33% 66%,${t.acc2} 66%)"></i>${t.name}</button>`).join("")}</div></div>
    <div class="shrow2"><label class="shf"><span>标题</span><input id="shTitle" maxlength="30"></label>
    <label class="shf"><span>你的名字</span><input id="shAuthor" maxlength="20" placeholder="不填就写 Made with 星露管理器"></label></div>
    <div class="shf"><span>图片</span><div class="shups">${upRow("avatar", "上传头像")}${upRow("bg", "上传背景")}</div></div>
    <div class="shf"><span>内容</span><label class="chk-line"><input type="checkbox" id="shSum" ${prefGet("sheetSum", false) ? "checked" : ""}> 带上简介</label></div>
    </div></div>
    <div class="shfooter"><div class="shfootertext"><p class="shthanks">如果你喜欢星露管理器，欢迎分享给朋友或在发布时提一句，万分感谢！</p><span class="muted small" id="shMsg" role="status"></span></div><div class="row shactions"><select id="shFormat" aria-label="导出格式"><option value="html">网页</option><option value="png">图片（PNG）</option><option value="pdf">PDF</option><option value="txt">TXT</option><option value="json">合集文件</option></select><button type="button" class="primary" id="shExport">导出</button></div></div>`;
  const ti = $("#shTitle", d), au = $("#shAuthor", d);
  ti.value = pick.title; au.value = prefGet("sheetAuthor", "");
  const eligible = () => sheetItems(pick.ids, $("#shLibs", d).checked).filter((x) => !offSrc.has(x.src));
  const selectedItems = () => eligible().filter(x => !excluded.has(x.m.id));
  const visibleItems = () => { const q = $("#shSearch", d).value.trim().toLowerCase(); return eligible().filter(x => !q || matchesSearch(x.m, q)); };
  let exporting = false;
  const drawList = () => {
    const box = $("#shMods", d), y = box.scrollTop, items = visibleItems(), all = $("#shAll", d);
    $("#shCount", d).textContent = `已选 ${selectedItems().length}`;
    const checked = items.filter(x => !excluded.has(x.m.id)).length;
    all.checked = !!items.length && checked === items.length; all.indeterminate = checked > 0 && checked < items.length; all.disabled = !items.length;
    const groups = sheetGroups(items);
    const searching = !!$("#shSearch", d).value.trim();
    box.innerHTML = groups.length ? groups.map((g, i) => {
      const open = searching ? !searchCollapsed.has(g.cat) : expanded.has(g.cat);
      return `<div class="shmodgroup"><div class="shgrouphead"><input type="checkbox" data-shgroup="${i}" aria-label="选择${esc(g.cat)}分类"><button type="button" class="shgroup-toggle" data-shtoggle="${i}" aria-expanded="${open}"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg><b>${esc(g.cat)}</b><span class="muted small">${g.items.length}</span></button></div>${open ? `<div class="shgroupitems">${g.items.map(x => `<label class="shmodrow" title="${esc(x.zh || x.en)}"><input type="checkbox" data-shmod="${x.m.id}" ${excluded.has(x.m.id) ? "" : "checked"}>${x.img ? `<img src="${esc(x.img)}" alt="" loading="lazy">` : '<i class="shmodph"></i>'}<span>${esc(x.zh || x.en)}</span></label>`).join("")}</div>` : ""}</div>`;
    }).join("") : '<p class="muted small shnone">没有符合条件的 Mod</p>';
    box.querySelectorAll('[data-shtoggle]').forEach(b => b.onclick = () => {const cat=groups[+b.dataset.shtoggle].cat, set=searching?searchCollapsed:expanded;set.has(cat)?set.delete(cat):set.add(cat);drawList();});
    box.querySelectorAll('[data-shgroup]').forEach(c => { const g = groups[+c.dataset.shgroup], n = g.items.filter(x => !excluded.has(x.m.id)).length; c.checked = n === g.items.length; c.indeterminate = n > 0 && n < g.items.length; c.onchange = () => {g.items.forEach(x => c.checked ? excluded.delete(x.m.id) : excluded.add(x.m.id));drawList();prev();}; });
    box.querySelectorAll('[data-shmod]').forEach(c => c.onchange = () => {const id=+c.dataset.shmod;c.checked?excluded.delete(id):excluded.add(id);drawList();prev();});
    box.scrollTop=y;
    $("#shExport", d).disabled = exporting || !selectedItems().length;
  };
  const drawSrc = () => {
    const want = new Set(pick.ids), cnt = {};
    allMods().forEach((m) => { if (want.has(m.id)) { const k = sheetSrcOf(m); cnt[k] = (cnt[k] || 0) + 1; } });
    $("#shSrc", d).innerHTML = Object.keys(SHEET_SRC).filter((k) => cnt[k]).map((k) => `<label class="chk-line"><input type="checkbox" data-src="${k}" ${offSrc.has(k) ? "" : "checked"}> ${SHEET_SRC[k]} ${cnt[k]}</label>`).join("") || '<span class="muted small">这里面没有 Mod</span>';
    $("#shSrc", d).querySelectorAll("[data-src]").forEach((c) => c.onchange = () => { c.checked ? offSrc.delete(c.dataset.src) : offSrc.add(c.dataset.src); drawList(); prev(); });
  };
  const drawUp = () => d.querySelectorAll("[data-up]").forEach((box) => {
    const k = box.dataset.up, v = sheetUp[k];
    $(".shthumb", box).style.backgroundImage = v ? `url(${v})` : ""; $(".shthumb", box).classList.toggle("hidden", !v); $(".shclr", box).classList.toggle("hidden", !v);
    prev();
  });
  d.querySelectorAll("[data-up]").forEach((box) => {
    const k = box.dataset.up, inp = $("input", box);
    $(".shupbtn", box).onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); inp.click(); } };
    inp.onchange = async () => {
      const f = inp.files[0]; inp.value = ""; if (!f) return;
      try { sheetUp[k] = await sheetShrinkFile(f, k === "avatar" ? 320 : 1600, k === "avatar"); try { localStorage.setItem(k === "avatar" ? "sheetAvatar" : "sheetBg", sheetUp[k]); } catch (e) {} drawUp(); }
      catch (err) { toast(err.message); }
    };
    $(".shclr", box).onclick = () => { sheetUp[k] = null; try { localStorage.removeItem(k === "avatar" ? "sheetAvatar" : "sheetBg"); } catch (e) {} drawUp(); };
  });
  // 预览和实际图片/PDF 使用同一模板、分组、分页与选择结果。
  let pvT = 0;
  const fr = $("#shPrev", d), box = $(".shpvbox", d), pvPage = $("#shPreviewPage", d);
  function fitPreview() {
    const doc = fr.contentDocument;
    if (!d.open || !doc?.documentElement) return;
    const k = zoom ?? Math.max(.15, Math.min(1, (box.clientWidth - 28) / 1080));
    const h = Math.max(220, Math.ceil(doc.body?.getBoundingClientRect().bottom || 0), doc.body?.scrollHeight || 0);
    fr.style.height = h + "px"; fr.style.transform = `scale(${k})`; pvPage.style.width = Math.ceil(1080*k)+"px"; pvPage.style.height = Math.ceil(h*k)+"px";
    $("#shZoomFit", d).textContent = `${Math.round(k*100)}%`;
  }
  function prev(reset = true) {
    if (reset) page = 0;
    clearTimeout(pvT);
    pvT = setTimeout(() => {
      if (!d.open || !fr.isConnected) return;
      const st = SHEET_STYLES[style], t = SHEET_THEMES[theme];
      const all = selectedItems(), per = st.per || 30, pages = Math.max(1,Math.ceil(all.length/per));
      if ($("#shFormat",d).value === "txt") {
        $("#shPage",d).textContent = `TXT · ${all.length} 个 Mod`;
        $("#shPrevPage",d).disabled = $("#shNextPage",d).disabled = true;
        fr.style.height="1px"; box.scrollTop=0;
        const content = sheetTxtText(all,{title:ti.value.trim()||pick.title,author:au.value.trim(),sum:$("#shSum",d).checked});
        fr.srcdoc = `<!doctype html><html><head><meta charset="utf-8"><style>html,body{width:1080px;margin:0;overflow:hidden;background:#fff;color:#222}pre{margin:0;padding:36px;white-space:pre-wrap;overflow-wrap:anywhere;font:20px/1.7 ${SHEET_FONT}}</style></head><body><pre>${sheetEsc(content)}</pre></body></html>`;
        return;
      }
      page=Math.max(0,Math.min(page,pages-1)); const items = all.slice(page*per,(page+1)*per);
      $("#shPage", d).textContent = all.length ? `第 ${page+1} / ${pages} 张 · ${all.length} 个 Mod` : "没有选中 Mod";
      $("#shPrevPage", d).disabled = page===0; $("#shNextPage", d).disabled = page>=pages-1;
      const totals = {}; all.forEach((x) => totals[x.cat] = (totals[x.cat] || 0) + 1);
      const titleText=ti.value.trim()||pick.title;
      const paged = ["png","pdf"].includes($("#shFormat",d).value);
      const o = sheetOpt(all, { title: titleText, pg: paged&&pages>1?`${page+1} / ${pages}`:"", start: page*per, author: au.value.trim(), theme: t, style, sum: $("#shSum", d).checked, avatar: sheetUp.avatar, bg: sheetUp.bg });
      const th = { get: (x) => (x && x.img) || "" };
      fr.style.height="1px"; box.scrollTop=0;
      fr.srcdoc = `<!doctype html><html><head><meta charset="utf-8"><style>${sheetCommon(t)}${st.css(t)}html,body{width:1080px;overflow:hidden}a,button{pointer-events:none}${sheetPgCss(t)}</style></head><body>${items.length ? st.body(sheetGroups(items, totals, all[page*per-1]), o, th, all) + sheetPgTag(o) : '<p style="font:40px sans-serif;color:#999;text-align:center;margin:200px 0 0">没有要导出的 Mod</p>'}</body></html>`;
    }, 120);
  }
  const contentRo=new ResizeObserver(fitPreview);
  fr.onload=()=>{contentRo.disconnect();if(fr.contentDocument?.body)contentRo.observe(fr.contentDocument.body);fitPreview();};
  const ro=new ResizeObserver(fitPreview);ro.observe(box);d.addEventListener("close",()=>{clearTimeout(pvT);ro.disconnect();contentRo.disconnect();fr.onload=null;},{once:true});
  $("#shPrevPage",d).onclick=()=>{page--;prev(false);}; $("#shNextPage",d).onclick=()=>{page++;prev(false);};
  const changeZoom=delta=>{zoom=Math.max(.15,Math.min(1,(zoom??Math.min(1,(box.clientWidth-28)/1080))+delta));fitPreview();};
  $("#shZoomOut",d).onclick=()=>changeZoom(-.08);$("#shZoomIn",d).onclick=()=>changeZoom(.08);$("#shZoomFit",d).onclick=()=>{zoom=null;fitPreview();};
  drawSrc(); drawUp(); drawList();
  fancySelect($("#shRange", d));
  $("#shRange", d).onchange = (e) => { const old = pick; pick = ranges.find((x) => x.key === e.target.value) || ranges[0]; if (!ti.value.trim() || ti.value === old.title) ti.value = pick.title; excluded.clear();$("#shSearch",d).value="";drawSrc();drawList();prev(); };
  $("#shSearch",d).oninput=()=>{searchCollapsed.clear();drawList();};
  $("#shAll",d).onchange=e=>{visibleItems().forEach(x=>e.target.checked?excluded.delete(x.m.id):excluded.add(x.m.id));drawList();prev();};
  const seg = (id, set) => $(id, d).onclick = (e) => { const b = e.target.closest("button"); if (!b) return; set(b.dataset.v); $(id, d).querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b)); };
  seg("#shTheme", (v) => { theme = v; prev(); }); seg("#shStyle", (v) => { style = v; drawCus(); prev(); });
  // 自制样式：复制说明给 AI → 粘贴或打开 AI 给的模板 → 预览、导出都用它
  const cusMsg = (t) => { $("#shMsg", d).textContent = t; };
  const drawCus = () => {
    $("#shCus", d).classList.toggle("hidden", style !== "custom");
    const mine = prefGet("sheetCustom", ""), nm = sheetTplSplit(sheetCustomTpl()).name;
    $("#shCusName", d).textContent = mine ? `正在用：${nm || "自制模板"}` : "正在用：示例。先点「复制说明」，发给任意 AI，写上你想要的样子";
    $("#shCusReset", d).classList.toggle("hidden", !mine);
  };
  const useTpl = (txt) => {
    txt = String(txt || "").replace(/^\s*```[a-z]*\s*/i, "").replace(/```\s*$/, "").trim();
    if (!txt) return cusMsg("模板是空的");
    if (txt.length > 200000) return cusMsg("模板太长了，让 AI 写短一点");
    if (!/\{\{#\s*groups\s*\}\}/.test(txt) || !/\{\{#\s*items\s*\}\}/.test(txt)) return cusMsg("这不是能用的模板：里面要有 {{#groups}} 和 {{#items}}。把说明重新发给 AI 再试");
    prefSet("sheetCustom", txt); $("#shCusEdit", d).classList.add("hidden"); cusMsg(""); drawCus(); prev();
  };
  $("#shCusGuide", d).onclick = async () => toast(await copyText(SHEET_CUSTOM_GUIDE) ? "已复制。发给 AI，在「我想要的样子」那里写上你的想法" : "复制不了，请再试一次");
  $("#shCusPaste", d).onclick = () => { $("#shCusEdit", d).classList.remove("hidden"); $("#shCusTa", d).value = ""; $("#shCusTa", d).focus(); };
  $("#shCusCancel", d).onclick = () => $("#shCusEdit", d).classList.add("hidden");
  $("#shCusUse", d).onclick = () => useTpl($("#shCusTa", d).value);
  $("#shCusOpen", d).onclick = () => $("#shCusFile", d).click();
  $("#shCusFile", d).onchange = async (e) => { const f = e.target.files[0]; e.target.value = ""; if (f) useTpl(await f.text()); };
  $("#shCusSave", d).onclick = () => { const tpl = sheetCustomTpl(); sheetSave(new Blob([tpl], { type: "text/html" }), `${sheetTplSplit(tpl).name || "自制样式"}.星露样式.html`); toast("已保存到「下载」文件夹，发给别人后对方点「载入文件」就能用"); };
  $("#shCusReset", d).onclick = async () => { if (await askConfirm("用回示例？", "你现在的自制模板会被换掉。想留着的话先点「保存文件」。", "用回示例", "primary")) { prefSet("sheetCustom", ""); drawCus(); prev(); } };
  drawCus();
  ti.oninput = au.oninput = () => prev(); $("#shSum", d).onchange = () => prev(); $("#shLibs", d).onchange = () => {drawList();prev();};
  const format=$("#shFormat",d);format.value=prefGet("sheetFormat","html");if(!format.value)format.value="html";fancySelect(format);format.onchange=()=>prev(false);
  const go = async (kind) => {
    if (exporting) return;
    const libs = $("#shLibs", d).checked, sum = $("#shSum", d).checked;
    prefSet("sheetTheme", theme); prefSet("sheetStyle", style); prefSet("sheetAuthor", au.value.trim()); prefSet("sheetLibs", libs); prefSet("sheetSum", sum); prefSet("sheetOffSrc", [...offSrc]);
    prefSet("sheetFormat",kind);
    const items = selectedItems();
    if (!items.length) { $("#shMsg", d).textContent = "没有要导出的 Mod，看看「来源」是不是都没勾。"; return; }
    const opt = { title: ti.value.trim() || pick.title, author: au.value.trim(), theme: SHEET_THEMES[theme], style, sum, avatar: sheetUp.avatar, bg: sheetUp.bg };
    const exportBtn=$("#shExport",d), msg=$("#shMsg",d);exporting=true;exportBtn.disabled=true;
    const say = (t) => { if (msg.isConnected) msg.textContent = t; };
    try {
      if (kind === "json") sheetJson(items, opt);
      else if (kind === "txt") sheetTxt(items, opt);
      else if (kind === "html") await sheetHtml(items, opt, say);
      else if (kind === "pdf") await sheetPdf(items, opt, say);
      else await sheetPng(items, opt, say);
      const non = items.filter((x) => !x.nid).length;
      say("");
      toast(`已保存到「下载」文件夹` + (kind === "json" ? "。朋友在「添加 Mod → 导入合集文件」里打开它" : "") + (non && kind === "json" ? `（${non} 个不是 Nexus 的，朋友要自己找）` : ""), 7000);
    } catch (err) { say("没做成：" + err.message); }
    finally { exporting=false; if (exportBtn.isConnected) exportBtn.disabled = !selectedItems().length; }
  };
  $("#shExport", d).onclick = () => go(format.value);
  d.showModal(); prev();
}
function sheetItems(ids, libs) {
  const want = new Set(ids), order = (state.cfg.categories || []).map((c) => c.name);
  const rank = (c) => { const i = order.indexOf(c); return c === "前置框架" ? 999 : i < 0 ? 998 : i; };
  return allMods().filter((m) => want.has(m.id) && (libs || m.category !== "前置框架"))
    .map((m) => ({ m, nid: m.nexus_id ? String(m.nexus_id) : "", zh: m.name_zh || "", en: m.name || "", cat: m.category || "其他", img: (m.images || [])[0] || "",
      src: sheetSrcOf(m), sum: String(m.summary_zh || m.summary || "").replace(/\s+/g, " ").trim().slice(0, 120),
      url: m.nexus_id ? `https://www.nexusmods.com/stardewvalley/mods/${m.nexus_id}` : (m.source_url || m.unofficial_url || m.url || "") }))
    .sort((a, b) => rank(a.cat) - rank(b.cat) || (a.zh || a.en).localeCompare(b.zh || b.en, "zh"));
}
// 分组：totals 记整组的数量（图片分页时一组会被拆到几张里）
function sheetGroups(items, totals, before) {
  const g = [];
  items.forEach((x) => { let last = g[g.length - 1]; if (!last || last.cat !== x.cat) g.push(last = { cat: x.cat, items: [] }); last.items.push(x); });
  g.forEach((x) => x.total = totals ? totals[x.cat] : x.items.length);
  // 分类从上一页接过来时，标题加「（续）」
  if (before && g[0] && g[0].cat === before.cat) g[0].cat += "（续）";
  return g;
}
function sheetSave(blob, name) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = name.replace(/[\\/:*?"<>|]/g, "_");
  document.body.appendChild(a); a.click();
  setTimeout(() => { a.remove(); URL.revokeObjectURL(a.href); }, 10000);
}
function sheetJson(items, opt) {
  const data = { type: "xinglu-pack", v: 1, name: opt.title, made: new Date().toISOString().slice(0, 10),
    mods: items.map((x) => ({ nexus_id: x.nid ? +x.nid : null, name: x.en, name_zh: x.zh, uids: x.m.unique_ids || [], url: x.url })) };
  sheetSave(new Blob([JSON.stringify(data, null, 1)], { type: "application/json" }), `${opt.title}.星露合集.json`);
}
function sheetTxtText(items, opt) {
  const lines = [opt.title, `共 ${items.length} 个 Mod`];
  if (opt.author) lines.push(`作者：${opt.author}`);
  for (const g of sheetGroups(items)) {
    lines.push("", `【${g.cat} · ${g.total}】`, "");
    for (const x of g.items) {
      lines.push(x.zh && x.en && x.zh !== x.en ? `${x.zh}（${x.en}）` : x.zh || x.en);
      lines.push(x.nid ? `尾号：${x.nid}` : `来源：${SHEET_SRC[x.src] || "其他"}`);
      if (x.url) lines.push(x.url);
      if (opt.sum && x.sum) lines.push(x.sum);
      lines.push("");
    }
  }
  return lines.join("\r\n");
}
function sheetTxt(items, opt) {
  sheetSave(new Blob(["\uFEFF", sheetTxtText(items, opt)], { type: "text/plain;charset=utf-8" }), `${opt.title}.txt`);
}
function sheetLoadImg(src) {
  return new Promise((ok) => { if (!src) return ok(null); const im = new Image(); im.onload = () => ok(im); im.onerror = () => ok(null); im.src = src; });
}
// 封面缩成小图（最长边 480），直接嵌进网页 / 图片里，导出的文件不依赖管理器
async function sheetThumbs(items, say) {
  const out = new Map(); let done = 0;
  const list = items.filter((x) => x.img), total = list.length, queue = list.slice();
  const work = async () => {
    const c = document.createElement("canvas"), ctx = c.getContext("2d");
    while (queue.length) {
      const x = queue.shift(), im = await sheetLoadImg(x.img);
      if (im) { try { const k = Math.min(1, 480 / Math.max(im.width, im.height)); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); ctx.drawImage(im, 0, 0, c.width, c.height); out.set(x, c.toDataURL("image/jpeg", 0.78)); } catch (e) { /* 读不了就不放图 */ } }
      say(`正在处理 ${++done} / ${total}`);
    }
  };
  await Promise.all([work(), work(), work(), work()]);
  return out;
}
function sheetOpt(items, opt) {
  const cats = new Set(items.map((x) => x.cat));
  return { ...opt, count: items.length, cats: cats.size, nexus: items.filter((x) => x.nid).length, date: new Date().toLocaleDateString("zh-CN"),
    metaLine: `${opt.author ? opt.author + " · " : ""}共 ${items.length} 个 Mod · ${new Date().toLocaleDateString("zh-CN")}` };
}
async function sheetHtml(items, opt, say) {
  const th = await sheetThumbs(items, say), st = SHEET_STYLES[opt.style] || SHEET_STYLES.card, t = opt.theme, o = sheetOpt(items, opt);
  const groups = sheetGroups(items), nids = items.filter((x) => x.nid).map((x) => x.nid);
  const html = `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${sheetEsc(opt.title)}</title>
<style>${sheetCommon(t)}${st.css(t)}
.tb{position:sticky;top:0;z-index:5;display:flex;gap:8px;flex-wrap:wrap;align-items:center;padding:10px 12px;background:${t.bg}ee;backdrop-filter:blur(6px);border-bottom:1px solid ${t.line};font-family:${SHEET_FONT}}
.tb input{flex:1;min-width:150px;height:36px;border:2px solid ${t.line};border-radius:99px;padding:0 14px;background:${t.card};color:${t.ink};font:inherit;outline:none}
.tb .all{height:36px;border-radius:99px;padding:0 16px;background:${t.acc};color:#fff;font-weight:600}
.tb select{height:36px;border:2px solid ${t.line};border-radius:99px;padding:0 10px;background:${t.card};color:${t.ink};font:inherit}
.none{text-align:center;color:${t.sub};padding:40px 0;display:none}
.toast{position:fixed;left:50%;bottom:28px;transform:translateX(-50%) translateY(20px);background:${t.ink};color:${t.bg};padding:9px 18px;border-radius:99px;font-size:14px;opacity:0;transition:.2s;pointer-events:none;font-family:${SHEET_FONT};z-index:9}
.toast.on{opacity:1;transform:translateX(-50%)}</style></head><body>
<div class="tb"><input id="q" type="search" placeholder="搜名字或尾号">${groups.length > 1 ? `<select id="cat"><option value="">全部分类</option>${groups.map((g) => `<option>${sheetEsc(g.cat)}</option>`).join("")}</select>` : ""}${nids.length ? `<button class="all" id="all">复制全部尾号</button>` : ""}</div>
${st.body(groups, o, th, items)}
<p class="none" id="none">没有找到。</p><div class="toast" id="toast"></div>
<script>
var NIDS=${JSON.stringify(nids.join(" "))};
function toast(m){var t=document.getElementById("toast");t.textContent=m;t.classList.add("on");clearTimeout(toast.h);toast.h=setTimeout(function(){t.classList.remove("on")},1800)}
function copy(s,ok){function fb(){var a=document.createElement("textarea");a.value=s;a.style.position="fixed";a.style.opacity="0";document.body.appendChild(a);a.select();try{document.execCommand("copy");ok()}catch(e){toast("复制不了，请手动复制")}a.remove()}if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(s).then(ok,fb)}else fb()}
document.addEventListener("click",function(e){var b=e.target.closest("button.id");if(b){e.preventDefault();copy(b.dataset.id,function(){b.classList.add("ok");setTimeout(function(){b.classList.remove("ok")},1200);toast("已复制尾号 "+b.dataset.id)});return}
if(e.target.id==="all"){copy(NIDS,function(){toast("已复制全部尾号，一共 ${nids.length} 个")})}});
var q=document.getElementById("q"),cs=document.getElementById("cat");q.addEventListener("input",filter);if(cs)cs.addEventListener("change",filter);
function filter(){var s=q.value.trim().toLowerCase(),c=cs?cs.value:"",any=false;document.querySelectorAll("[data-sec]").forEach(function(sec){var n=0;if(c&&sec.dataset.sec!==c){sec.style.display="none";return}sec.querySelectorAll(".it").forEach(function(it){var on=!s||it.dataset.q.indexOf(s)>=0;it.style.display=on?"":"none";if(on)n++});sec.style.display=n?"":"none";if(n)any=true});document.getElementById("none").style.display=any?"none":"block"}
</script></body></html>`;
  sheetSave(new Blob([html], { type: "text/html" }), `${opt.title}.html`);
}
// 图片 / PDF：同一份样式，按 per 个一张分好页，每页放进一个看不见的小窗口排好版，量出高度，再画到 canvas 上
// 一页一页画：画完马上交给 eat 转成压缩好的文件，再把画布清掉，不会一次占很多内存（GPT 查出，11-24）
// 一页超过最高高度就自动拆成两页，不会把下面截掉
async function sheetDraw(items, opt, say, eat) {
  const th = await sheetThumbs(items, say), st = SHEET_STYLES[opt.style] || SHEET_STYLES.card, t = opt.theme;
  const totals = {}; items.forEach((x) => totals[x.cat] = (totals[x.cat] || 0) + 1);
  const per = st.per || 30, pages = [];
  for (let i = 0; i < items.length; i += per) pages.push({ start: i, n: Math.min(per, items.length - i) });
  const W = 1080, SCALE = 2, MAXH = 15000;
  const fr = document.createElement("iframe");
  fr.style.cssText = `position:fixed;left:-99999px;top:0;width:${W}px;height:400px;border:0;visibility:hidden`;
  document.body.appendChild(fr);
  const lay = async (pg, label) => {
    const o = sheetOpt(items, { ...opt, start: pg.start, pg: label });
    const doc = fr.contentDocument;
    doc.open(); doc.write(`<!doctype html><html><head><meta charset="utf-8"><style>${sheetCommon(t)}${st.css(t)}html,body{width:${W}px}${sheetPgCss(t)}</style></head><body>${st.body(sheetGroups(items.slice(pg.start, pg.start + pg.n), totals, items[pg.start - 1]), o, th, items)}${sheetPgTag(o)}</body></html>`); doc.close();
    await Promise.all([...doc.images].map((im) => im.decode().catch(() => {})));
    await new Promise((r) => setTimeout(r, 60));
    return { doc, h: Math.ceil(doc.documentElement.scrollHeight) };
  };
  try {
    if (pages.length > 1 || items.length > 1) {  // 先量一遍：太高的页对半拆
      for (let pi = 0; pi < pages.length; pi++) {
        const pg = pages[pi];
        if (pg.n > 1 && (await lay(pg, "99 / 99")).h > MAXH) {
          const half = Math.ceil(pg.n / 2);
          pages.splice(pi, 1, { start: pg.start, n: half }, { start: pg.start + half, n: pg.n - half });
          pi--;
        }
      }
    }
    for (let pi = 0; pi < pages.length; pi++) {
      say(pages.length > 1 ? `正在处理 ${pi + 1} / ${pages.length}` : "正在处理");
      const { doc, h } = await lay(pages[pi], pages.length > 1 ? `${pi + 1} / ${pages.length}` : "");
      if (h > MAXH) throw new Error("单个 Mod 的模板内容过长，请缩小模板或改用网页导出");
      const H = h;
      const xml = new XMLSerializer().serializeToString(doc.documentElement);
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}"><foreignObject width="100%" height="100%">${xml}</foreignObject></svg>`;
      const img = new Image();
      img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
      await img.decode();
      const c = document.createElement("canvas"); c.width = W * SCALE; c.height = H * SCALE;
      const ctx = c.getContext("2d"); ctx.fillStyle = t.bg; ctx.fillRect(0, 0, c.width, c.height); ctx.scale(SCALE, SCALE); ctx.drawImage(img, 0, 0);
      try { await eat(c, pi, pages.length); } finally { c.width = c.height = 0; img.src = ""; }
    }
  } finally { fr.remove(); }
  return pages.length;
}
const sheetBlob = (c, type, q) => new Promise((ok, no) => c.toBlob((b) => b ? ok(b) : no(new Error("图片太大了，换成「网页」试试")), type, q));
// 图片：一张就直接存 png；好几张打成一个 zip（浏览器会拦「一次下载多个文件」，所以只下一次）
async function sheetPng(items, opt, say) {
  const files = [];
  const n = await sheetDraw(items, opt, say, async (c, i) => { files.push({ name: `${opt.title}-${i + 1}.png`, blob: await sheetBlob(c, "image/png") }); });
  if (n === 1) { sheetSave(files[0].blob, `${opt.title}.png`); return; }
  say("正在处理");
  for (const f of files) { f.data = new Uint8Array(await f.blob.arrayBuffer()); f.blob = null; }
  sheetSave(sheetZip(files), `${opt.title}（${n} 张图）.zip`);
}
// PDF：每张图一页，图片用 JPEG 放进去（不用外部库）
async function sheetPdf(items, opt, say) {
  const pages = [];
  await sheetDraw(items, opt, say, async (c) => { pages.push({ w: c.width, h: c.height, jpg: new Uint8Array(await (await sheetBlob(c, "image/jpeg", 0.9)).arrayBuffer()) }); });
  say("正在处理");
  sheetSave(sheetPdfBlob(pages, opt.title), `${opt.title}.pdf`);
}
function sheetCrc(buf) {
  let t = sheetCrc.t;
  if (!t) { t = sheetCrc.t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } }
  let c = 0xffffffff; for (let i = 0; i < buf.length; i++) c = t[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function sheetZip(files) {  // 不压缩的 zip（png 本来就压缩过），文件名 UTF-8
  const enc = new TextEncoder(), parts = [], central = []; let off = 0;
  const u16 = (v) => [v & 255, (v >>> 8) & 255], u32 = (v) => [v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255];
  for (const f of files) {
    const name = enc.encode(f.name), crc = sheetCrc(f.data), n = f.data.length;
    const head = [0x50, 0x4b, 3, 4, ...u16(20), ...u16(0x800), ...u16(0), ...u16(0), ...u16(0), ...u32(crc), ...u32(n), ...u32(n), ...u16(name.length), ...u16(0)];
    parts.push(new Uint8Array(head), name, f.data);
    central.push(new Uint8Array([0x50, 0x4b, 1, 2, ...u16(20), ...u16(20), ...u16(0x800), ...u16(0), ...u16(0), ...u16(0), ...u32(crc), ...u32(n), ...u32(n), ...u16(name.length), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(off)]), name);
    off += head.length + name.length + n;
  }
  const cdSize = central.reduce((a, b) => a + b.length, 0);
  const end = new Uint8Array([0x50, 0x4b, 5, 6, ...u16(0), ...u16(0), ...u16(files.length), ...u16(files.length), ...u32(cdSize), ...u32(off), ...u16(0)]);
  return new Blob([...parts, ...central, end], { type: "application/zip" });
}
function sheetPdfBlob(pages, title) {
  const enc = new TextEncoder(), chunks = [], offs = []; let pos = 0;
  const put = (x) => { const b = typeof x === "string" ? enc.encode(x) : x; chunks.push(b); pos += b.length; };
  const obj = (n, body) => { offs[n] = pos; put(`${n} 0 obj\n`); body(); put("\nendobj\n"); };
  const K = 0.75, np = pages.length;  // 1px = 0.75pt
  const pageObj = (i) => 3 + i * 3, imgObj = (i) => 4 + i * 3, cntObj = (i) => 5 + i * 3, infoObj = 3 + np * 3;
  const hex = (s) => "<FEFF" + [...s].map((ch) => { const c = ch.codePointAt(0); return c > 0xffff ? [0xd800 + ((c - 0x10000) >> 10), 0xdc00 + ((c - 0x10000) & 0x3ff)] : [c]; }).flat().map((c) => c.toString(16).padStart(4, "0")).join("") + ">";
  put("%PDF-1.4\n%\xe2\xe3\xcf\xd3\n");
  obj(1, () => put("<< /Type /Catalog /Pages 2 0 R >>"));
  obj(2, () => put(`<< /Type /Pages /Count ${np} /Kids [${pages.map((_, i) => `${pageObj(i)} 0 R`).join(" ")}] >>`));
  pages.forEach((p, i) => {
    const w = (p.w * K).toFixed(2), h = (p.h * K).toFixed(2), cs = `q ${w} 0 0 ${h} 0 0 cm /Im0 Do Q`;
    obj(pageObj(i), () => put(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${w} ${h}] /Resources << /XObject << /Im0 ${imgObj(i)} 0 R >> >> /Contents ${cntObj(i)} 0 R >>`));
    obj(imgObj(i), () => { put(`<< /Type /XObject /Subtype /Image /Width ${p.w} /Height ${p.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${p.jpg.length} >>\nstream\n`); put(p.jpg); put("\nendstream"); });
    obj(cntObj(i), () => put(`<< /Length ${cs.length} >>\nstream\n${cs}\nendstream`));
  });
  obj(infoObj, () => put(`<< /Title ${hex(title)} /Producer ${hex("星露管理器")} >>`));
  const xref = pos, total = infoObj + 1;
  put(`xref\n0 ${total}\n0000000000 65535 f \n` + Array.from({ length: total - 1 }, (_, i) => String(offs[i + 1]).padStart(10, "0") + " 00000 n \n").join(""));
  put(`trailer\n<< /Size ${total} /Root 1 0 R /Info ${infoObj} 0 R >>\nstartxref\n${xref}\n%%EOF`);
  return new Blob(chunks, { type: "application/pdf" });
}
// 合集分享（11-23）：导出成一个小文件发给朋友；朋友「添加 Mod → 导入合集文件」，再点「下载没装的」
async function packDownload(name) {
  const p = state.packs.find((x) => x.name === name); if (!p) return;
  const ids = allMods().filter((m) => p.ids.includes(m.id) && !m.installed).map((m) => m.id);
  try {
    const r = await api("/api/pack-download", { ids });
    toast(r.queued ? `开始下载 ${r.queued} 个` : r.guided ? `会逐个打开 ${r.guided} 个下载页，点「Slow download」后自动弹下一个` : "没有能自动下载的", 7000);
    const pv = pickVersions(r), rest = (r.manual?.length || 0) - (r.manual_ids || []).length;
    if (pv || rest > 0) setTimeout(() => toast([pv, rest > 0 && `${rest} 个不在 Nexus，要自己下载`].filter(Boolean).join("；"), 8000), 2500);
    load();
  } catch (err) { toast(err.message, 7000); }
}
$("#btnPackImport").onclick = () => $("#packFile").click();
$("#packFile").onchange = async (e) => {
  const f = e.target.files[0]; e.target.value = "";
  if (!f) return;
  let data; try { data = JSON.parse(await f.text()); } catch (err) { return toast("这不是星露管理器的合集文件", 6000); }
  try {
    const r = await api("/api/pack-import", { pack: data });
    await load();
    state.packs = await api("/api/packs").catch(() => state.packs);
    state.cat = PACK; state.pack = r.name; render();
    const items = (r.manual || []).map((x) => x.name + (x.url ? `：${x.url}` : ""));
    if (r.missing || items.length) {
      const pick = await askChoice(`已导入合集「${r.name}」`, (r.missing ? `有 ${r.missing} 个还没下载。` : "") + (items.length ? `下面 ${items.length} 个不是 Nexus 上的，要自己找来装。` : ""), items.slice(0, 30),
        [{ key: null, text: "以后再说" }, ...(r.missing ? [{ key: "dl", text: "全部下载", cls: "primary" }] : [])]);
      if (pick === "dl") packDownload(r.name);
    } else toast(`已导入合集「${r.name}」，${r.count} 个都装好了`);
  } catch (err) { toast(err.message, 7000); }
};
// 启动游戏（11-23）：先看 SMAPI 装没装、游戏开没开、有没有缺前置 / 多版本没选，再通过 SMAPI 启动
async function playGame() {
  const btn = $("#btnPlay"); btn.disabled = true;
  try {
    const c = await api("/api/game/check");
    if (!c.gamedir) { openSettings("gen"); return toast("没找到游戏，已打开设置：点「自动查找」或粘贴游戏 Mods 文件夹，再点「保存」", 8000); }
    if (c.xbox) return toast("Xbox / Game Pass 版不能从这里启动，请从 Xbox 应用启动游戏", 7000);
    if (!c.smapi.installed) {
      if (await askConfirm("还没装 SMAPI", "Mod 要靠 SMAPI 才能用。点「去下载」，下载后解压，双击里面的「install on Windows」。", "去下载", "primary")) openExt(c.smapi.page);
      return;
    }
    if (c.running) return toast("游戏已经开着了");
    const live = allMods().filter((m) => inGame(m) && !m.disabled);
    const miss = withLibraryLookup(() => live.filter((m) => missingRequired(m).length));
    const vars = live.filter((m) => m.variant_clash), incomp = live.filter((m) => compatOf(m));
    if (miss.length || vars.length || incomp.length) {
      const items = [...miss.map((m) => `${title(m)}：缺前置`), ...vars.map((m) => `${title(m)}：要选一个版本`), ...incomp.map((m) => `${title(m)}：不兼容，会被跳过`)];
      const pick = await askChoice(`有 ${items.length} 个 Mod 进游戏会用不了`, miss.length ? "建议先补齐前置再玩。" : vars.length ? "在详情里选一个版本再玩。" : "这些 Mod 进游戏不会生效，不影响其他 Mod。", items.slice(0, 30),
        [{ key: null, text: "取消" }, { key: "go", text: "直接启动" }, ...(miss.length ? [{ key: "fix", text: "先补齐前置", cls: "primary" }] : [])]);
      if (pick === "fix") return openFixDeps();
      if (pick !== "go") return;
    }
    await api("/api/game/launch", {});
    toast(c.smapi.latest ? `游戏启动中…（SMAPI 有新版 ${c.smapi.latest}，可在「设置 → 常规」更新）` : "游戏启动中…", 6000);
  } catch (err) { toast(err.message, 7000); }
  finally { btn.disabled = false; }
}
$("#btnPlay").onclick = playGame;
// 输入框弹窗（替代浏览器自带的 prompt）
function askInput(title, value = "", okText = "确定", hint = "", check = null) {  // check：{label, checked} → 多一个勾选框，结果是 {value, checked}
  return queueQuestion("inputDlg", () => {
  let d = $("#inputDlg");
  if (!d) { d = document.createElement("dialog"); d.id = "inputDlg"; d.className = "modal confirm"; d.setAttribute("closedby", "closerequest"); document.body.appendChild(d); }
  d.innerHTML = `<h2>${esc(title)}</h2>${hint ? `<p class="muted small">${esc(hint)}</p>` : ""}<input id="inOk" maxlength="80">${check ? `<label class="chk-line inchk"><input type="checkbox" id="inChk" ${check.checked ? "checked" : ""}> ${esc(check.label)}</label>` : ""}<div class="row end"><button data-close>取消</button><button class="primary" id="inGo">${esc(okText)}</button></div>`;
  const inp = $("#inOk", d); inp.value = value;
  return new Promise((res) => {
    let out = null;
    const go = () => { out = check ? { value: inp.value.trim(), checked: $("#inChk", d).checked } : inp.value.trim(); d.close(); };
    $("#inGo", d).onclick = go;
    inp.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); go(); } };
    d.querySelector("[data-close]").onclick = () => d.close();
    d.onclose = () => { d.onclose = null; res(out); };
    d.showModal(); inp.focus(); inp.select();
  });
  });
}
async function delPack(name) {
  const p = state.packs.find((x) => x.name === name); if (!p) return;
  if (!await askConfirm(`删除合集「${name}」？`, `只删这个合集，里面的 ${packIds(p).length} 个 Mod 不动。删掉的合集在「设置 → 回收站」留 30 天。`)) return;
  try { await api("/api/trash/add-pack", { pack: p }); }
  catch (err) { if (!await askConfirm("没能放进回收站", "删掉后就找不回来了。还要删除吗？", "仍然删除", "danger")) return; }
  try { await savePacks((ps) => ps.filter((x) => x.name !== name)); } catch (err) { return toast(err.message, 6000); }
  if (state.cat === PACK && state.pack === name) { state.cat = "全部"; state.pack = ""; }
  render(); toast(`已删除合集「${name}」`);
}

// 牌阵：点一摞，卡片依次弹出横排，后面页面模糊，滚轮左右翻（11-22）
function openStackView(k, from, keepX) {
  const mods = (state.restList?.find((u) => u.stack === k) || {}).mods;
  const d = $("#stackView");
  if (!mods) { if (keepX != null) d.close(); return; }
  d.dataset.svkey = k; d.dataset.sig = mods.map(modSig).join("\n");  // 不能叫 data-stack：全局点击会把弹窗本身当成牌堆再打开一次
  const cards = withLibraryLookup(() => mods.map(card).join("")).replaceAll('loading="lazy" src="', 'decoding="async" data-src="');
  d.innerHTML = `<div class="svhead"><b>${esc(mods[0].author)}</b><span>${mods.length} 个</span><button class="x" data-close aria-label="关闭"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
    <div class="svtrack">${cards}</div><div class="svhint">滚轮左右翻 · 点卡片看详情 · 点空白处关闭</div>`;
  const tr = $(".svtrack", d);
  if (!d.open) d.showModal();
  if (keepX != null) tr.scrollLeft = keepX;
  const loadVisible = () => {
    const first = Math.max(0, Math.floor(tr.scrollLeft / 268) - 1);
    const last = Math.min(mods.length, Math.ceil((tr.scrollLeft + tr.clientWidth) / 268) + 1);
    for (let i = first; i < last; i++) {
      const img = tr.children[i]?.querySelector("img[data-src]");
      if (img) { img.src = img.dataset.src; delete img.dataset.src; }
    }
  };
  loadVisible();
  tr.addEventListener("scroll", loadVisible, { passive: true });
  if (keepX == null) {
    d.addEventListener("close", () => { d.innerHTML = ""; delete d.dataset.svkey; }, { once: true });
    [...tr.children].slice(0, 8).forEach((c, i) => { c.classList.add("enter"); c.style.animationDelay = `${i * 35}ms`; });
  }
  tr.classList.add("go");
  d.querySelector("[data-close]").onclick = () => d.close();
  d.onclick = (e) => { if (e.target === d || e.target === tr || e.target.classList.contains("svhint") || e.target.classList.contains("svhead")) d.close(); };
  tr.onwheel = (e) => { if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) { e.preventDefault(); tr.scrollLeft += e.deltaY; loadVisible(); } };
}

// 选完文件或点别处，收起「选文件」小菜单
document.addEventListener("change", (e) => { if (e.target.matches("[data-libfile],[data-libdir]")) e.target.closest("details.minimenu")?.removeAttribute("open"); }, true);
document.addEventListener("click", (e) => { document.querySelectorAll("details.minimenu[open]").forEach((d) => { if (!d.contains(e.target)) d.removeAttribute("open"); }); });

// 下拉菜单比窗口高时，限制高度、在菜单里面滚动（11-24 Hazel：管理菜单超出浏览器）
function fitMenu(d) {
  const p = d.querySelector(":scope > .pop"); if (!p) return;
  p.style.maxHeight = ""; p.style.overflowY = "";
  const r = p.getBoundingClientRect(), room = Math.floor(d.classList.contains("up") ? r.bottom - 8 : innerHeight - r.top - 8);
  if (r.height > room) { p.style.maxHeight = Math.max(160, room) + "px"; p.style.overflowY = "auto"; }
}
document.addEventListener("toggle", (e) => { const d = e.target; if (d.matches && d.matches("details.menu") && d.open) fitMenu(d); }, true);
window.addEventListener("resize", () => document.querySelectorAll("details.menu[open]").forEach(fitMenu));
